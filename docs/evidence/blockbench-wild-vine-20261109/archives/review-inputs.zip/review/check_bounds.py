"""Independent transformed-corner spans from the original resource JSON."""
from pathlib import Path
import itertools, json, math

HERE = Path(__file__).resolve().parent

def transform(point, pivot, angle):
    a = math.radians(angle)
    x, z = point[0] - pivot[0], point[2] - pivot[2]
    return [pivot[0] + x*math.cos(a) + z*math.sin(a), point[1],
            pivot[2] - x*math.sin(a) + z*math.cos(a)]

def bounds(points):
    lower = [min(p[k] for p in points) for k in range(3)]
    upper = [max(p[k] for p in points) for k in range(3)]
    return {'min': lower, 'max': upper, 'span': [b-a for a,b in zip(lower,upper)]}

source = json.loads((HERE/'official-cross-1.20.1.json').read_text())
points = []
for element in source['elements']:
    fr, to = element['from'][:], element['to'][:]
    rotation = element['rotation']
    assert rotation['axis'] == 'y' and rotation['rescale'] is True
    pivot, angle = rotation['origin'], rotation['angle']
    scale = 1/math.cos(math.radians(angle))
    for axis in [0,2]:
        fr[axis] = pivot[axis] + (fr[axis]-pivot[axis])*scale
        to[axis] = pivot[axis] + (to[axis]-pivot[axis])*scale
    points += [transform(p,pivot,angle) for p in itertools.product(*zip(fr,to))]
java = bounds(points)

native = json.loads((HERE/'inputs/canonical/runtime/RP/models/entity/wild_grapevine.geo.json').read_text())['minecraft:geometry'][0]
points = []
for bone in native['bones']:
    assert not bone.get('rotation') and not bone.get('parent')
    for cube in bone['cubes']:
        fr = cube['origin']
        to = [x+y for x,y in zip(fr,cube['size'])]
        pivot, rotation = cube.get('pivot',[0,0,0]), cube['rotation']
        assert rotation[0] == rotation[2] == 0
        points += [transform(p,pivot,rotation[1]) for p in itertools.product(*zip(fr,to))]
bedrock = bounds(points)
assert abs(java['span'][0]-14.4) < 1e-9
assert abs(bedrock['span'][0]-16.1/math.sqrt(2)) < 1e-9
report = {'method':'Independent corner transforms on original JSON; native coordinates compared by spans, which are unchanged by X reflection. No scene-helper calls.',
          'source':java,'native':bedrock,
          'native_to_source_span_ratio':bedrock['span'][0]/java['span'][0],
          'claim':'Resource geometry span mismatch confirmed. No GUI or native game acceptance yet.'}
print(json.dumps(report,indent=2))
