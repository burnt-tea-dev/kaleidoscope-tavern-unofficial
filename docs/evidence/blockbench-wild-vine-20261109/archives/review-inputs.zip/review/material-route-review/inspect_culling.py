"""Static-only JVM class-file constant and bytecode reader; never loads Java classes."""
import struct,zipfile,pathlib,re,json,hashlib,sys
JAR=pathlib.Path(sys.argv[1]); MAPPINGS=pathlib.Path(sys.argv[2]); OUTPUT=pathlib.Path(sys.argv[3])
class Reader:
 def __init__(self,b): self.b=b;self.p=0
 def take(self,n): out=self.b[self.p:self.p+n];self.p+=n;return out
 def u1(self):return self.take(1)[0]
 def u2(self):return struct.unpack('>H',self.take(2))[0]
 def u4(self):return struct.unpack('>I',self.take(4))[0]
maplines=MAPPINGS.read_text().splitlines(); mapping={}; cur=None
for line in maplines:
 if not line.startswith(' ') and ' -> ' in line:
  orig,cur=line[:-1].split(' -> '); mapping[cur]={'name':orig,'members':{}}
 elif cur and ' -> ' in line:
  orig,obf=line.strip().split(' -> ');mapping[cur]['members'].setdefault(obf,[]).append(orig)

# Resolve members by descriptor, using official mappings rather than names alone.
orig_to_obf={v['name']:k for k,v in mapping.items()}
def descriptor(t):
 arr=0
 while t.endswith('[]'):arr+=1;t=t[:-2]
 d={'void':'V','boolean':'Z','byte':'B','char':'C','short':'S','int':'I','long':'J','float':'F','double':'D'}.get(t)
 return '['*arr+(d or 'L'+orig_to_obf.get(t,t).replace('.','/')+';')
for owner,m in mapping.items():
 m['resolved']={}
 for obf,values in m['members'].items():
  for original in values:
   sig=re.sub(r'^\d+:\d+:','',original)
   if '(' in sig:
    mat=re.match(r'(\S+) (.*?)\((.*?)\)',sig)
    if not mat:continue
    ret,name,args=mat.groups();desc='('+''.join(descriptor(x) for x in args.split(',') if x)+')'+descriptor(ret)
   else:
    ret,name=sig.split(' ',1);desc=descriptor(ret)
   m['resolved'][(obf,desc)]=original

def parse(data):
 r=Reader(data); assert r.u4()==0xcafebabe;r.take(4);cp=[None]; n=r.u2()
 while len(cp)<n:
  t=r.u1()
  if t==1: cp.append((t,r.take(r.u2()).decode('utf-8',errors='replace')))
  elif t in (3,4):cp.append((t,r.u4()))
  elif t in (5,6):cp.extend([(t,r.take(8).hex()),None])
  elif t in (7,8,16,19,20):cp.append((t,r.u2()))
  elif t in (9,10,11,12,17,18):cp.append((t,r.u2(),r.u2()))
  elif t==15:cp.append((t,r.u1(),r.u2()))
  else:raise ValueError(t)
 def show(i):
  v=cp[i]; t=v[0]
  if t==1:return v[1]
  if t in (3,4,5,6):return str(v[1])
  if t in (7,8,16,19,20):return show(v[1])
  if t in (9,10,11):
   owner=show(v[1]); nat=cp[v[2]]; name=show(nat[1]);desc=show(nat[2]); m=mapping.get(owner,{});resolved=m.get('resolved',{}).get((name,desc));resolved=resolved or (mapping[orig_to_obf['net.minecraft.client.renderer.RenderStateShard']]['resolved'].get((name,desc)) if owner==orig_to_obf['net.minecraft.client.renderer.RenderType'] else None)
   return owner+'.'+name+desc+' ['+m.get('name',owner)+' :: '+(resolved or '?')+']'
  if t==12:return show(v[1])+':'+show(v[2])
  if t==15:return str(v[1])+':'+show(v[2])
  if t in (17,18):return 'bootstrap '+str(v[1])+':'+show(v[2])
 r.u2();cls=show(r.u2());r.u2();r.take(r.u2()*2)
 def attrs(x):
  a=[]
  for _ in range(x.u2()):a.append((show(x.u2()),x.take(x.u4())))
  return a
 for _ in range(r.u2()):r.take(6);attrs(r)
 methods=[]
 for _ in range(r.u2()):
  flags=r.u2(); name=show(r.u2()); desc=show(r.u2()); aa=attrs(r);methods.append((name,desc,aa))
 aa=attrs(r)
 return cls,show,methods,aa
names={0:'nop',1:'aconst_null',2:'iconst_m1',3:'iconst_0',4:'iconst_1',5:'iconst_2',6:'iconst_3',7:'iconst_4',8:'iconst_5',16:'bipush',17:'sipush',18:'ldc',19:'ldc_w',20:'ldc2_w',21:'iload',25:'aload',26:'iload_0',27:'iload_1',28:'iload_2',29:'iload_3',42:'aload_0',43:'aload_1',44:'aload_2',45:'aload_3',54:'istore',58:'astore',59:'istore_0',60:'istore_1',61:'istore_2',62:'istore_3',75:'astore_0',76:'astore_1',77:'astore_2',78:'astore_3',87:'pop',89:'dup',96:'iadd',153:'ifeq',154:'ifne',159:'if_icmpeq',160:'if_icmpne',165:'if_acmpeq',166:'if_acmpne',167:'goto',172:'ireturn',176:'areturn',177:'return',178:'getstatic',179:'putstatic',180:'getfield',181:'putfield',182:'invokevirtual',183:'invokespecial',184:'invokestatic',185:'invokeinterface',186:'invokedynamic',187:'new',188:'newarray',189:'anewarray',190:'arraylength',191:'athrow',192:'checkcast',193:'instanceof',198:'ifnull',199:'ifnonnull'}
lengths={x:2 for x in [16,18,*range(21,26),*range(54,59),169,188]};lengths.update({x:3 for x in [17,19,20,132,*range(153,169),*range(178,185),187,189,192,193,198,199]});lengths.update({185:5,186:5,197:4,200:5,201:5})
cp2={19,20,*range(178,188),189,192,193,197}
def dis(code,show):
 p=0
 while p<len(code):
  o=code[p];n=lengths.get(o,1)
  if o==170:
   x=(p+4)//4*4;lo,hi=struct.unpack('>ii',code[x+4:x+12]);n=x-p+12+4*(hi-lo+1)
  elif o==171:
   x=(p+4)//4*4;nn=struct.unpack('>i',code[x+4:x+8])[0];n=x-p+8+8*nn
  elif o==196:n=6 if code[p+1]==132 else 4
  if o in cp2:operand=show(struct.unpack('>H',code[p+1:p+3])[0])
  elif o==18:operand=show(code[p+1])
  elif o in range(153,169) or o in (198,199):operand='-> '+str(p+struct.unpack('>h',code[p+1:p+3])[0])
  else:operand=code[p+1:p+n].hex()
  yield f'{p:04d}: {names.get(o,hex(o))} {operand}'
  p+=n
 assert p==len(code)


selected = ['net.minecraft.client.renderer.RenderType', 'net.minecraft.client.renderer.RenderType$CompositeState$CompositeStateBuilder', 'net.minecraft.client.renderer.RenderStateShard', 'net.minecraft.client.renderer.RenderStateShard$CullStateShard']
result = {'jar_sha256': hashlib.sha256(JAR.read_bytes()).hexdigest(), 'mappings_sha256': hashlib.sha256(MAPPINGS.read_bytes()).hexdigest(), 'class_execution': False, 'classes': []}
with zipfile.ZipFile(JAR) as z:
 for original in selected:
  c=orig_to_obf[original];data=z.read(c+'.class');cls,show,methods,aa=parse(data);row={'class':original,'obfuscated':c,'class_sha256':hashlib.sha256(data).hexdigest(),'methods':[]}
  for name,desc,attributes in methods:
   mapped=mapping[c]['resolved'].get((name,desc),'?');lines=[]
   for an,b in attributes:
    if an=='Code':
     reader=Reader(b);reader.take(4);code=reader.take(reader.u4());lines=list(dis(code,show))
   if original.endswith('CompositeStateBuilder') and name=='<init>':pass
   elif original.endswith('CullStateShard'):pass
   elif original.endswith('RenderType') and ' cutout()' in mapped:pass
   elif original.endswith('RenderType') and name=='<clinit>':
    start=next(i for i,l in enumerate(lines) if l.endswith('ldc_w cutout') or l.endswith('ldc cutout'))
    end=next(i for i in range(start,len(lines)) if 'putstatic ' in lines[i] and ' CUTOUT]' in lines[i]);lines=lines[start:end+1]
   elif original.endswith('RenderStateShard') and name=='<clinit>':
    end=next(i for i,l in enumerate(lines) if 'putstatic ' in l and 'CullStateShard CULL]' in l);lines=lines[end-4:end+6]
   else:continue
   row['methods'].append({'mapped':mapped,'method':name+desc,'instructions':lines})
  result['classes'].append(row)
OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'output':str(OUTPUT),'classes':len(result['classes'])}))
