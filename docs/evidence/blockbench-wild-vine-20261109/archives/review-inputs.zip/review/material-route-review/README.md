# Wild vine cutout policy proposal

Review-only, not applied. Keep the reviewed geometry bytes and all four authored directed faces. Change exactly the four head/body world/item wildcard `render_method` values from `alpha_test` to `alpha_test_single_sided`. AO, dimming, texture, geometry, states and all other fields remain unchanged.

Microsoft's current material documentation says alpha_test disables backface culling and alpha_test_single_sided enables it. Official Java 1.20.1 and 1.21.1 class data, read without loading/executing it, confirms vanilla cutout keeps the default CULL state. Forge's documented cutout routes world rendering to that type; its maintained 1.20.x item cutout also leaves default CULL enabled. Exact source URLs, hashes and the rejected exact-47.3.0 archive retrieval are in proposal.json.

The opposing source face is not absent: each viewpoint should see its authored forward face. With culling disabled, the reverse face may add a mirrored texel through a transparent forward texel. Front-versus-Double editor controls diagnose this separately from the proven source width mismatch.

The source Front-only scenes already preserve all four directed faces. Their matching head/body North/South/diagonal views are the bounded controls for the proposed culling policy. Native Bedrock-codec imports do not import BP materials and default to Auto/DoubleSide, so they cannot certify this route change. No native renderer, game, saved-world or LIVE claim follows.

Only bounded source excerpts, summary/provenance and the Python static inspector belong in portable evidence. Never include official client archives, the attempted Forge archive, or whole Mojang mappings. The inspector takes explicit external JAR/mapping/output paths and never executes a class.
