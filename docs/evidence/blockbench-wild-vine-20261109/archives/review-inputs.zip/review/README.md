# Wild vine source/current review preparation

Two review-only scenes cover the growing head and body. They have **not yet been opened in the GUI**. No runtime files were modified.

## Source and route

- Canonical 0.6.213 at `d42a39745f25082aa129f4d4bb823684e4174771`.
- Forge at `c4ec1880bd44cf3139d3ba744ab30bb379cf1416`, Minecraft 1.20.1. The two generated models inherit `minecraft:block/cross` and use separate head/body textures. Both blockstate JSONs have one unrotated model variant.
- Matching NeoForge generated models, blockstates and PNG bytes are identical. The official vanilla 1.21.1 parent was independently retrieved from its SHA-1/size verified archive and is byte-identical to 1.20.1. See `official-parent-source/download-record.json`.
- The Forge parent is extracted exactly from the already SHA-1/size/SHA-256 verified official 1.20.1 client archive. The archive was only read as ZIP data, never executed. Only the small parent JSON and source receipts may be included in published evidence, never either full archive.
- The locked user-upload mod JAR also contains equivalent parsed model/blockstate JSON and exact texture bytes; see `locked-author-jar-verification.json`. Current head and body use one shared geometry and distinct exact source-equal PNGs. The head's age/sheared states do not change its visual material or geometry. Material face dimming is false for both.

## Discriminating finding

The original parent has two zero-thickness, rescaled crossed planes with total X/Z spans 14.4. Current runtime uses two 16 × 16 × 0.1 slabs rotated ±45°, spanning about 11.3844 along X/Z including thickness. Independent original-JSON corner transforms confirm this difference. This is a resource mismatch awaiting actual GUI review, not yet a proposed repair.

The runtime also uses array/box UV rather than explicit per-face UV. Its Blockbench representation is deliberately retained, not silently replaced with full-range face mappings. In official Blockbench 5.2.2 both Bedrock and Free formats floor box dimensions for UV calculation: the thin Z size becomes zero for UVs. The north/south ranges are `[0,0,16,16]` and `[16,0,32,16]`. The editor's default texture mode clamps rather than repeats. Any resulting appearance must be checked against a direct native import; it cannot by itself establish Bedrock engine wrapping behavior.

## GUI queue

1. Open `scenes/wild_grapevine.bbmodel`, then `scenes/wild_grapevine_plant.bbmodel`. Original Java is world X=-20, current native is X=+20. Inspect both diagonal sides and at least one cardinal orthographic view. Record actual camera direction, not universal screen-left claims.
2. Open each matching `direct-controls/*.geo.json` through the native Bedrock codec and import its paired PNG. These are the exact runtime geometry/texture bytes. Verify the same current shape and face coverage. Direct import does not include the BP's unshaded material hint, so compare geometry/UV coverage rather than lighting.
3. Preserve actual original JPEGs and all scene bytes. Do not save or export the read-only review models. No Minecraft, BDS, LIVE, user computer, plugin, server, renderer flags or security changes are needed.

## Files and limitations

`manifest.json` pins every copied input and scene, `codec-provenance.json` records relevant official editor code paths, and `independent-bounds.json` is a separate raw-geometry corner calculation. `build_review.py` creates only this review folder; `review_codec.py` is the previously validated read-only Java/Bedrock review helper, with native box-UV cubes added explicitly here.

The fixtures do not reproduce engine cutout sidedness, texture wrapping, lighting, particles, growth, gameplay or held-item contexts. No full parity conclusion follows from the planned editor comparison. The normal 0.1 native slab thickness is disclosed, not normalized away.
