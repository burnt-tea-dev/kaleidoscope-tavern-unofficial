"""Review-only candidate from pinned original sources; never writes a repository.

All outputs remain under this script's own directory. No GUI, game, archives,
packaging, releases, runtime files, poses, or original review fixtures are changed.
"""
from pathlib import Path
import ast, base64, copy, datetime, hashlib, importlib.util, io, itertools, json, math, subprocess, sys, uuid, zipfile
from PIL import Image

H = Path(__file__).resolve().parent
P = H.parent
W = P.parent
REPO = W / 'tavern-incense-publication-20261109'
JAVA = W / 'tavern-visual-review-20261108/java-reference'
PIN = 'd42a39745f25082aa129f4d4bb823684e4174771'
FORGE = 'c4ec1880bd44cf3139d3ba744ab30bb379cf1416'
NEO = 'a1afba34981a00e89d57130d3dc8f1e64f1820a2'
MC26 = '9b8f165a4641e738e694641dd81240a0206573e1'
GEOPATH = 'runtime/RP/models/entity/wild_grapevine.geo.json'
SHA = lambda b: hashlib.sha256(b).hexdigest()

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def blob(repo, pin, path):
    return git(repo, 'show', pin + ':' + path)

def save(path, data):
    target = H / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return target

def dump(path, obj):
    return save(path, (json.dumps(obj, indent=2, ensure_ascii=False) + '\n').encode())

def read(path):
    return json.loads(path.read_bytes())

def local_input(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(W)), 'bytes': len(data), 'sha256': SHA(data)}

before_review = {str(p.relative_to(P)): SHA(p.read_bytes()) for p in P.rglob('*') if p.is_file() and H not in p.parents and '__pycache__' not in p.parts}
statuses = {str(repo): git(repo, 'status', '--porcelain') for repo in [REPO, JAVA]}
manifest = read(P / 'manifest.json')
verification = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'canonical_pin': PIN, 'runtime_tree': git(REPO, 'rev-parse', PIN+':runtime').decode().strip(), 'canonical_remote_main': git(REPO, 'ls-remote', '--heads', 'origin', 'main').decode().strip(), 'java_remote_heads': git(JAVA, 'ls-remote', '--heads', 'origin').decode().strip().splitlines()}
assert verification['runtime_tree'] == '38c5977dd6bfe14b1824734612e3c601e1e41028'
verification['canonical_remote_matches_input_pin'] = verification['canonical_remote_main'].split()[0] == PIN
verification['canonical_remote_drift_handling'] = 'Keep the assigned d42a397 input pin; report newer main without rebasing or mutating a checkout. Recheck affected blobs before integration.'
verification['original_input_checks'] = []
for path, record in manifest['inputs'].items():
    origin = record['origin']
    raw = blob(REPO if 'canonical/' in path else JAVA, origin['commit'], origin['path'])
    assert raw == (P/path).read_bytes()
    assert SHA(raw) == record['sha256'] and len(raw) == record['bytes']
    row = {'path': path, 'sha256': SHA(raw), 'original_git_bytes_equal': True}
    if 'neoforge_matching_path' in record:
        other = blob(JAVA, NEO, origin['path'])
        assert raw == other
        latest = blob(JAVA, MC26, origin['path'])
        if '/models/' in path:
            old, new = json.loads(raw), json.loads(latest)
            assert {k:v for k,v in old.items() if k != 'render_type'} == new
            row['unpublished_26_1_2'] = 'Only render_type removed; all other fields identical.'
        else:
            assert raw == latest
            row['unpublished_26_1_2'] = 'Exact bytes equal.'
        row['forge_neoforge_exact_equal'] = True
    verification['original_input_checks'].append(row)

# Read the original official client archives strictly as ZIP data.
cross_raw = (P/'official-cross-1.20.1.json').read_bytes()
assert SHA(cross_raw) == '34c9fa7f9ff7562553ee0cb74c4f9a5d9d520189d1293d1ef6177afdf5af1640'
verification['official_parent_checks'] = []
record121 = read(P/'official-parent-source/download-record.json')
for version, archive, sha1, sha256, size in [
    ('1.20.1', W/'otc-dishwasher-material-audit-20261108/evidence/java-1.20.1-client.jar', '0c3ec587af28e5a785c0b4a7b8a30f9a8f78f838', '56b71336d2b4fdffd197f56595b0da93e32a946f78f382a299b8f4b92758bb0f', 23028853),
    ('1.21.1', P/'official-parent-source/java-1.21.1-client-data.jar', record121['client']['sha1'], record121['client_sha256'], record121['client']['size'])]:
    raw = archive.read_bytes()
    assert len(raw) == size and hashlib.sha1(raw).hexdigest() == sha1 and SHA(raw) == sha256
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        parent = z.read('assets/minecraft/models/block/cross.json')
    assert parent == cross_raw
    verification['official_parent_checks'].append({'minecraft': version, 'archive_sha1': sha1, 'archive_sha256': sha256, 'archive_bytes': size, 'parent_sha256': SHA(parent), 'parent_bytes': len(parent), 'archive_executed': False})
version_raw = (P/'official-parent-source/1.21.1-version.json').read_bytes()
assert hashlib.sha1(version_raw).hexdigest() == record121['version']['sha1']
assert json.loads(version_raw)['downloads']['client'] == record121['client']
save('inputs/official-cross.json', cross_raw)
cross = json.loads(cross_raw)

# Independently check the six locked original mod-member blobs, not merely the prior report.
# The complete user-upload JAR is not present here: whole-archive identity remains the lock's assertion.
lock = json.loads(blob(REPO, PIN, 'art/source-jar.lock.json'))
prior_lock = read(P/'locked-author-jar-verification.json')
assert lock['input'] == prior_lock['input']
lock_members = {r['path']:r for r in lock['asset_files']}
verification['locked_mod_asset_checks'] = []
for row in prior_lock['files']:
    member = lock_members[row['path']]
    raw = git(REPO, 'cat-file', 'blob', member['git_blob_sha1'])
    assert len(raw) == member['bytes'] and SHA(raw) == member['sha256'] == row['sha256']
    assert raw == (P/row['saved_path']).read_bytes()
    sourcepath = ('src/main/resources/' if row['path'].endswith('.png') else 'src/generated/resources/') + row['path']
    source = blob(JAVA, FORGE, sourcepath)
    equal = raw == source if row['path'].endswith('.png') else json.loads(raw) == json.loads(source)
    assert equal
    verification['locked_mod_asset_checks'].append({'path': row['path'], 'git_blob_sha1': member['git_blob_sha1'], 'sha256': SHA(raw), 'source_equal': True, 'comparison': 'exact bytes' if row['path'].endswith('.png') else 'parsed JSON'})
verification['locked_mod_archive_limit'] = 'Complete original user-upload mod JAR not locally available; six locked original Git blob bytes independently checked, whole-archive metadata inherited from canonical lock. No publisher-checksum claim.'

# Verify the codec provenance against actual previously extracted official source bytes.
official = W/'otc-appliance-visual-prep-20261108/review-decoder-candidate/official-source'
cp = read(P/'codec-provenance.json')
verification['official_codec_source_checks'] = []
for name, row in cp['sources'].items():
    raw = (official/name).read_bytes()
    assert SHA(raw) == row['sha256'] and len(raw) == row['bytes']
    verification['official_codec_source_checks'].append({'file': name, 'sha256': SHA(raw), 'bytes': len(raw)})
verification['codec_boundary'] = 'Official Blockbench codec/source semantics, not proof of Bedrock renderer sampling, wrapping, culling, or lighting.'

before_raw = blob(REPO, PIN, GEOPATH)
before = json.loads(before_raw)
g0 = before['minecraft:geometry'][0]
save('inputs/before.geo.json', before_raw)
unused_raw = blob(REPO, PIN, 'runtime/RP/models/entity/wild_grapevine_plant.geo.json')
unused = json.loads(unused_raw)['minecraft:geometry'][0]
unused_id = unused['description']['identifier']
refs = git(REPO, 'grep', '-l', '-F', unused_id, PIN, '--', 'runtime').decode().splitlines()
assert refs == [PIN+':runtime/RP/models/entity/wild_grapevine_plant.geo.json']
verification['unused_geometry'] = {'sha256': SHA(unused_raw), 'identifier': unused_id, 'literal_reference_scan': refs, 'limit': 'Literal runtime strings only; no inferred dynamic strings.'}

# Reuse exact canonical source conversion functions. Parse/extract only six pure
# functions so no historical main entry point or repository mutation can execute.
converter_path = 'history/pre-release-0.6.29/tools/sync_post12_visuals.py'
converter_raw = blob(REPO, PIN, converter_path)
functions = {'_clean_number', '_clean_numbers', '_convert_face', '_element_box', '_element_rotation', '_convert_element'}
tree = ast.parse(converter_raw)
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in functions]
assert {node.name for node in nodes} == functions
module = ast.Module(body=nodes, type_ignores=[])
ns = {'math': math}
exec(compile(module, converter_path, 'exec'), ns)
extracted = '\n\n'.join(ast.get_source_segment(converter_raw.decode(), node) for node in nodes)+'\n'
save('inputs/canonical-conversion-functions.py.txt', extracted.encode())
verification['conversion'] = {'canonical_source_path': converter_path, 'commit': PIN, 'whole_file_sha256': SHA(converter_raw), 'extracted_functions_sha256': SHA(extracted.encode()), 'functions': sorted(functions), 'execution': 'Only extracted pure functions; no module top-level code.', 'adaptations': ['Center zero-thickness source axis at ±0.08, yielding a 0.16-model-unit open slab, a known existing conversion convention.', 'Remove the converter-generated unshaded face alias: the existing world and item wildcard already sets face_dimming=false, ambient_occlusion=0 and alpha_test; there is no named unshaded alias in either block. No BP/material edits.', 'Retain exact active a2 description and root bone fields; replace cubes only.']}
candidate = copy.deepcopy(before)
cg = candidate['minecraft:geometry'][0]
cubes = []
for e in cross['elements']:
    c = ns['_convert_element'](e, 1)
    zero = [i for i, z in enumerate(c['size']) if z == 0]
    assert len(zero) == 1
    axis = zero[0]
    c['origin'][axis] -= .08
    c['size'][axis] = .16
    for face in c['uv'].values():
        assert face.pop('material_instance') == 'unshaded'
    cubes.append(c)
cg['bones'][0]['cubes'] = cubes
assert cg['description'] == g0['description']
assert {k:v for k,v in cg['bones'][0].items() if k!='cubes'} == {k:v for k,v in g0['bones'][0].items() if k!='cubes'}
unused_without_alias = copy.deepcopy(unused['bones'][0]['cubes'])
for c in unused_without_alias:
    for f in c['uv'].values():
        f.pop('material_instance')
assert cubes == unused_without_alias
verification['unused_geometry']['regenerated_cubes_equal_after_removing_unshaded_alias'] = True
candidate_path = dump('candidate/wild_grapevine.geo.json', candidate)

# Independent directed surface math. No candidate generator or review helper calls.
# The common frame is the Java editor frame centered on X/Z=(8,8).
def add(a,b): return [x+y for x,y in zip(a,b)]
def sub(a,b): return [x-y for x,y in zip(a,b)]
def mul(a,s): return [x*s for x in a]
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def norm(a): return math.sqrt(dot(a,a))
def rotate(p, pivot, a):
    x,y,z = sub(p,pivot); a = math.radians(a)
    return add(pivot,[x*math.cos(a)+z*math.sin(a), y, -x*math.sin(a)+z*math.cos(a)])
def extent(points):
    lo=[min(p[k] for p in points) for k in range(3)]
    hi=[max(p[k] for p in points) for k in range(3)]
    return {'min':lo, 'max':hi, 'span':sub(hi,lo)}
def face_point(lo,hi,side,u,v):
    # This is the original official CubeFace.UVToLocal mapping (0..1 fractions).
    lerp=lambda a,b,t:a+(b-a)*t
    if side=='north': return [lerp(hi[0],lo[0],u),lerp(hi[1],lo[1],v),lo[2]]
    if side=='south': return [lerp(lo[0],hi[0],u),lerp(hi[1],lo[1],v),hi[2]]
    if side=='east': return [hi[0],lerp(hi[1],lo[1],v),lerp(hi[2],lo[2],u)]
    if side=='west': return [lo[0],lerp(hi[1],lo[1],v),lerp(lo[2],hi[2],u)]
    if side=='up': return [lerp(lo[0],hi[0],u),hi[1],lerp(lo[2],hi[2],v)]
    if side=='down': return [lerp(lo[0],hi[0],u),lo[1],lerp(hi[2],lo[2],v)]
    raise AssertionError(side)
NORMALS={'north':[0,0,-1],'south':[0,0,1],'east':[1,0,0],'west':[-1,0,0],'up':[0,1,0],'down':[0,-1,0]}
def java_frame(e):
    # Source coordinate translation before its original pivoted rescale/rotation.
    r=e['rotation']; assert r['axis']=='y' and r['rescale'] and r['angle']==45
    pivot=sub(r['origin'],[8,0,8]); scale=1/math.cos(math.radians(r['angle']))
    lo=sub(e['from'],[8,0,8]); hi=sub(e['to'],[8,0,8])
    for i in (0,2):
        lo[i]=pivot[i]+(lo[i]-pivot[i])*scale
        hi[i]=pivot[i]+(hi[i]-pivot[i])*scale
    return lo,hi,pivot,r['angle']
def bedrock_frame(c):
    o=c['origin'];s=c['size'];p=c.get('pivot',[0,0,0]);r=c.get('rotation',[0,0,0])
    assert r[0]==r[2]==0 and not c.get('mirror') and not c.get('inflate')
    lo=[-o[0]-s[0],o[1],o[2]];hi=add(lo,s)
    return lo,hi,[-p[0],p[1],p[2]],-r[1]
def points(frame,side):
    lo,hi,p,a=frame
    return [rotate(face_point(lo,hi,side,u,v),p,a) for u,v in [(0,0),(1,0),(1,1),(0,1)]]
def all_corners(frames):
    return [rotate(p,pivot,a) for lo,hi,pivot,a in frames for p in itertools.product(*zip(lo,hi))]
def polygon_area(p):
    a=sub(p[1],p[0]);b=sub(p[3],p[0]);cross=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
    return norm(cross)
def box_uv(c,side):
    # Explicit editor-only formula, never a Bedrock engine claim.
    x,y,z=[math.floor(v+1e-7) for v in c['size']];u,v=c['uv']
    table={'north':[z,z,x,y],'south':[2*z+x,z,x,y],'east':[0,z,z,y],'west':[z+x,z,z,y],'up':[z+x,z,-x,-z],'down':[z+2*x,0,-x,z]}
    a,b,c,d=table[side];return [a+u,b+v,a+c+u,b+d+v]
def uv_corners(rect):
    a,b,c,d=rect;return [[a,b],[c,b],[c,d],[a,d]]
def native_uv(c,side):
    f=c['uv'][side];u,v=f['uv'];du,dv=f['uv_size'];assert f.get('uv_rotation',0)==0
    return [u,v,u+du,v+dv]

jframes=[java_frame(e) for e in cross['elements']]
cframes=[bedrock_frame(c) for c in cubes]
bframes=[bedrock_frame(c) for c in g0['bones'][0]['cubes']]
audit={'method':'Independent original JSON face/UV corner transforms. Source rescale applied about original pivot; candidate decoded using official native codec X reflection/rotation signs. Four corners per directed nondegenerate source face, with center-plane geometry separated from physical ±0.08 slab offset.', 'coordinate_frame':'Centered Java/Blockbench frame; source translation (-8,0,-8); no global pose rotation or arbitrary face remap in candidate.', 'source':extent(all_corners(jframes)), 'before':extent(all_corners(bframes)), 'candidate_full_slabs':extent(all_corners(cframes)), 'faces':[]}
mapping={(0,'north'):(1,'north'),(0,'south'):(1,'south'),(1,'west'):(0,'south'),(1,'east'):(0,'north')}
center_points=[]
for i,e in enumerate(cross['elements']):
    assert set(e['faces'])==set(cubes[i]['uv'])
    for side, f in e['faces'].items():
        jp=points(jframes[i],side);cp=points(cframes[i],side)
        n=rotate(NORMALS[side],[0,0,0],jframes[i][3]);cn=rotate(NORMALS[side],[0,0,0],cframes[i][3])
        center=[sub(p,mul(n,.08)) for p in cp]
        center_points.extend(center)
        deltas=[sub(c,j) for c,j in zip(center,jp)]
        world_deltas=[sub(c,j) for c,j in zip(cp,jp)]
        br,bs=mapping[(i,side)];bc=g0['bones'][0]['cubes'][br];bp=points(bframes[br],bs)
        bn=rotate(NORMALS[bs],[0,0,0],bframes[br][3])
        j_uv=f['uv'];c_uv=native_uv(cubes[i],side);b_uv=box_uv(bc,bs)
        assert j_uv==c_uv==[0,0,16,16]
        assert norm(sub(n,cn))<1e-14 and norm(sub(n,bn))<1e-14
        assert max(map(norm,deltas))<1e-7
        assert abs(polygon_area(cp)-polygon_area(jp))<1e-6
        row={'element':i,'face':side,'normal':n,'source_corners_at_uv_00_10_11_01':jp,'candidate_surface_corners_at_same_uv':cp,'candidate_center_plane_corners':center,'source_uv_corners':uv_corners(j_uv),'candidate_uv_corners':uv_corners(c_uv),'uv_corner_max_error':0,'source_area':polygon_area(jp),'candidate_area':polygon_area(cp),'normal_error':norm(sub(n,cn)),'center_plane_corner_max_error':max(map(norm,deltas)),'surface_corner_max_error':max(map(norm,world_deltas)),'surface_signed_normal_offsets':[dot(d,n) for d in world_deltas],'before_correspondence':{'cube':br,'face':bs,'corners':bp,'normal_error':norm(sub(n,bn)),'surface_corner_max_error':max(norm(sub(b,j)) for b,j in zip(bp,jp)),'area':polygon_area(bp),'editor_only_uv_corners':uv_corners(b_uv),'editor_only_uv_corner_max_error':max(norm(sub(a,b)) for a,b in zip(uv_corners(j_uv),uv_corners(b_uv)))}}
        audit['faces'].append(row)
assert len(audit['faces'])==4
audit['candidate_center_planes']=extent(center_points)
audit['totals']={'source_nondegenerate_authored_faces':4,'candidate_nondegenerate_textured_faces':sum(len(c['uv']) for c in cubes),'candidate_omitted_slab_edge_faces':8,'all_source_face_uv_corners_compared':16,'all_source_face_normals_match':True,'maximum_center_plane_corner_error':max(f['center_plane_corner_max_error'] for f in audit['faces']),'maximum_surface_corner_error':max(f['surface_corner_max_error'] for f in audit['faces']),'maximum_uv_corner_error':0,'before_xz_span_ratio':audit['before']['span'][0]/audit['source']['span'][0], 'candidate_full_slab_span_increase_percent':(audit['candidate_full_slabs']['span'][0]/audit['source']['span'][0]-1)*100}
audit['thickness_adaptation']={'java_thickness':0,'before_thickness_model_units':0.1,'candidate_thickness_model_units':0.16,'candidate_thickness_blocks':0.01,'candidate_each_face_offset_model_units':0.08,'candidate_each_face_offset_blocks':0.005,'edge_faces':'Omitted, as in source; four authored directed faces only. Not a six-sided solid box.','rounding':'Canonical conversion rounds rescaled origin/size to 7 decimal places independently; maximum center-plane corner error measured above, not normalized away.','necessity_limit':'0.16 is an existing adaptation convention, not claimed as an engine-required minimum or exact zero-thickness Java parity.'}
dump('face-geometry-uv-audit.json',audit)

# Check world AND item routes and all visual states from exact original blobs.
routes=[]
terrain=json.loads(blob(REPO,PIN,'runtime/RP/textures/terrain_texture.json'))['texture_data']
for kind in ['wild_grapevine','wild_grapevine_plant']:
    block_raw=blob(REPO,PIN,'runtime/BP/blocks/'+kind+'.json')
    b=json.loads(block_raw)['minecraft:block'];comp=b['components']
    assert not b.get('permutations') and not comp.get('minecraft:transformation')
    for target, geometry, mats in [('world',comp['minecraft:geometry'],comp['minecraft:material_instances']),('item',comp['minecraft:item_visual']['geometry'],comp['minecraft:item_visual']['material_instances'])]:
        assert geometry['identifier']==cg['description']['identifier'] and list(mats)==['*']
        mat=mats['*'];assert mat['render_method']=='alpha_test' and mat['face_dimming'] is False and mat['ambient_occlusion']==0
        path='runtime/RP/'+terrain[mat['texture']]['textures']+'.png'
        raw=blob(REPO,PIN,path)
        src=blob(JAVA,FORGE,'src/main/resources/assets/kaleidoscope_tavern/textures/block/plant/'+kind+'.png')
        assert raw==src
        routes.append({'kind':kind,'target':target,'geometry':geometry,'material':mat,'texture_sha256':SHA(raw),'source_png_exact':True,'transformation':comp.get('minecraft:transformation'),'permutations':b.get('permutations',[]),'block_json_sha256':SHA(block_raw)})
    save('inputs/'+kind+'.png',src)
    resolved=copy.deepcopy(cross)
    child=json.loads(blob(JAVA,FORGE,'src/generated/resources/assets/kaleidoscope_tavern/models/block/plant/'+kind+'.json'))
    resolved['textures'].update(child['textures'])
    dump('inputs/resolved-'+kind+'.json',resolved)
    save('direct-controls/before/'+kind+'.geo.json',before_raw)
    save('direct-controls/before/'+kind+'.png',src)
    save('direct-controls/candidate/'+kind+'.geo.json',candidate_path.read_bytes())
    save('direct-controls/candidate/'+kind+'.png',src)
dump('route-verification.json',routes)

# Existing adapter bytes preserved verbatim. Explicit scene-only shade annotation
# reflects unchanged wildcard material; no hidden geometry, UV, or pose correction.
helper_raw=(P/'review_codec.py').read_bytes()
save('review_codec.py',helper_raw)
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('wild_review_codec',H/'review_codec.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
C.OUT=H/'scenes';C.OUT.mkdir(exist_ok=True)
# Stable IDs make regeneration deterministic while using the unchanged helper.
counter=itertools.count()
C.uid=lambda:str(uuid.uuid5(uuid.NAMESPACE_URL,'wild-vine-review-20261109/'+str(next(counter))))

def add_before(scene,texture,offset):
    tex=scene.texture(texture);node=scene.group('BEFORE active a2 | world X='+str(offset[0]),offset)
    for i,c in enumerate(g0['bones'][0]['cubes']):
        lo,hi,p,a=bedrock_frame(c)
        faces={s:{'uv':[0,0,0,0],'texture':tex} for s in C.SIDES}
        scene.cube('BEFORE native box UV cube '+str(i),add(lo,offset),add(hi,offset),faces,add(p,offset),[0,a,0],node)
        scene.j['elements'][-1].update(box_uv=True,uv_offset=c['uv'][:],shade=False)

scenes=[]
for kind in ['wild_grapevine','wild_grapevine_plant']:
    texture=H/'inputs'/f'{kind}.png';source=H/'inputs'/f'resolved-{kind}.json'
    for mode in ['source-before-after','source-after']:
        scene=C.Scene(kind+' | '+mode+' | REVIEW ONLY')
        scene.j['resolution']={'width':16,'height':16}
        source_x=-32 if mode=='source-before-after' else -20
        candidate_x=32 if mode=='source-before-after' else 20
        scene.java(source,texture,[source_x,0,0])
        scene.j['groups'][0]['name']='SOURCE official cross | world X='+str(source_x)
        if mode=='source-before-after':add_before(scene,texture,[0,0,0])
        n=len(scene.j['elements'])
        scene.bedrock(candidate_path,texture,[candidate_x,0,0],name='AFTER candidate a2 | world X='+str(candidate_x))
        for e in scene.j['elements'][n:]:
            e['name']='AFTER candidate '+e['name'];e['shade']=False
        name=kind+'-'+mode+'.bbmodel';scene.save(name)
        scenes.append({'path':'scenes/'+name,'sha256':SHA((C.OUT/name).read_bytes()),'source_world_x':source_x,'before_world_x':0 if mode=='source-before-after' else None,'candidate_world_x':candidate_x,'gui_reviewed':False})
        # Independent serialized scene checks, including all embedded source PNG bytes.
        result=read(C.OUT/name)
        for t in result['textures']:
            assert base64.b64decode(t['source'].split(',',1)[1])==texture.read_bytes()
        js=result['elements'][:2];cs=result['elements'][-2:]
        for i,(je,ce) in enumerate(zip(js,cs)):
            for field,expected in [('from',cframes[i][0]),('to',cframes[i][1]),('origin',cframes[i][2])]:
                assert all(abs(ce[field][k]-[candidate_x,0,0][k]-expected[k])<1e-12 for k in range(3))
            assert ce['rotation']==je['rotation']==[0,45,0]
            assert ce['shade'] is False and je['shade'] is False
            for side in C.SIDES:
                a,b=je['faces'][side],ce['faces'][side]
                assert (a['texture'] is None)==(b['texture'] is None)
                if a['texture'] is not None:assert a['uv']==b['uv'] and a.get('rotation',0)==b.get('rotation',0)
        if mode=='source-before-after':
            for e,c in zip(result['elements'][2:4],g0['bones'][0]['cubes']):assert e['box_uv'] is True and e['uv_offset']==c['uv']

assert all(git(repo,'status','--porcelain')==statuses[str(repo)] for repo in [REPO,JAVA])
after_review={str(p.relative_to(P)):SHA(p.read_bytes()) for p in P.rglob('*') if p.is_file() and H not in p.parents and '__pycache__' not in p.parts}
assert before_review==after_review
verification['original_review_files_unchanged']=True
verification['repository_status_unchanged']=True
verification['review_helper']={'sha256':SHA(helper_raw),'bytes_equal_existing':True,'permitted_explicit_caller_annotations':['Deterministic UUID hook only, no geometry/UV formula changes.','Before scene retains original array/box UV, including official editor behavior.','Candidate shade=false mapped from existing unchanged material wildcard.']}
dump('independent-source-verification.json',verification)
summary={'status':'REVIEW-ONLY CANDIDATE; actual GUI pending; no runtime integration', 'candidate':'candidate/wild_grapevine.geo.json','candidate_sha256':SHA(candidate_path.read_bytes()),'candidate_bytes':len(candidate_path.read_bytes()),'canonical_pin':PIN,'runtime_tree':verification['runtime_tree'],'scenes':scenes,'face_audit':audit['totals'],'only_proposed_runtime_change':GEOPATH,'preserved':['geometry.kt_assets_a2.wild_grapevine identity','format version, texture resolution, visible bounds, root name/pivot and non-cube fields','all world/item routes, state behavior, textures, accepted transformations and poses','selection/collision boxes, growth, scripts, drops, version and baseline files'],'unverified':['Actual GUI review of before/candidate/direct-native controls','Bedrock client cutout sidedness/wrapping/lighting and held/item contexts','Whether 0.16 thickness is perceptually preferable to another thin-slab convention; it is disclosed, not asserted source-exact','Unpublished Minecraft26.1.2 vanilla parent/renderer'],'original_review_files_unchanged':True,'repository_status_unchanged':True}
summary.update(independent_validation='independent-validation.json', gui_handoff='README.md', canonical_remote_observed=verification['canonical_remote_main'].split()[0], canonical_remote_drift='Assigned d42a397 inputs retained; recheck affected blobs before any later integration.')
dump('manifest.json',summary)
dump('artifact-sha256.json',{str(p.relative_to(H)):{'sha256':SHA(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(H.rglob('*')) if p.is_file() and p.name!='artifact-sha256.json'})
print(json.dumps(summary,indent=2))
