# Wild grapevine: independent review-only candidate

**Ready for the parent’s actual GUI review. No runtime integration, release, build, version change, game process, or desktop action was performed.** All writes are inside this new subfolder. Original before scenes/manifests remain byte-identical.

## Result and exact candidate

- Candidate: `candidate/wild_grapevine.geo.json`, SHA-256 `e7e8c23f421aba7d8082c6952d6599bc5fb99231c9a656ff1566b4303cbd0d0b`, 2488 bytes.
- Assigned input base: canonical `d42a39745f25082aa129f4d4bb823684e4174771`, runtime tree `38c5977dd6bfe14b1824734612e3c601e1e41028`.
- The fresh remote check observed newer main `1bd3d70f94d142630b05a655008a296bc0bcd387`. The assigned inputs were retained; **recheck the affected blobs before any later integration**. No rebase or checkout mutation was performed.
- Java’s original rescaled cross spans 14.4 model units in X/Z. Current active slabs span 11.3844191771, only 79.0585% of the source span. This geometric mismatch is independent of texture sampling.
- The candidate’s center planes reproduce all four directed authored surfaces and UV mappings, within 0.000000050914 model units due to the established seven-decimal conversion rounding. All 16 directed face UV corners match exactly. The independent validator also checks all 1024 texel centers.
- **Thickness is an explicit adaptation:** source planes have zero thickness; candidate open slabs are 0.16 model units (0.01 block), centered ±0.08 (±0.005 block) around each source plane. Their full X/Z extent is approximately 14.513137157, 0.7857% larger than the zero-thickness source. The four outer surfaces are not asserted geometrically identical to source. No cap/edge faces are added.

## Source-backed construction and preserved scope

`build_candidate_review.py` independently retrieves the exact pinned Git blobs and rechecks source/canonical images, models, blockstates, routes, official archives, and existing codec source hashes. It extracts only the six pure conversion functions from the canonical historical `sync_post12_visuals.py` and applies them to the official vanilla cross parent. It does not execute that script’s top level or copy the unused a3 geometry as its input. The resulting cubes independently equal the unused a3 cubes after the material alias adjustment below.

The converter correctly bakes `rescale=true` into bounds before rotation. Source `[8,8,8]` becomes Bedrock pivot `[0,8,0]`. The X reflection and Y sign change yield native rotation `[0,-45,0]` on both the X- and Z-aligned source elements. These are coordinate conversions, not arbitrary new block or item poses. The first slab’s size is `[20.3646753,16,0.16]`; the second is `[0.16,16,20.3646753]`.

Only the active geometry’s cubes would change. The a2 identifier, root bone name/pivot, description, visible bounds, texture size, format version, BP world/item routes, state behavior, PNG bytes, selection/collision boxes, growth, drops and all accepted transforms/poses are preserved. Both growing head and body, including their item visuals, use this same a2 geometry.

Java source disables face shading and ambient occlusion and requests cutout. Both current BP wildcard materials already use `alpha_test`, `ambient_occlusion=0`, `face_dimming=false`. The converter’s named `unshaded` face aliases are therefore removed from this candidate, so the existing wildcard resolves every face. No nonexistent alias, new material, BP change, or altered lighting policy is introduced. The Free scene maps that existing wildcard to `shade=false` explicitly; native direct imports do not have BP material settings and are geometry/UV controls, not lighting controls.

## GUI handoff

1. Open `scenes/wild_grapevine-source-before-after.bbmodel`, then the corresponding `wild_grapevine_plant` file. Outliner identities are explicit: SOURCE at world X=-32, BEFORE at X=0, AFTER at X=+32. Camera orientation can reverse their screen order; record actual orientation.
2. Use the matching `*-source-after.bbmodel` close pairs when needed. SOURCE is X=-20, AFTER X=+20. Inspect both diagonal sides and cardinal orthographic views; verify full sprite orientation and coverage for both head and body.
3. Open both matching `direct-controls/before/*.geo.json` files with the native Bedrock codec and their paired PNGs, and then the corresponding `direct-controls/candidate/` controls. The before geometry is byte-exact original runtime. Candidate control bytes equal the candidate hash above. Compare shape and face/UV coverage with Free scenes. Do not infer native engine behavior from the editor.
4. Preserve original screenshots and these exact scene bytes; do not save/export the read-only controls. No need to launch Minecraft/BDS, alter a renderer/security setting, load plugins, or touch runtime files for this review.

## Evidence and limitations

- `face-geometry-uv-audit.json`: exhaustive directed source/candidate corner coordinates, normals, areas and UVs, plus the mapped before faces. Center-plane error and ±0.08 physical displacement are separate. Before box UV values are explicitly **editor-only**, never an engine-wrap claim.
- `independent-validation.json`: separate complex-number implementation checks four directed faces at 16 corners and 1024 texel centers, and rejects targeted geometry/UV/material/identity regressions.
- `independent-source-verification.json`: exact source/Forge/NeoForge/canonical blob checks; official 1.20.1 and 1.21.1 client archives rehashed and read only as ZIP data; official cross parents are identical 884-byte assets. Six locked mod-member Git blobs are verified against their source and canonical lock. The complete uploaded mod JAR was not locally available, so whole-archive identity is inherited from the lock, not independently rehashed here.
- `route-verification.json`: both head/body and world/item geometry/material/texture routes. `manifest.json` pins GUI scene identities; `artifact-sha256.json` pins deliverables.
- `review_codec.py` is byte-identical to the existing helper. Caller annotations are limited to deterministic UUIDs, original box UV handling for BEFORE, and the explicit unchanged material’s shading hint. No silent adapter changes.
- Minecraft 26.1.2 children remove only `render_type`; all other model fields and related states/textures agree. Its vanilla parent/renderer was not checked and is not covered.

This is not GUI acceptance, Bedrock renderer parity, or a gameplay/held-item test. Engine alpha-test sidedness, box-UV sampling/wrapping, lighting and item contexts remain outside this review. The 0.16 convention is not claimed as a mandatory minimum or proven preferable to every thinner option. Subsequent source changes require revalidation of affected inputs before integration.
