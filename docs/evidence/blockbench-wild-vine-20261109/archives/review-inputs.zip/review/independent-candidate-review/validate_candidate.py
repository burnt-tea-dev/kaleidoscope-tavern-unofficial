"""Separate review validator: read artifacts only, except its local JSON result.

Does not import or rerun the candidate builder, historical converter, or scene helper.
Complex-number rotations independently check directed, UV-corresponding surfaces.
"""
from pathlib import Path
import cmath, copy, hashlib, itertools, json, math
H=Path(__file__).resolve().parent
read=lambda p:json.loads((H/p).read_text())
candidate=read('candidate/wild_grapevine.geo.json')
source=read('inputs/official-cross.json')
before=read('inputs/before.geo.json')
routes=read('route-verification.json')

def sample(lo,hi,face,u,v):
    if face=='north':return [hi[0]+(lo[0]-hi[0])*u,hi[1]+(lo[1]-hi[1])*v,lo[2]]
    if face=='south':return [lo[0]+(hi[0]-lo[0])*u,hi[1]+(lo[1]-hi[1])*v,hi[2]]
    if face=='west':return [lo[0],hi[1]+(lo[1]-hi[1])*v,lo[2]+(hi[2]-lo[2])*u]
    if face=='east':return [hi[0],hi[1]+(lo[1]-hi[1])*v,hi[2]+(lo[2]-hi[2])*u]
    raise AssertionError('Unexpected source/candidate face: '+face)

def transform(p,pivot,degrees):
    q=complex(p[0]-pivot[0],p[2]-pivot[2])*cmath.exp(complex(0,-math.radians(degrees)))
    return [pivot[0]+q.real,p[1],pivot[2]+q.imag]

def dist(a,b):return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))

def inspect(doc):
    assert doc.keys()==before.keys() and doc['format_version']==before['format_version']
    assert len(doc['minecraft:geometry'])==1
    geo=doc['minecraft:geometry'][0];old=before['minecraft:geometry'][0]
    assert geo['description']==old['description']
    assert len(geo['bones'])==1
    root=geo['bones'][0]
    assert {k:v for k,v in root.items() if k!='cubes'}=={k:v for k,v in old['bones'][0].items() if k!='cubes'}
    assert len(root['cubes'])==len(source['elements'])==2
    rows=[]
    for index,(cube,e) in enumerate(zip(root['cubes'],source['elements'])):
        assert set(cube)=={'origin','size','pivot','rotation','uv'}
        assert set(cube['uv'])==set(e['faces'])
        assert cube['pivot']==[0,8,0] and cube['rotation']==[0,-45,0]
        zero=[i for i,(a,b) in enumerate(zip(e['from'],e['to'])) if a==b]
        assert len(zero)==1
        axis=zero[0];assert cube['size'][axis]==.16
        lo=[-cube['origin'][0]-cube['size'][0],cube['origin'][1],cube['origin'][2]]
        hi=[lo[i]+cube['size'][i] for i in range(3)]
        pivot=[-cube['pivot'][0],cube['pivot'][1],cube['pivot'][2]]
        # Remove only the disclosed slab thickness, keeping rounding/asymmetry.
        center=(lo[axis]+hi[axis])/2
        lo[axis]=hi[axis]=center
        source_pivot=e['rotation']['origin']
        assert e['rotation']['rescale'] is True and e['rotation']['axis']=='y'
        factor=1/math.cos(math.radians(e['rotation']['angle']))
        for face,entry in e['faces'].items():
            f=cube['uv'][face]
            assert set(f)=={'uv','uv_size'} and f['uv']==entry['uv'][:2] and f['uv_size']==[entry['uv'][2]-entry['uv'][0],entry['uv'][3]-entry['uv'][1]]
            # Corners plus every pixel center of the exact 16x16 source map.
            max_error=0
            samples=[(0,0),(1,0),(1,1),(0,1)]+[((u+.5)/16,(v+.5)/16) for u,v in itertools.product(range(16),repeat=2)]
            for u,v in samples:
                p=sample(e['from'],e['to'],face,u,v)
                for i in (0,2):p[i]=source_pivot[i]+(p[i]-source_pivot[i])*factor
                jp=transform(p,source_pivot,e['rotation']['angle']);jp[0]-=8;jp[2]-=8
                cp=transform(sample(lo,hi,face,u,v),pivot,-cube['rotation'][1])
                max_error=max(max_error,dist(jp,cp))
            assert max_error<1e-7, (index,face,max_error)
            rows.append({'element':index,'face':face,'samples':len(samples),'maximum_center_plane_sample_error':max_error})
    for row in routes:
        assert row['geometry']['identifier']==geo['description']['identifier']
        assert row['material']['face_dimming'] is False and row['material']['ambient_occlusion']==0 and row['material']['render_method']=='alpha_test'
        assert row['transformation'] is None and row['permutations']==[] and row['source_png_exact']
    return rows

rows=inspect(candidate)
mutations={
    'missing_rescale_width':lambda g:g['bones'][0]['cubes'][0]['size'].__setitem__(0,14.4),
    'old_simplified_width':lambda g:g['bones'][0]['cubes'][0]['size'].__setitem__(0,16),
    'moved_plane':lambda g:g['bones'][0]['cubes'][0]['origin'].__setitem__(2,.02),
    'wrong_rotation_sign':lambda g:g['bones'][0]['cubes'][0]['rotation'].__setitem__(1,45),
    'wrong_pivot':lambda g:g['bones'][0]['cubes'][0]['pivot'].__setitem__(0,1),
    'mirrored_uv':lambda g:g['bones'][0]['cubes'][0]['uv']['north']['uv_size'].__setitem__(0,-16),
    'offset_reverse_uv':lambda g:g['bones'][0]['cubes'][0]['uv']['south']['uv'].__setitem__(0,16),
    'unmapped_material_alias':lambda g:g['bones'][0]['cubes'][0]['uv']['north'].__setitem__('material_instance','unshaded'),
    'added_slab_cap_face':lambda g:g['bones'][0]['cubes'][0]['uv'].__setitem__('up',{'uv':[0,0],'uv_size':[16,16]}),
    'removed_reverse_face':lambda g:g['bones'][0]['cubes'][0]['uv'].pop('south'),
    'box_uv_reintroduced':lambda g:g['bones'][0]['cubes'][0].__setitem__('uv',[0,0]),
    'inactive_a3_identity':lambda g:g['description'].__setitem__('identifier','geometry.kt_assets_a3.wild_grapevine_plant'),
    'undisclosed_thickness':lambda g:g['bones'][0]['cubes'][0]['size'].__setitem__(2,.1),
}
results={}
for name,fn in mutations.items():
    broken=copy.deepcopy(candidate);fn(broken['minecraft:geometry'][0])
    try:inspect(broken)
    except (AssertionError,TypeError):results[name]='rejected'
    else:raise AssertionError('Accepted broken candidate: '+name)
report={'candidate_sha256':hashlib.sha256((H/'candidate/wild_grapevine.geo.json').read_bytes()).hexdigest(),'method':'Independent complex-number transforms; no generator, converter or scene helper imported. Every declared face checked at four UV corners and all 256 texel centers after explicit slab center projection.','face_samples':rows,'total_corner_samples':16,'total_texel_center_samples':1024,'mutations':results,'gui_reviewed':False,'minecraft_rendered':False}
(H/'independent-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
