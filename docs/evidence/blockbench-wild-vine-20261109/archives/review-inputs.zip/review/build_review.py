"""Bounded read-only wild-vine source/current review. No runtime writes or game."""
from pathlib import Path
import base64, copy, hashlib, io, json, math, subprocess
from PIL import Image
import review_codec as C

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ROOT = WORK / 'tavern-incense-publication-20261109'
JAVA = WORK / 'tavern-visual-review-20261108/java-reference'
PIN = 'd42a39745f25082aa129f4d4bb823684e4174771'
FORGE = 'c4ec1880bd44cf3139d3ba744ab30bb379cf1416'
NEO = 'a1afba34981a00e89d57130d3dc8f1e64f1820a2'
C.OUT = HERE / 'scenes'
C.OUT.mkdir(exist_ok=True)
SHA = lambda b: hashlib.sha256(b).hexdigest()
inputs = {}

def git(repo, spec):
    return subprocess.check_output(['git', '-C', str(repo), 'show', spec])

def save_input(path, data, origin):
    p = HERE / 'inputs' / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    inputs[str(p.relative_to(HERE))] = {'sha256': SHA(data), 'bytes': len(data), 'origin': origin}
    return p

def native(path):
    return save_input('canonical/' + path, git(ROOT, PIN + ':' + path), {'repository': 'burnt-tea-dev/kaleidoscope-tavern-unofficial', 'commit': PIN, 'path': path})

def source(path):
    data = git(JAVA, FORGE + ':' + path)
    p = save_input('forge/' + path, data, {'commit': FORGE, 'path': path})
    other = subprocess.run(['git', '-C', str(JAVA), 'show', NEO + ':' + path], capture_output=True)
    record = inputs[str(p.relative_to(HERE))]
    record['neoforge_matching_path'] = {'commit': NEO, 'present': other.returncode == 0}
    if other.returncode == 0:
        record['neoforge_matching_path'].update(sha256=SHA(other.stdout), bytes_equal=other.stdout == data)
        if path.endswith('.json'):
            record['neoforge_matching_path']['json_equal'] = json.loads(other.stdout) == json.loads(data)
        elif path.endswith('.png'):
            a, b = Image.open(io.BytesIO(data)).convert('RGBA'), Image.open(io.BytesIO(other.stdout)).convert('RGBA')
            record['neoforge_matching_path']['rgba_equal'] = a.size == b.size and a.tobytes() == b.tobytes()
    return p

cross_path = HERE / 'official-cross-1.20.1.json'
cross_bytes = cross_path.read_bytes()
assert SHA(cross_bytes) == '34c9fa7f9ff7562553ee0cb74c4f9a5d9d520189d1293d1ef6177afdf5af1640'
cross = json.loads(cross_bytes)
cross_receipt = {'asset': 'assets/minecraft/models/block/cross.json', 'asset_sha256': SHA(cross_bytes), 'minecraft': '1.20.1', 'official_client_url': 'https://piston-data.mojang.com/v1/objects/0c3ec587af28e5a785c0b4a7b8a30f9a8f78f838/client.jar', 'client_sha1': '0c3ec587af28e5a785c0b4a7b8a30f9a8f78f838', 'client_sha256': '56b71336d2b4fdffd197f56595b0da93e32a946f78f382a299b8f4b92758bb0f', 'client_bytes': 23028853, 'archive_executed': False, 'scope': 'Exact Forge 1.20.1 parent; official NeoForge-targeted vanilla1.21.1 parent independently retrieved and byte-identical.'}
parent_1211 = json.loads((HERE/'official-parent-source/download-record.json').read_text())
assert (HERE/'official-parent-source/cross-1.21.1.json').read_bytes() == cross_bytes
assert parent_1211['parent_identical_1_20_1'] is True
cross_receipt['minecraft_1_21_1_verification'] = parent_1211
terrain = json.loads(native('runtime/RP/textures/terrain_texture.json').read_text())['texture_data']
gp = native('runtime/RP/models/entity/wild_grapevine.geo.json')
geo = json.loads(gp.read_text())['minecraft:geometry'][0]
assert geo['description']['texture_width'] == geo['description']['texture_height'] == 16
assert len(geo['bones']) == 1 and geo['bones'][0]['pivot'] == [0,0,0]

def add_native_box(scene, texture, offset, label):
    """Preserve native box UV. Free and Bedrock 5.2.2 both floor box sizes."""
    tex = scene.texture(texture)
    node = scene.group(label, offset)
    add = lambda v: [v[k] + offset[k] for k in range(3)]
    for i, cube in enumerate(geo['bones'][0]['cubes']):
        assert not cube.get('mirror') and not cube.get('inflate')
        assert cube['uv'] == [0,0]
        o, z = cube['origin'], cube['size']
        fr = [-o[0]-z[0],o[1],o[2]]
        to = [fr[k]+z[k] for k in range(3)]
        p, r = cube.get('pivot',[0,0,0]), cube.get('rotation',[0,0,0])
        faces = {s:{'uv':[0,0,0,0],'texture':tex} for s in C.SIDES}
        scene.cube('Native box UV '+str(i),add(fr),add(to),faces,add([-p[0],p[1],p[2]]),[-r[0],-r[1],r[2]],node)
        e = scene.j['elements'][-1]
        e.update(box_uv=True,uv_offset=cube['uv'][:],shade=False)

rows=[]
for kind in ['wild_grapevine','wild_grapevine_plant']:
    model_path=source('src/generated/resources/assets/kaleidoscope_tavern/models/block/plant/'+kind+'.json')
    states_path=source('src/generated/resources/assets/kaleidoscope_tavern/blockstates/'+kind+'.json')
    model=json.loads(model_path.read_text());states=json.loads(states_path.read_text())
    assert model['parent']=='minecraft:block/cross'
    assert model['render_type']=='minecraft:cutout'
    assert states=={'variants':{'':{'model':'kaleidoscope_tavern:block/plant/'+kind}}}
    jp=source('src/main/resources/assets/kaleidoscope_tavern/textures/block/plant/'+kind+'.png')
    bp=native('runtime/BP/blocks/'+kind+'.json'); block=json.loads(bp.read_text())['minecraft:block']
    assert not block.get('permutations')
    comp=block['components'];assert comp['minecraft:geometry']['identifier']==geo['description']['identifier']
    assert not comp.get('minecraft:transformation')
    mat=comp['minecraft:material_instances']['*']
    assert mat['face_dimming'] is False and mat['render_method']=='alpha_test'
    tp=native('runtime/RP/'+terrain[mat['texture']]['textures']+'.png')
    a,b=Image.open(jp).convert('RGBA'),Image.open(tp).convert('RGBA')
    assert a.size==b.size==(16,16) and a.tobytes()==b.tobytes()
    resolved=copy.deepcopy(cross);resolved['textures'].update(model['textures'])
    rp=HERE/'inputs'/('resolved-'+kind+'.json');rp.write_text(json.dumps(resolved,indent=2)+'\n')
    s=C.Scene('Wild vine review | '+kind+' | source -X / current +X')
    s.j['resolution']={'width':16,'height':16}
    s.java(rp,jp,[-20,0,0]);add_native_box(s,tp,[20,0,0],'Current runtime +X')
    name=kind+'.bbmodel';s.save(name)
    # Native direct-import control, without altering its geometry or material bytes.
    control=HERE/'direct-controls';control.mkdir(exist_ok=True)
    (control/(kind+'.geo.json')).write_bytes(gp.read_bytes());(control/(kind+'.png')).write_bytes(tp.read_bytes())
    rows.append({'kind':kind,'scene':'scenes/'+name,'scene_sha256':SHA((C.OUT/name).read_bytes()),'block_states':block['description'].get('states',{}),'all_states_share_visual':True,'texture_rgba_equal':True,'java_source_span_xz':14.4,'native_full_slab_span_xz':16/math.sqrt(2)+.1/math.sqrt(2),'native_main_sheet_span_xz':16/math.sqrt(2),'native_sheet_thickness':.1,'gui_reviewed':False})

report={'runtime_pin':PIN,'runtime_version':'0.6.213','source_pin':FORGE,'source_parent':cross_receipt,'scenes':rows,'inputs':inputs,'finding':'The authored 1.20.1/1.21.1 cross parent uses 14.4-wide axes after rescale; the current runtime slabs span about 11.3844 in X/Z. This is a confirmed resource geometry difference, not yet a GUI defect acceptance or a proposed runtime patch.','box_uv_preview_contract':{'application':'Blockbench5.2.2','native_and_free_box_uv_float_size':False,'size_rounding':'floor(size+1e-7) as official Cube.size','native_box_texture_size':[16,16],'effective_dimensions':[16,16,0],'north_uv':[0,0,16,16],'south_uv':[16,0,32,16],'other_uvs':'thin side/end faces become zero-area UV ranges in the editor. Engine box UV sampling and culling are not certified.'},'limitations':['Prepared only; GUI not yet run.','Source-parent retrieval proves Forge1.20.1 and NeoForge1.21.1, not all Minecraft versions.','No Minecraft client process, BDS, LIVE, user machine or runtime edits.','Current native slab thickness0.1 is preserved and disclosed.','Free scene follows official box-UV representation, but direct native control still needs comparison.','Material face_dimming is mapped to editor shade; shader/alpha-test/double-sided runtime behavior untested.']}
(HERE/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'scenes':len(rows),'tracked_inputs':len(inputs),'finding':report['finding']},indent=2))
