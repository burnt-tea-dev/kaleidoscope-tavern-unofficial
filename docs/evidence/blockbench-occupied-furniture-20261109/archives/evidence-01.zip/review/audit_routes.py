"""Bounded independent route/PoseStack audit using the repository's existing
source-contract checker functions, without running its broad history checks.
No builder import, game, GUI or service operations.
"""
from pathlib import Path
import ast,json,hashlib,itertools,math
H=Path(__file__).resolve().parent;R=H/'inputs/current';S=H/'inputs/forge';read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
path=R/'tools/check_storage_rendering.py';tree=ast.parse(path.read_text());names=['rx','ry','add','mul','facing','java_point','bedrock_point','check_pose_writer'];code=ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in names],type_ignores=[]);exec(compile(code,str(path),'exec'))
contract=read(R/'data/storage-render-source.json');verified=[]
for p,h in contract['sources'].items():
 if '/client/render/'in p:
  b=(S/p).read_bytes().replace(b'\r\n',b'\n');assert sha(b)==h;verified.append(p)
snap=read(H/'pose-snapshot.json');animations=read(R/'runtime/RP/animations/runtime_storage_bottle.animation.json')['animations'];geo=read(R/'runtime/RP/models/entity/wine_1.geo.json')['minecraft:geometry'][0];gindex=read(H/'geometry-index.json');shared=(R/'runtime/BP/scripts/bedrock/storage-visual-maintenance.js').read_text();owners=['holder','cellar_cabinet','tilted_rack','circular_rack','bar_cabinet'];routes={};clients={}
for owner in owners:
 client=read(R/f'runtime/RP/entity/runtime_{owner}_bottle_visual.entity.json')['minecraft:client_entity']['description'];clients[owner]=client;adapter=(R/f"runtime/BP/scripts/bedrock/{owner.replace('_','-')}.js").read_text();check_pose_writer(owner,adapter,shared);rc=read(R/f'runtime/RP/render_controllers/runtime_{owner}.render_controllers.json')['render_controllers'];ctrl=rc[client['render_controllers'][0]]
 prop='holder_kind'if owner=='holder'else'storage_kind'
 assert ctrl['geometry']=="Array.kind[q.property('kaleidoscope_tavern:"+prop+"') - 1]";assert ctrl['textures']==["Array.kind[q.property('kaleidoscope_tavern:"+prop+"') - 1]"]
 assert ctrl['materials']==[{'*':"q.property('kaleidoscope_tavern:"+prop+"') == 6 ? Material.luminous_bride : Material.default"}]
 table=snap['compact'if owner in ['holder','cellar_cabinet']else'general'];assert len(ctrl['arrays']['geometries']['Array.kind'])==len(table)
 for kind,name in [(6,'luminous_bride'),(15,'wine')]+([(16,'brandy')]if owner in ['bar_cabinet','circular_rack']else[]):
  assert table[kind-1]==name;assert ctrl['arrays']['geometries']['Array.kind'][kind-1]=='Geometry.kind_'+str(kind);assert ctrl['arrays']['textures']['Array.kind'][kind-1]=='Texture.kind_'+str(kind);assert client['geometry']['kind_'+str(kind)].endswith(name+'_1')
 routes[owner]={'active_chain':[f'runtime/BP/blocks/{owner}.json',f"runtime/BP/scripts/bedrock/{owner.replace('_','-')}.js",f"runtime/BP/scripts/core/{owner.replace('_','-')}.js",client['identifier'],client['render_controllers'][0]],'geometry_owner':'helper selected count1, not block occupancy mesh','pitch_owner':'RP root animation only; setRotation forces x=0','scale':client['scripts']['scale'],'materials':client['materials'],'kind_index_count':len(table),'kind6':'luminous_bride','kind15':'wine','controller_index_and_material_verified':True}
clients['glass_bar_cabinet']=clients['bar_cabinet'];routes['glass_bar_cabinet']={'same_helper_and_layout_owner':'bar_cabinet','distinct_body':'runtime/BP/blocks/glass_bar_cabinet.json'}
maximum=0.;count=0
for case in snap['poses']:
 for p in itertools.product([6,10],[0,16],[6,10]):
  expected=java_point(p,case,contract);actual=bedrock_point([8-p[0],p[1],p[2]-8],case,clients[case['family']],geo,animations);error=max(abs(x-y)for x,y in zip(expected,actual));assert error<1e-12;maximum=max(maximum,error);count+=1
block=read(R/'runtime/BP/blocks/glassware_holder.json')['minecraft:block'];glass=(S/'src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/client/render/block/GlasswareHolderBlockEntityRender.java').read_text();assert 'translate(-0.25, 0.76, 0.75)'in glass and'translate(0.5 * (i % 2), 0, 0.5 * (i / 2))'in glass and'Axis.XN.rotationDegrees(180)'in glass and'RenderType.cutout()'in glass
routes['glassware_holder']={'active_chain':['runtime/BP/scripts/bedrock/furniture.js','runtime/BP/scripts/core/hit-basis.js','runtime/BP/blocks/glassware_holder.json','runtime/RP/models/entity/runtime_glassware_holder.geo.json'],'helper_entity':False,'occupancy_owner':'four BP glass_slot_N states and bone_visibility, not storage_bottle animation','source_material':'RenderType.cutout explicitly','native_materials':block['components']['minecraft:material_instances'],'geometry_virtual_uv':[64,64],'native_glass_png_actual_dimensions':[32,32],'world_slot_check':'glassware-world-slot-audit.json','editor_reference_warning':'BB decode negates X; original bone quadrant mapping is an independently pinned client convention. Sparse fixture is not rendered-client world proof.'}
report={'routes':routes,'source_renderer_hashes_verified':verified,'pose_cases':len(snap['poses']),'ideal_constant_vertex_comparisons':count,'max_coordinate_error_blocks':maximum,'source_float_note':'Existing algebraic contract uses literal scale constants; saved fixture separately reproduces float32 Java scale and reports sub-micropixel float roundoff.','helper_pitch_applied_once':True,'source_material_note':'Bottles renderSingleBlock use source default blockstate model cutout; glassware explicitly overrides cutout. Native stored luminous uses one-sided alpha test, other stored bottles use entity_alphatest.','client_and_gui_run':False}
(H/'routing-and-transform-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('poses',len(snap['poses']),'vertices',count,'maximum blocks',maximum)
