"""N04 review-only meshes. Exact affine transforms, no geometry export or runtime edits.
Source and current have independent inputs. Native storage animation is evaluated in
its documented Java-compatible world contract, NOT blindly as BB bone Euler.
Glassware keeps the raw BB-decoded reference frame; world slot checks are separate.
"""
from pathlib import Path
import json,math,uuid,base64,io,hashlib
import numpy as np
from PIL import Image
H=Path(__file__).resolve().parent;I=H/'inputs';R=I/'current';S=I/'forge/src/main/resources/assets/kaleidoscope_tavern';M=json.loads((H/'manifest.json').read_text());M['scenes']=[];M['cases']=[]
read=lambda p:json.loads(p.read_text());uid=lambda:str(uuid.uuid4());sha=lambda b:hashlib.sha256(b).hexdigest()
def T(v):m=np.eye(4);m[:3,3]=v;return m
def Q(axis,deg):
 m=np.eye(4);a=math.radians(deg);c,s=math.cos(a),math.sin(a);i,j={'x':(1,2),'y':(2,0),'z':(0,1)}[axis];m[i,i]=m[j,j]=c;m[j,i]=s;m[i,j]=-s;return m
def E(r):return Q('z',r[2])@Q('y',r[1])@Q('x',r[0])
def K(s):return np.diag([s,s,s,1])
def apply(m,p):return (m@np.r_[p,1])[:3].tolist()
def face(fr,to,side,uv,rotation=0):
 x,y,z=fr;X,Y,Z=to;pts=[]
 for u,v in [(0,0),(0,1),(1,1),(1,0)]:
  for _ in range(rotation//90):u,v=1-v,u
  pts.append({'east':[X,Y+(y-Y)*v,Z+(z-Z)*u],'west':[x,Y+(y-Y)*v,z+(Z-z)*u],'up':[x+(X-x)*u,Y,z+(Z-z)*v],'down':[x+(X-x)*u,y,Z+(z-Z)*v],'south':[x+(X-x)*u,Y+(y-Y)*v,Z],'north':[X+(x-X)*u,Y+(y-Y)*v,z]}[side])
 a,b,c,d=uv;return pts,[[a,b],[a,d],[c,d],[c,b]]
def resolve(rel):
 j=read(S/'models'/f'{rel}.json')
 if j.get('parent'):
  p=resolve(j['parent'].split(':')[-1]);j={**p,**j,'textures':{**p.get('textures',{}),**j.get('textures',{})}}
 return j
terrain=read(R/'runtime/RP/textures/terrain_texture.json')['texture_data'];gindex=read(H/'geometry-index.json');poses=read(H/'pose-snapshot.json')['poses'];animations=read(R/'runtime/RP/animations/runtime_storage_bottle.animation.json')['animations']
class Scene:
 def __init__(self,name):self.j={'meta':{'format_version':'5.0','model_format':'free','box_uv':False},'name':name,'resolution':{'width':128,'height':128},'elements':[],'groups':[],'outliner':[],'textures':[]};self.cache={}
 def group(self,name):
  u=uid();self.j['groups'].append({'name':name,'uuid':u,'origin':[0,0,0],'rotation':[0,0,0],'visibility':True,'export':True});n={'uuid':u,'children':[],'isOpen':False};self.j['outliner'].append(n);return n
 def tex(self,p):
  key=str(p)
  if key in self.cache:return self.cache[key]
  b=p.read_bytes();im=Image.open(io.BytesIO(b));n=len(self.j['textures']);self.cache[key]=n;self.j['textures'].append({'name':p.name,'id':str(n),'uuid':uid(),'width':im.width,'height':im.height,'uv_width':128,'uv_height':128,'render_mode':'default','render_sides':'front','internal':True,'saved':True,'source':'data:image/png;base64,'+base64.b64encode(b).decode(),'_review_input':str(p.relative_to(H))});return n
 def mesh(self,name,faces,m,group,raw):
  vs={};fs={};records=[]
  for n,(ps,uvs,tp,vwh,meta)in enumerate(faces):
   keys=[]
   for k,p in enumerate(ps):key=f'v{n}_{k}';keys.append(key);vs[key]=apply(m,p)
   fs[f'f{n}']={'vertices':keys,'uv':{key:[u*128/vwh[0],v*128/vwh[1]]for key,(u,v)in zip(keys,uvs)},'texture':self.tex(tp)};records.append(meta)
  u=uid();self.j['elements'].append({'name':name,'uuid':u,'type':'mesh','origin':[0,0,0],'rotation':[0,0,0],'vertices':vs,'faces':fs,'visibility':True,'shade':raw.get('shade',True),'_review':{**raw,'matrix':m.tolist(),'faces':records}});group['children'].append(u)
 def save(self,name,cases,views):
  p=H/'scenes'/f'{name}.bbmodel';p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(self.j,indent=2)+'\n');M['scenes'].append({'file':str(p.relative_to(H)),'sha256':sha(p.read_bytes()),'cases':[c['id']for c in cases],'recommended_views':views,'meshes':len(self.j['elements']),'gui_reviewed':False});M['cases'].extend([{**c,'scene':p.name}for c in cases]);print(name,len(self.j['elements']),flush=True)
def source(sc,rel,m,g,role,case):
 j=resolve(rel)
 for i,e in enumerate(j['elements']):
  fr=e['from'][:];to=e['to'][:];rot=e.get('rotation',{});p=rot.get('origin',[8,0,8]);axis=rot.get('axis','y');a=rot.get('angle',0)
  if rot.get('rescale'):
   for k in range(3):
    if k!='xyz'.index(axis):fr[k]=p[k]+(fr[k]-p[k])/math.cos(math.radians(a));to[k]=p[k]+(to[k]-p[k])/math.cos(math.radians(a))
  local=T(p)@Q(axis,a)@T(-np.array(p));ff=[]
  for s,f in e['faces'].items():
   t=f['texture']
   while t.startswith('#'):t=j['textures'][t[1:]]
   assert t.startswith('kaleidoscope_tavern:');tp=S/'textures'/(t.split(':')[1]+'.png');ps,uv=face(fr,to,s,f['uv'],f.get('rotation',0));ff.append((ps,uv,tp,[16,16],{'side':s,'texture_input':str(tp.relative_to(H)),'virtual_dimensions':[16,16],'uv':f['uv'],'rotation':f.get('rotation',0)}))
  sc.mesh('SOURCE '+role+' element '+str(i),ff,m@local,g,{'kind':'source_json','input':str((S/'models'/f'{rel}.json').relative_to(H)),'element':i,'outer_matrix':m.tolist(),'case':case,'role':role,'shade':e.get('shade',True),'render_type':j.get('render_type','block default')})
def native(sc,gid,materials,m,g,role,case,visible=None,root_pitch=None):
 gp=R/gindex[gid];geo=read(gp)['minecraft:geometry'][0];wh=[geo['description']['texture_width'],geo['description']['texture_height']];world={}
 for b in geo['bones']:
  p=np.array(b.get('pivot',[0,0,0]))*[-1,1,1];r=np.array(b.get('rotation',[0,0,0]))*[-1,-1,1]
  if root_pitch is not None and b['name']=='root':r=[root_pitch,0,0] # documented runtime world contract
  world[b['name']]=world.get(b.get('parent'),np.eye(4))@T(p)@E(r)@T(-p)
  if visible is not None and b['name']not in visible:continue
  for i,c in enumerate(b.get('cubes',[])):
   assert isinstance(c['uv'],dict) and not c.get('inflate') and not c.get('mirror')
   o,sz=c['origin'],c['size'];fr=[-o[0]-sz[0],o[1],o[2]];to=np.array(fr)+sz;p=np.array(c.get('pivot',[0,0,0]))*[-1,1,1];r=np.array(c.get('rotation',[0,0,0]))*[-1,-1,1];local=T(p)@E(r)@T(-p);ff=[]
   for s,f in c['uv'].items():
    mat=f.get('material_instance','*');tp=materials.get(mat,materials['*']);u,v=f['uv'];du,dv=f['uv_size'];uv=[u,v,u+du,v+dv];uv=uv[2:]+uv[:2]if s in ['up','down']else uv;ps,us=face(fr,to,s,uv,f.get('uv_rotation',0));ff.append((ps,us,tp,wh,{'side':s,'texture_input':str(tp.relative_to(H)),'virtual_dimensions':wh,'uv':uv,'rotation':f.get('uv_rotation',0),'material_instance':mat}))
   sc.mesh('CURRENT '+role+' '+b['name']+' cube '+str(i),ff,m@world[b['name']]@local,g,{'kind':'native_geo','input':str(gp.relative_to(H)),'bone':b['name'],'cube':i,'outer_matrix':m.tolist(),'root_pitch_world_contract':root_pitch,'case':case,'role':role,'shade':True})
def body(sc,owner,off,f,case,visible=None):
 block=read(R/f'runtime/BP/blocks/{owner}.json')['minecraft:block'];mats={k:R/('runtime/RP/'+terrain[v['texture']]['textures']+'.png')for k,v in block['components']['minecraft:material_instances'].items()if'texture'in v};sm='block/'+('deco/'+owner if owner in ['holder','circular_rack','tilted_rack','glassware_holder']else'brew/'+owner+'/single')
 sg=sc.group('SOURCE world -X | '+case);ng=sc.group('CURRENT world +X | '+case)
 source(sc,sm,T([-24,0,off])@Q('y',-f*90)@T([-8,0,-8]),sg,'body',case);native(sc,block['components']['minecraft:geometry']['identifier'],mats,T([24,0,off])@Q('y',-f*90),ng,'body',case,visible=visible);return sg,ng,block
circle=[(.5,.125,0),(.875,.3125,22.5),(.875,.6875,-22.5),(.5,.875,180),(.125,.6875,157.5),(.125,.3125,-157.5)]
def source_pose(owner,slot,f,side=None,single=False):
 outer=Q('y',-f*90)
 if owner=='tilted_rack':return outer@T([-8,0,-8])@K(float(np.float32(.9)))@T([16*(.425-.375*slot),5,16*(.02+(slot-1)*.005)])@Q('x',22.5)
 if owner=='circular_rack':x,z,yr=circle[slot];pos=[16*x-8,2,16*z-8];pitch=0;s=.82
 elif owner=='cellar_cabinet':pos=[16*(.825-slot%3*.325)-8,16*(.78-slot//3*.29),6];pitch=-90;yr=0;s=1
 elif owner=='holder':pos=[0,2,4];pitch=-45;yr=0;s=.95
 else:dx=0 if single else(4 if side=='left'else-4)*(1 if f%2==0 else-1);pos=[dx,1,0];pitch=yr=0;s=.9
 return outer@T(pos)@Q('y',yr)@Q('x',pitch)@K(float(np.float32(s)))@T([-8,0,-8])
def bottle(sc,owner,slot,f,bottle,off,sg,ng,case,side=None,single=False):
 fo='bar_cabinet'if owner=='glass_bar_cabinet'else owner;ent=read(R/f'runtime/RP/entity/runtime_{fo}_bottle_visual.entity.json')['minecraft:client_entity']['description'];kind={'wine':15,'luminous_bride':6,'brandy':16}[bottle];key='kind_'+str(kind);pose=next(p for p in poses if p['family']==owner and p['facing']==f and p['slot']==slot and (side is None or p.get('side')==side and p.get('single')==single))['pose'];o=pose['offset'];pitch=0
 for alias in ent.get('scripts',{}).get('animate',[]):pitch+=animations[ent['animations'][alias]]['bones']['root']['rotation'][0]
 sm='block/brew/drink/'+bottle+'/count1';source(sc,sm,T([-24,0,off])@source_pose(owner,slot,f,side,single),sg,'slot '+str(side or slot)+' '+bottle,case)
 mat=R/('runtime/RP/'+ent['textures'][key]+'.png');nm=T([24,0,off])@T([o['x']*16-8,o['y']*16,o['z']*16-8])@Q('y',-pose['rotation']['y'])@K(float(ent['scripts']['scale']));native(sc,ent['geometry'][key],{'*':mat},nm,ng,'slot '+str(side or slot)+' '+bottle,case,root_pitch=pitch)
 return {'slot':side or slot,'bottle':bottle,'kind':kind,'pose':pose,'whole_entity_scale':float(ent['scripts']['scale']),'root_pitch':pitch,'effective_material':ent['materials']['luminous_bride'if kind==6 else'default'],'source_render_type':resolve(sm).get('render_type')}
def make(name,owner,rows,views):
 sc=Scene('N04 '+name+' | SOURCE -X CURRENT +X | placed only');cases=[]
 for i,row in enumerate(rows):
  f=row.get('facing',0);z=i*34;cid=name+'-'+str(i);sg,ng,block=body(sc,owner,z,f,cid);occ=[]
  for slot,b in row['slots']:
   side=slot if isinstance(slot,str)else None;occ.append(bottle(sc,owner,0 if side else slot,f,b,z,sg,ng,cid,side,row.get('single',False)))
  cases.append({'id':cid,'owner':owner,'facing':f,'occupancy':occ,'source_offset':[-24,0,z],'current_offset':[24,0,z],'single_bottle_mode':row.get('single',False),'body_geometry':block['components']['minecraft:geometry']['identifier'],'coordinate_scope':'storage source-world algebra versus shipped helper/scale/RP-root-pitch contract; not engine execution'})
 sc.save(name,cases,views)
make('circular-full','circular_rack',[{'slots':[(i,'luminous_bride'if i==3 else'wine')for i in range(6)]}],['perspective','top','side/front slot neck clearance'])
make('tilted-full','tilted_rack',[{'slots':[(i,'luminous_bride'if i==1 else'wine')for i in range(3)]}],['perspective','side pitch and seat','top slot extrema'])
make('bar-twin-cardinal','bar_cabinet',[{'facing':f,'slots':[('left','wine'),('right','luminous_bride')]}for f in [0,1]],['perspective','top side swap north/east','front cavity'])
make('bar-single-irregular','bar_cabinet',[{'single':True,'slots':[('left','brandy')]}],['perspective','front broad single bottle','top'])
make('glass-bar-material','glass_bar_cabinet',[{'slots':[('left','wine'),('right','luminous_bride')]}],['perspective','front glass overlap','top'])
make('cellar-full','cellar_cabinet',[{'slots':[(i,'luminous_bride'if i==4 else'wine')for i in range(9)]}],['perspective','front nine slot spacing','side horizontal pitch'])
make('holder-occupied','holder',[{'slots':[(0,b)]}for b in ['wine','luminous_bride']],['perspective','side contact and pitch','bottom occlusion'])
# Glassware is static block geometry. Native decoded sparse positions are NOT Java
# world positions. Retain the actual canonical bone mapping, no guessed correction.
sc=Scene('N04 glassware holder | SOURCE -X CURRENT decoded +X | WORLD slot convention separate');cases=[]
b=read(R/'runtime/BP/blocks/glassware_holder.json')['minecraft:block']
for i,(f,mask)in enumerate([(0,15),(1,1),(3,8)]):
 cid='glassware-'+str(i);z=i*34;visible=['holder']
 for bone,expr in b['components']['minecraft:geometry']['bone_visibility'].items():
  import re
  def state(m):k=m[1];return str(f if k.endswith(':facing')else(mask>>int(k[-1]))&1)
  expression=re.sub(r"q.block_state\('([^']+)'\)",state,expr).replace('&&',' and ').replace('||',' or ')
  if eval(expression,{'__builtins__':{}},{}):visible.append(bone)
 sg,ng,block=body(sc,'glassware_holder',z,f,cid,visible)
 for slot in range(4):
  if mask>>slot&1:source(sc,'block/mixology/empty_glassware',T([-24,0,z])@T([-12+8*(slot%2),12.16,4+8*(slot//2)])@Q('x',-180),sg,'glass slot '+str(slot),cid)
 cases.append({'id':cid,'owner':'glassware_holder','facing':f,'mask':mask,'visible_native_bones':visible,'source_offset':[-24,0,z],'current_offset':[24,0,z],'coordinate_scope':'Java actual quadrant coordinates vs literal BB-decoded native geometry. Sparse sides may mirror in this editor reference; world quadrant mapping independently audited from pinned measured client convention. This is not a runtime defect.'})
sc.save('glassware-occupied',cases,['perspective','bottom hanging cups and slot extrema','top sparse north/east/west reference labels'])
M['comparison_limits']=['Editor Front side rendering is explicit for every texture; native Free Auto may choose DoubleSide. Neither setting executes Java/Bedrock material definitions.','Source stored bottles use default placed block state count1, never held transforms. Tilted rack +6 first-person lift is separate and untouched.','Native storage animation positive X pitch follows documented runtime world-contract evaluator; blindly negating it as BB bone Euler would create a false discrepancy.','Glassware sparse figures retain literal BB reference coordinates, separately audited world slots; no inferred bug from apparent editor mirroring.','No GUI, Minecraft, BDS, LIVE, controller ticks, camera/FOV, lighting, alpha-sort or runtime state transition acceptance.']
(H/'manifest.json').write_text(json.dumps(M,indent=2)+'\n')
queue={'batch':'N04','status':'prepared_not_gui_reviewed','scene_count':len(M['scenes']),'case_count':len(M['cases']),'estimated_useful_captures':len(M['scenes'])*3,'identity':'SOURCE at negative model X; CURRENT at positive model X. Default camera may put CURRENT screen-left. Check named groups; screen direction is not cardinal/world facing.','materials':'All textures render_sides=front, actual PNG bytes embedded, virtual UV128. Do not switch to Auto as a parity fix.','scenes':M['scenes']};(H/'capture-queue.json').write_text(json.dumps(queue,indent=2)+'\n')
