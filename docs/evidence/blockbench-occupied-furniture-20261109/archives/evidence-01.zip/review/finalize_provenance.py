from pathlib import Path
import json,hashlib,subprocess,re,io
from PIL import Image
H=Path(__file__).resolve().parent;W=H.parent;R=W/'tavern-wild-vine-repair-20261109';M=json.loads((H/'manifest.json').read_text());PIN=M['canonical_commit'];read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a])
def pin(rel):
 b=git('show',PIN+':'+rel);p=H/'inputs/current'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert b==git('show',M['worktree_commit']+':'+rel);M['inputs'][str(p.relative_to(H))]={'owner':PIN,'original_path':rel,'sha256':sha(b),'bytes':len(b)};return p
# Accepted held pose is evidence only, not a placed-layout input.
p=pin('runtime/RP/models/entity/item_display_tilted_rack.geo.json');accepted=read(H/'inputs/current/docs/evidence/t175-rack-lift/native-review.json');assert sha(p.read_bytes())==accepted['runtime_sha256']
held={'runtime_file':accepted['runtime_file'],'sha256':sha(p.read_bytes()),'accepted_evidence_sha256':sha((H/'inputs/current/docs/evidence/t175-rack-lift/native-review.json').read_bytes()),'selected_y_lift':accepted['selected_y_lift'],'exact_runtime_bytes_preserved':True,'used_for_placed_layout':False}
(H/'held-pose-preservation.json').write_text(json.dumps(held,indent=2)+'\n')
# Reuse the independently proved local Luminous crop/thickness adaptation only
# after both exact source and canonical geometry/texture input hashes match.
old=read(W/'tavern-bottle-review-20261108/manifest.json');proof=read(W/'tavern-bottle-review-20261108/face-adaptation-verification.json');row=next(s for s in proof['states']if s['family']=='luminous_bride'and s['count']==1);state=next(s for f in old['families']if f['name']=='luminous_bride'for s in f['states']if s['count']==1);reuse=[]
for field in ['canonical_geometry','canonical_texture','java_model','java_texture']:
 op=Path(state[field]);b=op.read_bytes();assert old['inputs'][str(op)]['sha256']==sha(b)
 if field.startswith('java'):rel=str(op).split('/java-reference/')[1];np=H/'inputs/forge'/rel
 else:rel=str(op).split('/source/')[1];np=H/'inputs/current'/rel
 nb=np.read_bytes();assert b==nb or field=='java_model' and b.replace(b'\r\n',b'\n')==nb.replace(b'\r\n',b'\n');reuse.append({'field':field,'input':str(np.relative_to(H)),'prior_sha256':sha(b),'current_sha256':sha(nb),'same_exact_bytes_as_prior_proof':b==nb,'line_endings_only_if_bytes_differ':b!=nb})
reuse_report={'source':'prior bottle proof #611, local face-adaptation-verification.json','prior_proof_sha256':sha((W/'tavern-bottle-review-20261108/face-adaptation-verification.json').read_bytes()),'method':proof['method'],'verified_reused_inputs':reuse,'count1_proof':row,'used_for':'Explain only the existing four bottom-strip crop faces and four +/-0.0625 cap surface offsets; all stored mesh transforms are independently rechecked in this batch.','new_occupied_gui_acceptance':False}
(H/'luminous-adaptation-reuse.json').write_text(json.dumps(reuse_report,indent=2)+'\n')
# Verify only already-materialized author-archive resource members; never lazy-fetch a Git object.
lock=read(R/'art/source-jar.lock.json');files={x['path']:x for x in lock['asset_files']};archive=[]
for path,rec in list(M['inputs'].items()):
 if not path.startswith('inputs/forge/src/')or not path.endswith(('.png','.json')):continue
 rel=rec['original_path'];part='/resources/'
 if part not in rel:continue
 ar=rel.split(part,1)[1]
 if ar not in files:continue
 info=files[ar];local=W/'tavern-bottle-review-20261108/verified-jar-inputs'/ar
 if not local.is_file():archive.append({'source':path,'author_member':ar,'status':'Not materialized locally; optional archive check not run. Pinned Forge/NeoForge source remains available.'});continue
 b=local.read_bytes();assert len(b)==info['bytes']and sha(b)==info['sha256'];data=(H/path).read_bytes();q=H/'inputs/author-resources'/ar;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);M['inputs'][str(q.relative_to(H))]={'owner':lock['input']['identity'],'original_path':ar,'sha256':sha(b),'bytes':len(b)}
 eq=json.loads(b)==json.loads(data)if ar.endswith('.json')else Image.open(io.BytesIO(b)).convert('RGBA').tobytes()==Image.open(io.BytesIO(data)).convert('RGBA').tobytes()and Image.open(io.BytesIO(b)).size==Image.open(io.BytesIO(data)).size
 archive.append({'source':path,'author_resource':str(q.relative_to(H)),'equal_json_or_pixels':eq,'exact_bytes_equal':b==data,'archive_sha256':sha(b)})
(H/'author-resource-verification.json').write_text(json.dumps({'archive_identity':lock['input'],'jar_included':False,'checks':archive},indent=2)+'\n')
# Bounded renderer semantic diff. API import migration is not a pose change.
renderers=[]
for name in ['Storage','CircularRack','TiltedRack','BarCabinet','CellarCabinet','Holder','GlasswareHolder']:
 rel='src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/client/render/block/'+name+'BlockEntityRender.java';a=(H/'inputs/forge'/rel).read_text();b=(H/'inputs/neoforge'/rel).read_text();a='\n'.join(x for x in a.splitlines()if not x.startswith('import '));b='\n'.join(x for x in b.splitlines()if not x.startswith('import '));assert a==b;renderers.append({'renderer':name,'body_identical_excluding_import_lines':True})
(H/'source-branch-renderer-audit.json').write_text(json.dumps({'renderers':renderers,'full_mod_parity_claimed':False},indent=2)+'\n')
M['provenance_note']='Canonical inputs read by Git object at main pin; verified identical to readonly worktree e420. No vendor JAR included. Bounded original author resource members included where lock supplied exact Git blob identities.'
(H/'manifest.json').write_text(json.dumps(M,indent=2)+'\n');print('verified local author members',sum('equal_json_or_pixels'in x for x in archive),'not materialized',sum('status'in x for x in archive),'total inputs',len(M['inputs']))
