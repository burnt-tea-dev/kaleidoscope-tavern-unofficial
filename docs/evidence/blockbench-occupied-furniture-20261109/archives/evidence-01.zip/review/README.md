# N04 occupied furniture: offline review preparation

**Ready for scheduled Blockbench inspection: 8 self-contained scenes, 12 occupied source/current cases, about 24 useful captures. GUI review has not run.** No new runtime mismatch was established by these checks. This is not empty-shell acceptance, in-game acceptance, or all-addon completion.

Canonical input is Tavern **0.6.213**, commit `cb2b37dfa2181ee042a090d8dbd434758a762afb`. The read-only worktree is `e4209276dab846dc6689d5760bc9e1809261d58d`; every selected canonical file was checked equal at those commits. Pending wild-vine changes do not enter this batch. No runtime edits, remote writes, client, BDS, LIVE, deployment, GUI, plugin or settings changes were made.

## Capture queue

Source groups are at model **X = -24**, current groups at **X = +24**. Camera projection may put current on screen-left. Always use named groups and case IDs, not screen-left/right, as identity. When several cases share a file they advance along Z in 34-unit steps. `capture-queue.json` contains exact files and useful views.

| Scene | Occupancy purpose | Views |
| --- | --- | --- |
| circular-full | All 6 slots, Wine plus Luminous Bride; circular yaw and extrema | perspective, top, slot neck clearance |
| tilted-full | All 3 slots, including middle material control; scale/pitch/seat | perspective, side, top |
| bar-twin-cardinal | Two-bottle north and east cases; directional left/right swap | perspective, top, cavity |
| bar-single-irregular | Brandy triggers single broad-bottle layout | perspective, front, top |
| glass-bar-material | Same twin layout owner in distinct glass body | perspective, front overlap, top |
| cellar-full | All 9 slots, center Luminous; horizontal pitch and row/column spacing | perspective, front, side |
| holder-occupied | One Wine and one Luminous case; -45° root pitch and contact | perspective, side, underside |
| glassware-occupied | Full north and sparse east/west cases; 4 cup extrema and visibility | perspective, underside, top |

Open the `.bbmodel` files without exporting them over runtime assets. PNG bytes are embedded and no external texture path is required. Save original GUI screenshots and hashes only after actual inspection. No GUI slot is taken by this preparation.

## Effective routes

The five bottle-layout owners select their existing helper entities, exact slot positions/yaw, root animations and whole-entity scales:

- Circular rack: 6 slots; scale 0.82; per-slot yaw from the Java renderer.
- Tilted rack: 3 slots; scale 0.9; +22.5° root pitch. Its helper position includes the scaled, rotated source origin.
- Bar cabinet: scale 0.9; centered irregular single bottle or twin offsets; glass bar cabinet shares this layout owner but has a distinct body.
- Cellar cabinet: 9 slots; scale 1; -90° root pitch.
- Holder: 1 slot; scale 0.95; -45° root pitch. Holder uses `holder_kind`; the other owners use `storage_kind`. Do not confuse the capped block state with the full helper kind.

The helper adapters set entity **pitch to zero**; RP root animation owns pitch exactly once. Controllers select count-one model/texture arrays. Kind 6 uses `entity_alphatest_one_sided`; other selected bottles use `entity_alphatest`. Wine, Luminous Bride and Brandy are discriminating representatives, not an attempt to duplicate the previously accepted 25 bottle families. `externalVisual` can route addon items to extension-owned helpers, but these fixtures select core items only and do not accept unpictured addon routes.

Glassware holder is different: it is a **block mesh with four occupancy states and bone-visibility expressions**, not a bottle helper entity. The furniture adapter and hit-basis mapping update those states. Java renders each occupied cup with a -180° X rotation and explicitly requests `RenderType.cutout()`.

`routing-and-transform-audit.json` records active paths, selected controller arrays/materials, scale and pitch ownership. It checks 100 pose cases over four facings, including the shared glass-bar variant. Eight independent points per case produce 800 comparisons; maximum ideal-contract difference is 2.22e-16 blocks.

## Coordinate boundaries: do not manufacture a facing bug

For stored bottles, source Java PoseStack matrices are evaluated from the original renderers. Current scenes evaluate the shipped helper position, yaw, scale and root pitch using the already documented Java-compatible storage coordinate contract. This is an algebraic placed-layout reconstruction, not a Bedrock renderer simulation. In particular, runtime root pitch uses its documented world-contract sign, not an automatic negation of the raw Blockbench bone Euler sign. All matrices are baked into mesh vertices; there is no Euler fitting or shear approximation. The source Java float scales are represented as float32, accounting for sub-micropixel differences from native literals.

**The glassware sparse cases deliberately retain two different reference frames:** source cups use Java world quadrants; current cups retain literal Blockbench-decoded canonical bones. Blockbench negates native geometry X. The independently pinned client world-slot convention uses the original bone quadrants and the effective block transformation. Thus an apparent sparse cup-side reversal in the editor is not proof of a runtime defect. The fixture does not invent a corrective mirror or silently reposition native cups. `glassware-world-slot-audit.json` separately verifies all 64 facing/occupancy masks, 256 visibility decisions, with zero errors under the recorded 2026-09-29 client convention. That convention was not re-observed in a client this run.

## UV and material handling

Each texture explicitly uses `render_sides: front`. Free-format Blockbench **Auto may choose DoubleSide**; changing to Auto would change the preview, not repair native materials. The fixtures execute neither Java nor BP materials, alpha sorting, native camera/FOV, lighting, AO or PBR.

All textures share a 128-unit editor UV space. Source JSON UVs are normalized from 16 virtual units. Native UVs are normalized from each geometry's virtual dimensions, not blindly from PNG size. In particular, glassware-holder geometry is 64×64 while its glass PNG is 32×32. The embedded PNG retains its real dimensions and original bytes. Per-face material names and the source shade flags remain recorded; native face-dimming and AO are not simulated by editor mesh shading.

Luminous retains the accepted source-supported adaptation from #611: four covered bottom-strip crop faces and four cap surfaces separated by ±0.0625 model units. Raw source/current face matching therefore reports eight expected adapted faces per Luminous placement. `luminous-adaptation-reuse.json` proves exact canonical geometry and PNG reuse; the Java input differs from the earlier checkout only by line endings. It preserves the earlier independent face proof, then this batch independently verifies every saved transformed face. These are not eight new failures, and no general geometric tolerance hides them.

## Independent saved-artifact audit

`independent-geometric-uv-audit.json` checks the saved models against original inputs without importing the builder:

- 240 input hashes and all 8 scene hashes.
- 44 embedded PNG entries with exact bytes, readable RGBA, actual dimensions and explicit 128-unit virtual UV dimensions.
- 604 saved meshes; 1,416 original-source face records and 1,360 original-native face records.
- 11,104 ordered face vertices, including zero-area source records, original signed bounds, rescale, local rotations, bone hierarchy, and all placed transforms.
- Maximum saved-versus-input vertex error 7.11e-15 model pixels; zero saved UV error.
- Every non-adapted storage face matches source geometry/UV/pixels; all remaining storage differences are the exact carried Luminous adaptation. Glassware reference/world frames are intentionally not mislabeled as direct occupied world equality.

## Source provenance and preserved scope

Forge is pinned to `c4ec1880bd44cf3139d3ba744ab30bb379cf1416`; NeoForge to `a1afba34981a00e89d57130d3dc8f1e64f1820a2`. Original bounded models, textures, renderer/block declarations and current routing inputs are retained under `inputs/` with SHA-256, byte length, original path and owner in `manifest.json`. Seven renderer bodies match across source branches after import-only API namespace differences. Model/texture comparisons are recorded individually.

One relevant source branch difference is explicit: empty-glassware model declares Forge cutout versus NeoForge translucent. Its occupied-holder renderer explicitly requests cutout in both branches; the renderer bodies, geometry and PNGs match. No claim is made about other contexts of that cup.

The original author JAR is **not included or executed**. Six already-materialized bottle resource members are checked against the archive lock and match JSON/pixels. Twenty-six other optional archive-member comparisons were not run because those bytes were not already materialized locally. Pinned Forge/NeoForge source bytes are available for them; no fresh remote or full-archive verification is claimed. See `author-resource-verification.json` and `preparation-receipt.json` for the stopped optional lookup.

The accepted tilted-rack **+6 first-person lift** is hash-identical (`93030bd4f8289be846eea898052b36ed81c33626355c8e42fbcac95a73968ff7`). `held-pose-preservation.json` records this. Placed slot layout does not use or modify held display transforms. Prior empty furniture shells and bottle-only captures are background evidence, not occupied acceptance.

## Reproduction

With the pinned local inputs already present, the saved artifacts can be rebuilt offline:

1. `python build_scenes.py`
2. `python audit_routes.py`
3. `python validate_scenes.py`

The initial `prepare_inputs.py` and `finalize_provenance.py` document preparation from the already available pinned worktrees. Do not rerun source materialization against a missing object or permit Git lazy fetching. The saved scenes and audits do not need Git/network access. GUI review remains the next step; runtime repair is neither proposed nor performed by this batch.
