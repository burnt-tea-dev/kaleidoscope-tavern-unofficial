/** Validated, data-only contracts. Behaviour remains in the Tavern host. */
import {check,id,integer} from './util.js';
const own=(value,source)=>{id(value);check(value.startsWith(source+':'),'FOREIGN_NAMESPACE',value);return value;};
export function normalizeFoundation(raw,source,itemExists){
 const rows=raw.furniture??[],effects=raw.effects??[];
 check(Array.isArray(rows)&&rows.length<=128,'FURNITURE_LIMIT');
 check(Array.isArray(effects)&&effects.length<=64,'EFFECT_LIMIT');
 const furniture=rows.map(row=>{
  check(row&&['bar_cabinet','cellar_cabinet','pendant_lamp'].includes(row.kind),'FURNITURE_KIND');
  const block=own(row.block,source);check(itemExists(block),'UNKNOWN_ITEM',block);
  const facing=id(row.facing??'kaleidoscope_tavern:facing');
  if(row.kind==='pendant_lamp'){
   // Reuse the host's existing two-half placement and destruction contract.
   check(facing==='kaleidoscope_tavern:facing'&&(row.half??'kaleidoscope_tavern:half')==='kaleidoscope_tavern:half','PENDANT_STATE_CONTRACT');
   return {source,block,kind:row.kind,facing,half:'kaleidoscope_tavern:half'};
  }
  const connection=own(row.connection,source);
  // The old coordinate store is read-only until a validated commit succeeds.
  const legacyPrefix=row.legacyPrefix;
  check(typeof legacyPrefix==='string'&&legacyPrefix===source+':storage/','INVALID_LEGACY_PREFIX');
  return {source,block,kind:row.kind,facing,connection,legacyPrefix};
 });
 check(new Set(furniture.map(x=>x.block)).size===furniture.length,'DUPLICATE_FURNITURE');
 const normalizedEffects=effects.map(row=>{
  check(row&&['timed','instant'].includes(row.mode),'EFFECT_MODE');
  return {id:own(row.id,source),mode:row.mode,source};
 });
 check(new Set(normalizedEffects.map(x=>x.id)).size===normalizedEffects.length,'DUPLICATE_EFFECT');
 const pickBlocks=raw.pickBlocks??[];
 check(Array.isArray(pickBlocks)&&pickBlocks.length<=64,'PICK_BLOCK_LIMIT');
 check(pickBlocks.reduce((sum,row)=>sum+(Array.isArray(row?.variants)?row.variants.length:0),0)<=256,'PICK_VARIANT_TOTAL');
 const normalizedPicks=pickBlocks.map(row=>{
  check(row&&typeof row==='object','PICK_BLOCK_SCHEMA');
  const block=own(row.block,source),variants=row.variants;
  check(Array.isArray(variants)&&variants.length>0&&variants.length<=64,'PICK_VARIANT_LIMIT');
  return {block,source,variants:variants.map(v=>{
   id(v.item);check(v.item.startsWith(source+':')||v.item.startsWith('minecraft:'),'FOREIGN_PICK_ITEM');
   check(itemExists(v.item),'UNKNOWN_ITEM',v.item);
   check(v.states&&typeof v.states==='object'&&!Array.isArray(v.states)&&Object.keys(v.states).length<=8,'PICK_STATES');
   const states={};for(const [key,value] of Object.entries(v.states)){
    own(key,source);check((typeof value==='string'&&value.length<=128)||typeof value==='boolean'||Number.isSafeInteger(value),'PICK_STATE_VALUE');
    states[key]=value;
   }
   return {item:v.item,states};
  })};
 });
 check(new Set(normalizedPicks.map(x=>x.block)).size===normalizedPicks.length,'DUPLICATE_PICK_BLOCK');
 const feedbackRows=raw.breakFeedback??[];
 check(Array.isArray(feedbackRows)&&feedbackRows.length<=256,'BREAK_FEEDBACK_LIMIT');
 const uv=value=>{check(Array.isArray(value)&&value.length===2&&value.every(n=>Number.isSafeInteger(n)&&n>=0&&n<=16380),'BREAK_FEEDBACK_UV');return [...value];};
 check(feedbackRows.reduce((n,row)=>n+(Array.isArray(row?.variants)?row.variants.length:0),0)<=512,'BREAK_VARIANT_TOTAL');
 const breakFeedback=feedbackRows.map(row=>{
  check(row&&['wood','glass','metal','chain','wool','crop','stone'].includes(row.material),'BREAK_FEEDBACK_MATERIAL');
  const block=own(row.block,source),particle=own(row.particle,source);check(itemExists(block),'UNKNOWN_ITEM',block);
  check(Array.isArray(row.variants??[])&&(row.variants??[]).length<=128,'BREAK_FEEDBACK_VARIANTS');
  const variants=(row.variants??[]).map(v=>{
   check(v.states&&typeof v.states==='object'&&!Array.isArray(v.states)&&Object.keys(v.states).length<=8,'BREAK_FEEDBACK_STATES');
   const states={};for(const [key,value] of Object.entries(v.states)){
    id(key);check(key.startsWith(source+':')||key.startsWith('minecraft:')||key.startsWith('kaleidoscope_tavern:'),'FOREIGN_BREAK_STATE');
    check(typeof value==='boolean'||Number.isSafeInteger(value)||typeof value==='string'&&value.length<=64,'BREAK_FEEDBACK_STATE');states[key]=value;
   }
   return {states,uv:uv(v.uv)};
  });
  return {block,material:row.material,particle,uv:uv(row.uv),...(variants.length?{variants}:{})};
 });
 check(new Set(breakFeedback.map(x=>x.block)).size===breakFeedback.length,'DUPLICATE_BREAK_FEEDBACK');
 const itemParticles=raw.itemParticles;
 let normalizedParticles;
 if(itemParticles!==undefined){
  check(Array.isArray(itemParticles)&&itemParticles.length<=256,'ITEM_PARTICLE_LIMIT');
  normalizedParticles=itemParticles.map(row=>{
   check(row&&typeof row==='object','ITEM_PARTICLE_SCHEMA');
   const item=own(row.item,source),particle=own(row.particle,source);
   check(itemExists(item),'UNKNOWN_ITEM',item);
   return {item,particle};
  });
  check(new Set(normalizedParticles.map(x=>x.item)).size===normalizedParticles.length,'DUPLICATE_ITEM_PARTICLE');
 }
 const legacyEffectKey=raw.legacyEffectKey;
 if(legacyEffectKey!==undefined)check(legacyEffectKey===source+':effects','INVALID_LEGACY_EFFECT_KEY');
 const modNameKey=raw.modNameKey;
 if(modNameKey!==undefined)check(modNameKey===`item.${source}.mod_name`,'INVALID_MOD_NAME_KEY');
 const requires=raw.requires??[];check(Array.isArray(requires)&&requires.length<=16&&requires.every(x=>typeof x==='string'),'INVALID_REQUIRES');
 return {breakFeedback,furniture,effects:normalizedEffects,pickBlocks:normalizedPicks,...(normalizedParticles?{itemParticles:normalizedParticles}:{}),legacyEffectKey,modNameKey,requires:[...new Set(requires)]};
}
export function migrateLegacyEffects(raw,source,definitions,absoluteTick){
 check(typeof raw==='string','LEGACY_EFFECT_SCHEMA');
 const data=JSON.parse(raw);check(data&&typeof data==='object'&&!Array.isArray(data),'LEGACY_EFFECT_SCHEMA');
 check(Object.keys(data).length<=32,'CUSTOM_EFFECT_LIMIT');
 const entries=[];
 for(const [name,row] of Object.entries(data)){
  const effect=source+':'+name;id(effect);
  check(definitions.some(x=>x.id===effect&&x.mode==='timed'),'LEGACY_EFFECT_UNKNOWN',effect);
  check(row&&Number.isSafeInteger(row.end)&&row.end>=0,'LEGACY_EFFECT_END');integer(row.amplifier,0,255);
  const ticks=Math.max(0,row.end-absoluteTick);check(ticks<=20000000,'LEGACY_EFFECT_DURATION');
  if(ticks)entries.push({id:effect,ticks,amplifier:row.amplifier});
 }
 return entries;
}
