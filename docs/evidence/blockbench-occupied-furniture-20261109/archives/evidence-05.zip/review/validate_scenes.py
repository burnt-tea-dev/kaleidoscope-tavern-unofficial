"""Independent original-input to saved-mesh validator. Does not import builder.
Uses SciPy XYZ matrices and explicit face vertex tables instead of builder loops.
Checks all input hashes, embedded pixels, original UV/face/rotation and transformed
vertices. Separate pair matching is informative, never self-comparison as source.
"""
from pathlib import Path
import json,hashlib,io,base64,math,re
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.optimize import linear_sum_assignment
from PIL import Image
H=Path(__file__).resolve().parent;M=json.loads((H/'manifest.json').read_text());C={'input_hashes':0,'scenes':0,'textures':0,'meshes':0,'direct_source_faces':0,'direct_native_faces':0,'vertices':0,'max_saved_vertex_error':0.,'max_saved_uv_error':0.,'gui_reviewed':False,'pair_comparisons':[]}
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
for p,r in M['inputs'].items():b=(H/p).read_bytes();assert len(b)==r['bytes']and sha(b)==r['sha256'];C['input_hashes']+=1
def tr(v):m=np.eye(4);m[:3,3]=v;return m
def rt(r):m=np.eye(4);m[:3,:3]=Rotation.from_euler('xyz',r,degrees=True).as_matrix();return m
def scale(s):return np.diag([s,s,s,1.])
def transform(m,p):return (m@np.c_[p,np.ones(len(p))].T).T[:,:3]
def surface(lo,hi,side,uv,rotation):
 x,y,z=lo;X,Y,Z=hi
 corners={'north':[[X,Y,z],[X,y,z],[x,y,z],[x,Y,z]],'east':[[X,Y,Z],[X,y,Z],[X,y,z],[X,Y,z]],'south':[[x,Y,Z],[x,y,Z],[X,y,Z],[X,Y,Z]],'west':[[x,Y,z],[x,y,z],[x,y,Z],[x,Y,Z]],'up':[[x,Y,z],[x,Y,Z],[X,Y,Z],[X,Y,z]],'down':[[x,y,Z],[x,y,z],[X,y,z],[X,y,Z]]}[side]
 n=(rotation//90)%4;corners=corners[-n:]+corners[:-n]if n else corners;a,b,c,d=uv;return np.array(corners),np.array([[a,b],[a,d],[c,d],[c,b]])
S=H/'inputs/forge/src/main/resources/assets/kaleidoscope_tavern';R=H/'inputs/current';cases={c['id']:c for c in M['cases']};poses=read(H/'pose-snapshot.json')['poses'];an=read(R/'runtime/RP/animations/runtime_storage_bottle.animation.json')['animations']
def resolved(p):
 j=read(p)
 if j.get('parent'):
  q=resolved(S/'models'/(j['parent'].split(':')[-1]+'.json'));j={**q,**j,'textures':{**q.get('textures',{}),**j.get('textures',{})}}
 return j
def expected_outer(e):
 r=e['_review'];c=cases[r['case']];f=c['facing'];isnative=r['kind']=='native_geo';off=c['current_offset'if isnative else'source_offset'];role=r['role'];outer=tr(off);facing=rt([0,-90*f,0]);owner=c['owner']
 if role=='body':return outer@facing@(np.eye(4)if isnative else tr([-8,0,-8]))
 if owner=='glassware_holder':
  slot=int(role.split()[-1]);return outer@tr([-12+8*(slot%2),12.16,4+8*(slot//2)])@rt([-180,0,0])
 occ=next(o for o in c['occupancy']if role=='slot '+str(o['slot'])+' '+o['bottle']);slot=occ['slot'];side=slot if isinstance(slot,str)else None;slot=0 if side else slot
 if isnative:
  p=next(x for x in poses if x['family']==owner and x['facing']==f and x['slot']==slot and (side is None or x.get('side')==side and x.get('single')==c['single_bottle_mode']))['pose'];d=read(R/f"runtime/RP/entity/runtime_{'bar_cabinet'if owner=='glass_bar_cabinet'else owner}_bottle_visual.entity.json")['minecraft:client_entity']['description'];o=p['offset'];return outer@tr([16*o['x']-8,16*o['y'],16*o['z']-8])@rt([0,-p['rotation']['y'],0])@scale(float(d['scripts']['scale']))
 # Independent direct PoseStack multiplication, in 16-pixel block coordinates.
 A=outer@facing@tr([-8,0,-8]);s=1.;rot=[0,0,0]
 if owner=='tilted_rack':return A@scale(float(np.float32(.9)))@tr([6.8-6*slot,5,.32+(slot-1)*.08])@rt([22.5,0,0])
 if owner=='holder':xyz=[8,2,12];s=.95;rot=[-45,0,0]
 elif owner=='cellar_cabinet':xyz=[13.2-5.2*(slot%3),12.48-4.64*(slot//3),14];rot=[-90,0,0]
 elif owner=='circular_rack':
  rows=[[8,2,2,0],[14,2,5,22.5],[14,2,11,-22.5],[8,2,14,180],[2,2,11,157.5],[2,2,5,-157.5]];q=rows[slot];xyz=q[:3];rot=[0,q[3],0];s=.82
 else:dx=0 if c['single_bottle_mode']else(4 if side=='left'else-4)*(1 if f in [0,2]else-1);xyz=[8+dx,1,8];s=.9
 return A@tr(xyz)@rt(rot)@scale(float(np.float32(s)))@tr([-8,0,-8])
def original_faces(e):
 r=e['_review'];outer=expected_outer(e);assert np.max(np.abs(outer-np.array(r['outer_matrix'])))<1e-12,(e['name'],'outer')
 if r['kind']=='source_json':
  j=resolved(H/r['input']);o=j['elements'][r['element']];lo=np.array(o['from'],float);hi=np.array(o['to'],float);rot=o.get('rotation',{});p=np.array(rot.get('origin',[8,0,8]),float);angles=[0,0,0];axis='xyz'.index(rot.get('axis','y'));angles[axis]=rot.get('angle',0)
  if rot.get('rescale'):
   for k in range(3):
    if k!=axis:lo[k]=p[k]+(lo[k]-p[k])/math.cos(math.radians(angles[axis]));hi[k]=p[k]+(hi[k]-p[k])/math.cos(math.radians(angles[axis]))
  matrix=outer@tr(p)@rt(angles)@tr(-p);out=[]
  for side,f in o['faces'].items():
   t=f['texture']
   while t.startswith('#'):t=j['textures'][t[1:]]
   tp=S/'textures'/(t.split(':')[1]+'.png');ps,uv=surface(lo,hi,side,f['uv'],f.get('rotation',0));out.append((transform(matrix,ps),uv/16,tp,side));C['direct_source_faces']+=1
 else:
  geo=read(H/r['input'])['minecraft:geometry'][0];bone=next(b for b in geo['bones']if b['name']==r['bone']);o=bone['cubes'][r['cube']];world={}
  for b in geo['bones']:
   p=np.array(b.get('pivot',[0,0,0]))*[-1,1,1];angles=np.array(b.get('rotation',[0,0,0]))*[-1,-1,1]
   if b['name']=='root'and r['root_pitch_world_contract']is not None:
    c=cases[r['case']];owner='bar_cabinet'if c['owner']=='glass_bar_cabinet'else c['owner'];d=read(R/f'runtime/RP/entity/runtime_{owner}_bottle_visual.entity.json')['minecraft:client_entity']['description'];pitch=sum(an[d['animations'][a]]['bones']['root']['rotation'][0]for a in d.get('scripts',{}).get('animate',[]));assert pitch==r['root_pitch_world_contract'];angles=[pitch,0,0]
   world[b['name']]=world.get(b.get('parent'),np.eye(4))@tr(p)@rt(angles)@tr(-p)
  lo=np.array(o['origin'],float);hi=lo+o['size'];lo[0],hi[0]=-hi[0],-lo[0];p=np.array(o.get('pivot',[0,0,0]))*[-1,1,1];angles=np.array(o.get('rotation',[0,0,0]))*[-1,-1,1];matrix=outer@world[bone['name']]@tr(p)@rt(angles)@tr(-p);out=[];wh=np.array([geo['description']['texture_width'],geo['description']['texture_height']])
  if r['role']=='body':
   block=read(R/f"runtime/BP/blocks/{cases[r['case']]['owner']}.json")['minecraft:block'];terr=read(R/'runtime/RP/textures/terrain_texture.json')['texture_data'];mats=block['components']['minecraft:material_instances']
  for side,f in o['uv'].items():
   uv=list(f['uv'])+[f['uv'][i]+f['uv_size'][i]for i in range(2)]
   if side in ['up','down']:uv=uv[2:]+uv[:2]
   ps,us=surface(lo,hi,side,uv,f.get('uv_rotation',0))
   if r['role']=='body':mat=mats.get(f.get('material_instance','*'),mats['*']);tp=R/('runtime/RP/'+terr[mat['texture']]['textures']+'.png')
   else:
    c=cases[r['case']];occ=next(x for x in c['occupancy']if r['role']=='slot '+str(x['slot'])+' '+x['bottle']);d=read(R/f"runtime/RP/entity/runtime_{'bar_cabinet'if c['owner']=='glass_bar_cabinet'else c['owner']}_bottle_visual.entity.json")['minecraft:client_entity']['description'];tp=R/('runtime/RP/'+d['textures']['kind_'+str(occ['kind'])]+'.png')
   out.append((transform(matrix,ps),us/wh,tp,side));C['direct_native_faces']+=1
 assert np.max(np.abs(matrix-np.array(r['matrix'])))<1e-12
 return out
for row in M['scenes']:
 p=H/row['file'];assert sha(p.read_bytes())==row['sha256'];doc=read(p);C['scenes']+=1;texhash={}
 for n,t in enumerate(doc['textures']):
  b=base64.b64decode(t['source'].split(',',1)[1]);im=Image.open(io.BytesIO(b)).convert('RGBA');assert im.size==(t['width'],t['height']);assert t['render_sides']=='front'and(t['uv_width'],t['uv_height'])==(128,128);assert b==(H/t['_review_input']).read_bytes();texhash[n]=sha(im.tobytes()+str(im.size).encode());C['textures']+=1
 paired={}
 for e in doc['elements']:
  C['meshes']+=1;exp=original_faces(e);assert len(exp)==len(e['faces']);r=e['_review'];c=cases[r['case']];off=np.array(c['current_offset'if r['kind']=='native_geo'else'source_offset']);key=(r['case'],r['kind']);paired.setdefault(key,[])
  for f,(ps,uv,tp,side) in zip(e['faces'].values(),exp):
   actual=np.array([e['vertices'][v]for v in f['vertices']]);au=np.array([f['uv'][v]for v in f['vertices']])/128;err=float(abs(actual-ps).max());ue=float(abs(au-uv).max());assert err<1e-10,(e['name'],side,err);assert ue<1e-12;C['max_saved_vertex_error']=max(C['max_saved_vertex_error'],err);C['max_saved_uv_error']=max(C['max_saved_uv_error'],ue);assert doc['textures'][f['texture']]['_review_input']==str(tp.relative_to(H));C['vertices']+=4
   if np.linalg.norm(np.cross(actual[1]-actual[0],actual[2]-actual[0]))>1e-9:paired[key].append((actual-off,au,texhash[f['texture']],r['role']))
 for cid in row['cases']:
  a=paired.get((cid,'source_json'),[]);b=paired.get((cid,'native_geo'),[]);result={'case':cid,'source_faces':len(a),'native_faces':len(b),'source_and_native_have_independent_inputs':True}
  if cases[cid]['owner']=='glassware_holder':result['comparison']='Native BB reference and Java world slots are distinct; no direct occupied world equality claim. Raw source and native every face verified above.'
  elif len(a)==len(b):
   cost=np.ones((len(a),len(b)))*1e5
   for i,(pa,ua,ta,ra)in enumerate(a):
    for j,(pb,ub,tb,rb)in enumerate(b):
     if ta!=tb or ra!=rb:continue
     for k in range(4):
      v=np.roll(pb,k,axis=0);u=np.roll(ub,k,axis=0)
      if np.max(abs(ua-u))<1e-8:cost[i,j]=min(cost[i,j],float(np.max(abs(pa-v))))
   ii,jj=linear_sum_assignment(cost);errs=cost[ii,jj];result.update(raw_exactly_matched_faces=int(np.sum(errs<1e-3)),max_exactly_matched_position_error_pixels=float(errs[errs<1e-3].max()) if np.any(errs<1e-3) else None,uv_and_pixel_constrained=True,raw_nonmatching_faces=int(np.sum(errs>=1e-3)))
   unmatched=[a[int(i)][3]for i,err in zip(ii,errs)if err>=1e-3]
   if unmatched:
    assert len(unmatched)==8 and all('luminous_bride'in role for role in unmatched),(cid,unmatched)
    proof=read(H/'luminous-adaptation-reuse.json');assert proof['count1_proof']['complete_uv_bijection']
    result.update(known_adapted_faces=8,adaptation='Four existing covered bottom-strip crop faces, four existing symmetric cap thickness offsets. Exact local proof reused only after source/native/texture verification; independent saved-face checks include every transformed adaptation.',adaptation_proof='luminous-adaptation-reuse.json',unexplained_differences=0)
   else:result['unexplained_differences']=0
  else:result['comparison']='Face cardinality differs; source plane decomposition must be assessed independently; no parity inference from total alone.'
  C['pair_comparisons'].append(result)
(H/'independent-geometric-uv-audit.json').write_text(json.dumps(C,indent=2)+'\n');print(json.dumps(C,indent=2))
