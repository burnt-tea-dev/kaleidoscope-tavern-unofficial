from pathlib import Path
import json,subprocess,hashlib,re,io,ast
from PIL import Image
H=Path(__file__).resolve().parent;W=H.parent;R=W/'tavern-wild-vine-repair-20261109';J=W/'tavern-visual-review-20261108/java-reference'
MAIN='cb2b37dfa2181ee042a090d8dbd434758a762afb';WORK='e4209276dab846dc6689d5760bc9e1809261d58d';FORGE='c4ec1880bd44cf3139d3ba744ab30bb379cf1416';NEO='a1afba34981a00e89d57130d3dc8f1e64f1820a2'
AS='src/main/resources/assets/kaleidoscope_tavern/';JA='src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(r,*a):return subprocess.check_output(['git','-C',str(r),*a])
M={'canonical_commit':MAIN,'read_only_worktree':str(R),'worktree_commit':WORK,'runtime_tree':git(R,'rev-parse',MAIN+':runtime').decode().strip(),'runtime_version':'0.6.213','source_pins':{'Forge':FORGE,'NeoForge':NEO},'inputs':{},'source_branch_comparison':{},'gui_reviewed':False,'scenes':[],'cases':[]}
def track(p,b,owner,rel):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);M['inputs'][str(p.relative_to(H))]={'sha256':sha(b),'bytes':len(b),'owner':owner,'original_path':rel};return p
seen=set()
def native(rel):
 p=H/'inputs/current'/rel
 if rel in seen:return p
 b=git(R,'show',MAIN+':'+rel);assert git(R,'show',WORK+':'+rel)==b,(rel,'changed worktree input');seen.add(rel);track(p,b,MAIN,rel)
 if rel.endswith('.js'):
  for imp in re.findall(r"from ['\"](\.[^'\"]+\.js)['\"]",b.decode()):native(str((Path(rel).parent/imp).resolve().relative_to(Path.cwd()))) if False else native(str(Path(__import__('os').path.normpath(str(Path(rel).parent/imp)))))
 return p
def source(rel):
 p=H/'inputs/forge'/rel
 if p.exists() and str(p.relative_to(H))in M['inputs']:return p
 b=git(J,'show',FORGE+':'+rel);track(p,b,FORGE,rel)
 z=subprocess.run(['git','-C',str(J),'show',NEO+':'+rel],capture_output=True);row={'present':z.returncode==0}
 if z.returncode==0:
  track(H/'inputs/neoforge'/rel,z.stdout,NEO,rel);row['bytes_equal']=b==z.stdout
  if rel.endswith('.json'):row['semantic_json_equal']=json.loads(b)==json.loads(z.stdout)
  elif rel.endswith('.png'):
   a,c=Image.open(io.BytesIO(b)).convert('RGBA'),Image.open(io.BytesIO(z.stdout)).convert('RGBA');row['pixels_equal']=a.size==c.size and a.tobytes()==c.tobytes()
  else:row['text_equal_ignoring_line_endings']=b.decode().splitlines()==z.stdout.decode().splitlines()
 M['source_branch_comparison'][rel]=row;return p
read=lambda p:json.loads(p.read_text())
def model(rel):
 p=source(AS+'models/'+rel+'.json');j=read(p)
 if j.get('parent'):
  par=model(j['parent'].split(':')[-1]);j={**par,**j,'textures':{**par.get('textures',{}),**j.get('textures',{})}}
 for v in j.get('textures',{}).values():
  if v.startswith('kaleidoscope_tavern:'):source(AS+'textures/'+v.split(':')[1]+'.png')
 return j
owners=['holder','circular_rack','tilted_rack','bar_cabinet','cellar_cabinet']
terrain=read(native('runtime/RP/textures/terrain_texture.json'))['texture_data']
geoindex={}
for p in (R/'runtime/RP/models/entity').glob('*.json'):
 for g in read(p)['minecraft:geometry']:geoindex[g['description']['identifier']]=str(p.relative_to(R))
for owner in owners+['glass_bar_cabinet','glassware_holder']:
 d=read(native(f'runtime/BP/blocks/{owner}.json'))['minecraft:block'];native(geoindex[d['components']['minecraft:geometry']['identifier']])
 for mat in d['components']['minecraft:material_instances'].values():
  if 'texture'in mat:native('runtime/RP/'+terrain[mat['texture']]['textures']+'.png')
 for perm in d['permutations']:
  gg=perm['components'].get('minecraft:geometry')
  if gg:native(geoindex[gg['identifier']])
 sm='deco/'+owner if owner in ['holder','circular_rack','tilted_rack','glassware_holder']else 'brew/'+owner+'/single'
 model('block/'+sm)
 source('src/generated/resources/assets/kaleidoscope_tavern/blockstates/'+owner+'.json')
for owner in owners:
 ent=read(native(f'runtime/RP/entity/runtime_{owner}_bottle_visual.entity.json'))['minecraft:client_entity']['description']
 native(f'runtime/BP/entities/{owner}_bottle_visual.json')
 native(f'runtime/RP/render_controllers/runtime_{owner}.render_controllers.json')
 for key in ['kind_6','kind_15']+(['kind_16']if owner in ['circular_rack','bar_cabinet']else[]):
  native(geoindex[ent['geometry'][key]]);native('runtime/RP/'+ent['textures'][key]+'.png')
 for kind in ['core','bedrock']:native('runtime/BP/scripts/'+kind+'/'+owner.replace('_','-')+'.js')
for rel in ['runtime/BP/scripts/bedrock/storage-visual-maintenance.js','runtime/BP/scripts/bedrock/furniture.js','runtime/BP/scripts/core/furniture.js','runtime/BP/scripts/core/hit-basis.js','runtime/RP/animations/runtime_storage_bottle.animation.json','data/storage-render-source.json','tools/check_storage_rendering.py','tools/check_glassware_slots.py','docs/evidence/t175-rack-lift/native-review.json']:
 try:native(rel)
 except subprocess.CalledProcessError:
  if 'item_view' not in rel:raise
for name in ['Storage','CircularRack','TiltedRack','BarCabinet','CellarCabinet','Holder','GlasswareHolder']:source(JA+'client/render/block/'+name+'BlockEntityRender.java')
for name,sub in [('Holder','deco'),('CircularRack','deco'),('TiltedRack','deco'),('BarCabinet','brew'),('CellarCabinet','brew'),('GlasswareHolder','deco')]:
 source(JA+f'block/{sub}/{name}Block.java');source(JA+f'blockentity/{sub}/{name}BlockEntity.java')
for bottle in ['wine','luminous_bride','brandy']:
 model('block/brew/drink/'+bottle+'/count1');source('src/generated/resources/assets/kaleidoscope_tavern/blockstates/'+bottle+'.json')
model('block/mixology/empty_glassware')
# Evaluate only read-only pure core pose functions, in one Node process. No server imports.
tree=ast.parse((R/'tools/check_storage_rendering.py').read_text());code=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name)and t.id=='NODE_SNAPSHOT'for t in n.targets))
snap=subprocess.check_output(['node','--input-type=module','-e',code],cwd=R)
track(H/'pose-snapshot.json',snap,'pure core function evaluation at '+WORK,'tools/check_storage_rendering.py:NODE_SNAPSHOT')
# Protect exact accepted first-person display assets, never use them for placed layout.
for p in (R/'runtime/RP').rglob('*tilted_rack*'):
 if p.is_file() and ('animation'in p.parts or 'animations'in p.parts or 'attachables'in p.parts):native(str(p.relative_to(R)))
(H/'geometry-index.json').write_text(json.dumps(geoindex,indent=2)+'\n')
(H/'manifest.json').write_text(json.dumps(M,indent=2)+'\n');print('inputs',len(M['inputs']))
