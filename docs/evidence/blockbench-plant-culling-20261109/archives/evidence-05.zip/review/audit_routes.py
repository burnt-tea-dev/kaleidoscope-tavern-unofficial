"""Read-only pinned Git audit; writes review JSON only inside this directory.

No checkout, fetch, import of repository code, class execution, or runtime edit.
"""
from pathlib import Path
from collections import Counter
import copy, hashlib, io, itertools, json, re, subprocess
from PIL import Image

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = WORK / 'tavern-decor-publication-20261109'
JAVA = WORK / 'tavern-visual-review-20261108/java-reference'
OLD = WORK / 'tavern-next-decor-review-20261108'
PIN = 'cb2b37dfa2181ee042a090d8dbd434758a762afb'
PINS = {'Forge': 'c4ec1880bd44cf3139d3ba744ab30bb379cf1416',
        'NeoForge': 'a1afba34981a00e89d57130d3dc8f1e64f1820a2'}
CANDIDATES = ['grape_crop', 'gold_grape_crop', 'ice_grape_crop', 'grapevine_trellis']
CONTROLS = ['gold_grapevine_trellis', 'ice_grapevine_trellis']
NS = 'kaleidoscope_tavern:'
sha = lambda b: hashlib.sha256(b).hexdigest()
jdump = lambda obj: (json.dumps(obj, indent=2, ensure_ascii=False)+'\n').encode()
cache = {}
inputs = {}

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], timeout=60)

def data(repo, pin, path):
    key = str(repo), pin, path
    if key not in cache:
        b = git(repo, 'show', pin+':'+path)
        cache[key] = b
        inputs['|'.join(key)] = {'repository': str(repo), 'commit': pin, 'path': path,
                                'sha256': sha(b), 'bytes': len(b)}
    return cache[key]

def read(repo, pin, path):
    return json.loads(data(repo, pin, path))

def write(name, obj):
    (HERE/name).write_bytes(jdump(obj))

def fields(value, path=()):
    if isinstance(value, dict):
        for k, v in value.items():
            if k == 'render_method': yield path+(k,), v
            else: yield from fields(v, path+(k,))
    elif isinstance(value, list):
        for i, v in enumerate(value): yield from fields(v, path+(i,))

def setpath(obj, path, value):
    for k in path[:-1]: obj = obj[k]
    obj[path[-1]] = value

def condition(text, state):
    # Accept only this bounded resource grammar, no arbitrary eval.
    atoms = text.split(' && ')
    for atom in atoms:
        m = re.fullmatch(r"q\.block_state\('([^']+)'\) == (\d+|'[^']+'|true|false)", atom)
        assert m, atom
        raw = m[2]
        val = raw[1:-1] if raw.startswith("'") else {'true': True, 'false': False}.get(raw, int(raw) if raw.isdigit() else None)
        if state[m[1]] != val: return False
    return True

def resolve_model(pin, ref, stack=()):
    assert ref.startswith(NS) and ref not in stack
    rel = ref.split(':', 1)[1]
    paths = [f'src/{kind}/resources/assets/kaleidoscope_tavern/models/{rel}.json' for kind in ['main', 'generated']]
    available = source_paths[pin]
    path = next(p for p in paths if p in available)
    obj = read(JAVA, pin, path)
    chain = [path]
    if obj.get('parent'):
        parent, chain2 = resolve_model(pin, obj['parent'], stack+(ref,))
        obj = {**parent, **obj, 'textures': {**parent.get('textures', {}), **obj.get('textures', {})}}
        chain += chain2
    return obj, chain

def texref(model, ref):
    seen = set()
    while ref.startswith('#'):
        assert ref not in seen
        seen.add(ref); ref = model['textures'][ref[1:]]
    return ref

def alpha_stats(raw):
    im = Image.open(io.BytesIO(raw)).convert('RGBA')
    counts = Counter(im.getchannel('A').tobytes())
    return {'size': list(im.size), 'rgba_sha256': sha(im.tobytes()), 'alpha_counts': dict(sorted(counts.items()))}

assert git(REPO, 'rev-parse', 'origin/main').decode().strip() == PIN
assert git(REPO, 'rev-parse', PIN+':runtime').decode().strip() == '38c5977dd6bfe14b1824734612e3c601e1e41028'
manifest = json.loads((OLD/'manifest.json').read_text())
for saved_path, record in manifest['inputs'].items():
    assert sha(Path(saved_path).read_bytes()) == record['sha256'], saved_path
old_faces = json.loads((OLD/'ordered-face-audit.json').read_text())
source_paths = {pin: set(git(JAVA, 'ls-tree', '-r', '--name-only', pin).decode().splitlines()) for pin in PINS.values()}
terrain = read(REPO, PIN, 'runtime/RP/textures/terrain_texture.json')['texture_data']
cases = [c for c in manifest['cases'] if c['block'] in CANDIDATES+CONTROLS]
geo = {}
models = []
for case in cases:
    gp = 'runtime/'+case['binding']['geometry'].split('/runtime/', 1)[1]
    raw = data(REPO, PIN, gp)
    assert sha(raw) == manifest['inputs'][case['binding']['geometry']]['sha256']
    model = json.loads(raw)['minecraft:geometry'][0]
    gid = model['description']['identifier']
    geo[gid] = (gp, model)
    source_ref = NS + str(Path(case['source_model']).relative_to(JAVA/'src/main/resources/assets/kaleidoscope_tavern/models')).removesuffix('.json')
    assert json.loads(data(JAVA, PINS['Forge'], str(Path(case['source_model']).relative_to(JAVA)))) == json.loads(Path(case['source_model']).read_bytes())
    source = {}
    for loader, pin in PINS.items():
        sm, chain = resolve_model(pin, source_ref)
        assert sm['render_type'] == 'cutout'
        faces = []
        for i, elem in enumerate(sm['elements']):
            for direction, face in elem['faces'].items():
                tref = texref(sm, face['texture'])
                tp = 'src/main/resources/assets/kaleidoscope_tavern/textures/'+tref.split(':',1)[1]+'.png'
                tb = data(JAVA, pin, tp)
                faces.append({'element': i, 'direction': direction, 'from': elem['from'], 'to': elem['to'],
                              'rotation': elem.get('rotation'), 'shade': elem.get('shade', True),
                              'uv': face.get('uv'), 'uv_rotation': face.get('rotation', 0),
                              'cullface': face.get('cullface'), 'texture': tref, 'texture_sha256': sha(tb),
                              'texture_rgba_sha256': alpha_stats(tb)['rgba_sha256']})
        source[loader] = {'model_ref': source_ref, 'chain': chain, 'render_type': sm['render_type'], 'faces': faces}
    for ff, nf in zip(source['Forge']['faces'], source['NeoForge']['faces'], strict=True):
        assert {k:v for k,v in ff.items() if k!='texture_sha256'} == {k:v for k,v in nf.items() if k!='texture_sha256'}, (case['label'], ff, nf)
    runtime_faces = []
    for bi, bone in enumerate(model['bones']):
        for ci, cube in enumerate(bone.get('cubes', [])):
            for direction, face in cube['uv'].items():
                runtime_faces.append({'bone': bi, 'cube': ci, 'direction': direction,
                    'origin': cube['origin'], 'size': cube['size'], 'pivot': cube.get('pivot'),
                    'rotation': cube.get('rotation'), 'uv': face,
                    'material_tag': face.get('material_instance', '*')})
    audited = next(c for c in old_faces['cases'] if c['label'] == case['label'])
    assert audited['face_bijection'] and not audited['unmatched_source_faces'] and not audited['unmatched_native_faces']
    for pair in audited['pairs']:
        assert pair['uv_equal'] and pair['shade_equal'] and pair['texture_pixels_equal']
    models.append({'label': case['label'], 'owner': case['block'], 'geometry_id': gid,
                   'geometry_path': gp, 'geometry_sha256': sha(raw), 'source': source,
                   'runtime_faces': runtime_faces, 'preserved_ordered_face_audit': audited})

owners = []
proposals = []
for name in CANDIDATES+CONTROLS:
    path = 'runtime/BP/blocks/'+name+'.json'
    raw = data(REPO, PIN, path); block = json.loads(raw); body = block['minecraft:block']
    assert sha(raw) == manifest['inputs'][str(WORK/'tavern-visual-review-20261108/source'/path)]['sha256']
    allfields = list(fields(block))
    methods = dict(Counter(v for _,v in allfields))
    expected_methods = {'alpha_test':8} if name.endswith('_crop') else ({'alpha_test':12,'alpha_test_single_sided':48} if name=='grapevine_trellis' else {'alpha_test_single_sided':60})
    assert methods == expected_methods, (name,methods)
    bstate_path = f'src/generated/resources/assets/kaleidoscope_tavern/blockstates/{name}.json'
    bsources = {loader: read(JAVA, pin, bstate_path) for loader, pin in PINS.items()}
    assert bsources['Forge'] == bsources['NeoForge']
    variants = bsources['Forge']['variants']
    declared = copy.deepcopy(body['description'].get('states', {}))
    if 'minecraft:block_face' in body['description'].get('traits', {}).get('minecraft:placement_position', {}).get('enabled_states', []):
        declared['minecraft:block_face'] = ['down', 'up', 'north', 'south', 'west', 'east']
    bindings = []
    binding_keys = {}
    def binding(geom, materials):
        gid = geom['identifier']; gp, model = geo[gid]
        used = Counter(f.get('material_instance', '*') for bone in model['bones'] for cube in bone.get('cubes',[]) for f in cube['uv'].values())
        resolved = {}
        for tag, count in used.items():
            key = tag if tag in materials else '*'
            mat = materials[key]
            tex = terrain[mat['texture']]['textures']; assert isinstance(tex, str)
            tp = 'runtime/RP/'+tex+'.png'; tb = data(REPO, PIN, tp)
            # Existing source/native pixel audit is exact for every face; current bytes unchanged.
            assert sha(tb) == manifest['inputs'][str(WORK/'tavern-visual-review-20261108/source'/tp)]['sha256']
            resolved[tag] = {'material_key': key, 'face_count': count, 'material': mat,
                             'texture_path': tp, 'texture_sha256': sha(tb), 'alpha': alpha_stats(tb)}
        value = {'geometry': geom, 'geometry_path': gp, 'geometry_sha256': sha(data(REPO,PIN,gp)),
                 'materials': materials, 'active_face_bindings': resolved}
        key = json.dumps(value, sort_keys=True)
        if key not in binding_keys:
            binding_keys[key] = len(bindings); bindings.append(value)
        return binding_keys[key]
    base = body['components']
    declarations = [{'location':'base', 'world_binding': binding(base['minecraft:geometry'],base['minecraft:material_instances']),
                     'item_binding': binding(base['minecraft:item_visual']['geometry'], base['minecraft:item_visual']['material_instances'])}]
    for i,p in enumerate(body.get('permutations', [])):
        c = copy.deepcopy(base); c.update(p['components'])
        declarations.append({'location': f'permutations/{i}', 'condition': p['condition'],
                             'world_binding': binding(c['minecraft:geometry'],c['minecraft:material_instances']),
                             'item_binding': binding(c['minecraft:item_visual']['geometry'],c['minecraft:item_visual']['material_instances']),
                             'item_inherits_base': 'minecraft:item_visual' not in p['components']})
    states = []
    for values in itertools.product(*declared.values()):
        state = dict(zip(declared, values)); c = copy.deepcopy(base); matched=[]
        for i,p in enumerate(body.get('permutations', [])):
            if condition(p['condition'], state): c.update(p['components']); matched.append(i)
        assert len(matched)==1
        short = {k.split(':',1)[1]: v for k,v in state.items()}
        source_state = {'age': short['age']}
        if 'shape' in short: source_state.update(type=short['shape'],waterlogged=str(short['waterlogged']).lower())
        skey = ','.join(f'{k}={v}' for k,v in sorted(source_state.items()))
        sv = variants[skey]
        assert sv.get('x',0)==sv.get('y',0)==0
        gid = c['minecraft:geometry']['identifier']
        case = next(x for x in cases if x['block']==name and x['binding']['geometry_id']==gid)
        source_ref = NS+str(Path(case['source_model']).relative_to(JAVA/'src/main/resources/assets/kaleidoscope_tavern/models')).removesuffix('.json')
        assert sv['model']==source_ref
        states.append({'states':state,'matched_permutations':matched,'source_state':skey,'source_model':sv['model'],
                       'effective_component_sources':{'minecraft:geometry':f'permutations/{matched[-1]}/components',
                          'minecraft:material_instances':f'permutations/{matched[-1]}/components','minecraft:item_visual':'components'},
                       'world_binding':binding(c['minecraft:geometry'],c['minecraft:material_instances']),
                       'item_binding':binding(c['minecraft:item_visual']['geometry'],c['minecraft:item_visual']['material_instances'])})
    item_paths = {loader: sorted(p for p in source_paths[pin] if p.endswith('/models/item/'+name+'.json')) for loader,pin in PINS.items()}
    assert all(not paths for paths in item_paths.values())
    owners.append({'owner': name, 'candidate': name in CANDIDATES, 'bp_path':path,'bp_sha256':sha(raw),
                   'render_method_counts':methods,'render_method_fields':len(allfields),'bindings':bindings,
                   'visual_declarations':declarations,'state_combinations':states,'source_blockstate_path':bstate_path,
                   'source_block_item_models':item_paths,
                   'item_limit':'No same-name Java item model on either pinned branch. Bedrock item_visual is the existing stage-zero block fallback, not a claim of normal grape/trellis item parity.'})
    if name in CANDIDATES:
        changed = copy.deepcopy(block); operations=[]
        for fp,before in allfields:
            if before == 'alpha_test_single_sided': continue
            assert 'material_instances' in fp or 'minecraft:material_instances' in fp
            setpath(changed,fp,'alpha_test_single_sided')
            operations.append({'op':'replace','path':'/'+ '/'.join(map(str,fp)), 'before':before,'value':'alpha_test_single_sided'})
        # The current canonical indentation/newline is exactly round-trippable.
        assert jdump(block)==raw
        normalized=copy.deepcopy(changed)
        for fp,before in allfields:setpath(normalized,fp,before)
        assert normalized==block
        proposals.append({'path':path,'before_sha256':sha(raw),'after_sha256':sha(jdump(changed)),
                          'serialization':'UTF-8 json.dumps(indent=2, ensure_ascii=False) plus newline',
                          'operations':operations,'other_fields_equal':True})

contracts = ['AGENTS.md','docs/BASELINE-MAINTENANCE.md','family/UPDATE-WORKFLOW.md',
 'tools/cultivation_source_contract.py','tools/test_cultivation_source_contract.py','tools/current_extension_source_contract.py',
 'tools/check_visuals.py','tools/refresh_visual_compat.py','runtime/BP/scripts/core/cultivation.js',
 'runtime/BP/scripts/bedrock/cultivation.js','tools/board-farm-interaction.test.mjs',
 'data/baseline-reconciliation.json','data/launch-repair-reference.json']
for p in contracts:data(REPO,PIN,p)
ledger=[]
for p in ['data/baseline-reconciliation.json','data/launch-repair-reference.json']:
    obj=read(REPO,PIN,p)
    for section in ['files','reviewedChanges']:
        for name in CANDIDATES:
            target='runtime/BP/blocks/'+name+'.json'
            if target in obj.get(section,{}):ledger.append({'path':p,'section':section,'affected_file':target})
for loader,pin in PINS.items():
    for rel in ['init/ModBlocks.java','init/ModItems.java','client/init/ClientSetupEvent.java','block/plant/GrapeCropBlock.java','block/plant/GrapevineTrellisBlock.java']:
        data(JAVA,pin,'src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/'+rel)

excerpts=[]
for loader,pin in PINS.items():
    for rel, markers in [('init/ModItems.java',['// 野生葡萄藤','// 龙头']),
                         ('init/ModBlocks.java',['RegistryObject<Block> WILD_GRAPEVINE','RegistryObject<Block> GOLD_GRAPE_CROP']),
                         ('block/plant/GrapeCropBlock.java',['getCloneItemStack']),
                         ('block/plant/GrapevineTrellisBlock.java',['getCloneItemStack'])]:
        path='src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/'+rel
        lines=data(JAVA,pin,path).decode().splitlines()
        # Bounded nearby evidence, with original line numbers and immutable source URL.
        wanted=set()
        if rel=='init/ModItems.java':
            for i,l in enumerate(lines):
                if re.search(r'\b(?:GRAPEVINE|TRELLIS|GRAPE|ICE_GRAPE|GOLD_GRAPE)\b',l): wanted.update(range(max(0,i-1),min(len(lines),i+5)))
            for name in CANDIDATES+CONTROLS:
                assert not re.search(r'ITEMS\.register\("'+name+r'"', '\n'.join(lines))
        elif rel=='init/ModBlocks.java':
            for i,l in enumerate(lines):
                if any('"'+name+'"' in l for name in CANDIDATES+CONTROLS):wanted.update(range(max(0,i-1),min(len(lines),i+5)))
        else:
            for i,l in enumerate(lines):
                if 'getCloneItemStack' in l:wanted.update(range(max(0,i-1),min(len(lines),i+4)))
        excerpts.append({'loader':loader,'commit':pin,'path':path,
             'url':f'https://github.com/KaleidoscopeMods/KaleidoscopeTavern/blob/{pin}/{path}',
             'lines':[{'line':i+1,'text':lines[i]} for i in sorted(wanted)]})
write('author-contract-excerpts.json',{'sources':excerpts,'same_name_block_items_registered':False,
 'limit':'These snippets establish distinct source items. Source clone-item behavior is not changed or declared equivalent to the native creative-pick adaptation.'})

summary={'candidates':CANDIDATES,'controls':CONTROLS,'candidate_changed_fields':sum(len(p['operations']) for p in proposals),
         'candidate_state_combinations':sum(len(o['state_combinations']) for o in owners if o['candidate']),
         'control_state_combinations':sum(len(o['state_combinations']) for o in owners if not o['candidate']),
         'distinct_models':len(models),'source_render_types':['cutout'],
         'no_runtime_files_written':True,'new_gui_views':0,'native_engine_acceptance':False}
write('route-audit.json',{'schema':1,'pin':PIN,'summary':summary,'owners':owners})
write('face-ownership.json',{'models':models,'limits':['Opposite directed quads are retained. No neighbor cullface does not disable GPU backface culling.','Prior exact ordered face mapping is reused only after source/geometry/PNG hash checks.','Known 336 plant faces have +/-0.08 displacement / 0.16 thickness; this is not exact source geometry.']})
write('proposal.json',{'state':'review_only_not_applied','pin':PIN,'version':'0.6.213','summary':summary,'files':proposals,
 'future_owner':{'resource_contract':'tools/cultivation_source_contract.py','negative_controls':'tools/test_cultivation_source_contract.py',
 'reason':'Existing cultivation owner already validates plants and shared runtime connections. Extend its current source-backed visual resource check for these four owners; do not create an A2/version-specific owner.',
 'retire_affected_historical_entries':ledger,'do_not_change':['wild_grapevine','wild_grapevine_plant',*CONTROLS,'geometry','textures','AO','face_dimming','item transforms','collision/selection','growth','state behavior']},
 'item_caveat':'Change the existing stage-zero native item_visual material fallback consistently. The six source block names have no corresponding Java item model; no item-pose or normal fruit/trellis item equivalence is claimed.',
 'limits':['No runtime edits, releases or remote publishing.','No new GUI work or engine execution.','Maintained Forge/NeoForge mappings, not exact loader archives.','No 26.1.2 renderer proof.']})
write('input-manifest.json',{'runtime_pin':PIN,'runtime_tree':git(REPO,'rev-parse',PIN+':runtime').decode().strip(),
 'source_pins':PINS,'inputs':list(inputs.values()),'preserved_contracts':contracts,
 'all_417_original_saved_input_hashes_rechecked':True,
 'previous_manifest_sha256':sha((OLD/'manifest.json').read_bytes()),
 'previous_face_audit_sha256':sha((OLD/'ordered-face-audit.json').read_bytes())})
print(json.dumps(summary,indent=2))
