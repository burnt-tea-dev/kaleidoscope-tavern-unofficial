"""Reuse hash-checked bounded official-class and loader-source evidence.

No archive download, class execution, or claim of a new engine test.
"""
from pathlib import Path
import hashlib,json
H=Path(__file__).resolve().parent
S=H.parent/'tavern-wild-vine-review-20261109/material-route-review'
O=H/'semantic-evidence';O.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
p=json.loads((S/'proposal.json').read_bytes());sources=[]
for name in ['java-1.20.1-culling.json','java-1.21.1-culling.json']:
    raw=(S/name).read_bytes();(O/name).write_bytes(raw)
    sources.append({'source':str(S/name),'copy':'semantic-evidence/'+name,'sha256':sha(raw),'reused_existing_class_data_analysis':True})
for loader,key in [('Forge','forge_mapping'),('NeoForge','neoforge_mapping')]:
    for f in p[key]['sources']:
        raw=(S/f['file']).read_bytes();assert sha(raw)==f['sha256']
        sources.append({**f,'loader':loader,'verified_local_path':str(S/f['file'])})
result={k:p[k] for k in ['bedrock','java_world','forge_mapping','neoforge_mapping','limits']}
result.update(state='reused_pinned_semantic_proof_not_new_engine_execution',local_sources=sources,
              source_proposal_sha256=sha((S/'proposal.json').read_bytes()),source_proposal=str(S/'proposal.json'))
(O/'provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print('Verified reused class-data summaries and four pinned loader source hashes; no download or execution.')
