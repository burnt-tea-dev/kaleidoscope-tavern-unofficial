"""Copy exact reviewed scenes; isolate a shared native texture only when needed.

Does not rebuild geometry, run a GUI, or alter screenshots or runtime files.
"""
from pathlib import Path
import base64, copy, hashlib, json, uuid
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'tavern-next-decor-review-20261108'
OUT=HERE/'scenes'; OUT.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda v:(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
read=lambda p:json.loads(p.read_bytes())
manifest=read(OLD/'manifest.json')
review=read(OLD/'gui-evidence-20261109/review.json')
mandatory=['grape-crop-stages-2','gold_grape-crop-stages-2','ice_grape-crop-stages-2','grapevine-shapes-stages-2']
controls=['gold_grapevine-shapes-stages-2','ice_grapevine-shapes-stages-2']
records=[];queue=[]

def leaves(node):
    for child in node['children']:
        if isinstance(child,str): yield child
        else: yield from leaves(child)

for stem in mandatory+controls:
    name=stem+'.bbmodel';source=OLD/'scenes'/name;raw=source.read_bytes();obj=json.loads(raw)
    oldrec=next(r for r in manifest['scenes'] if Path(r['file']).name==name)
    assert sha(raw)==oldrec['sha256']
    # Original source, native geometry, PNGs, UUIDs, groups and hierarchy preserved byte-for-byte.
    original=OUT/(stem+'--original-front.bbmodel');original.write_bytes(raw)
    byuuid={e['uuid']:e for e in obj['elements']}
    groups={g['uuid']:g for g in obj['groups']}
    rootnodes={n['uuid']:n for n in obj['outliner']}
    source_ids=set();native_ids=set();old_double_ids=set();fixed_ids=set()
    for uid,node in rootnodes.items():
        group=groups[uid]
        ids=set(leaves(node))
        if group['name'].startswith('Source '):source_ids.update(ids)
        else:
            assert group['name'].startswith('Native ')
            native_ids.update(ids)
            if stem.startswith('grapevine-') and 'single_stage' not in group['name']:fixed_ids.update(ids)
            else:old_double_ids.update(ids)
    source_tex={f['texture'] for u in source_ids for f in byuuid[u]['faces'].values() if f['texture'] is not None}
    native_tex={f['texture'] for u in native_ids for f in byuuid[u]['faces'].values() if f['texture'] is not None}
    assert not source_tex&native_tex, 'This original already separates source/native texture entries'
    assert source_ids|native_ids==set(byuuid)
    assert all(t['render_sides']=='front' for t in obj['textures'])
    rec={'scene':stem,'role':'candidate' if stem in mandatory else 'already_single_sided_A3_control',
         'original_input':str(source),'original_sha256':sha(raw),'original_front':str(original.relative_to(HERE)),
         'cases':[{k:c[k] for k in ['label','block','states','source_world_offset','native_world_offset']} for c in manifest['cases'] if c['scene']==name],
         'source_element_uuids':sorted(source_ids),'native_element_uuids':sorted(native_ids),
         'source_texture_indices':sorted(source_tex),'native_texture_indices':sorted(native_tex),
         'source_and_native_share_texture_entry':False,'existing_front_captures':[]}
    for imgrec in review['images']:
        if imgrec['file'].startswith(stem+'-'):
            p=OLD/'gui-evidence-20261109'/imgrec['file'];assert sha(p.read_bytes())==imgrec['sha256']
            rec['existing_front_captures'].append({**imgrec,'path':str(p),'reused_not_new':True})
    if stem in controls:
        rec['new_capture_required']=False;records.append(rec);continue
    front=copy.deepcopy(obj);binding_changes=[];isolations=[]
    # The ordinary vine scene also contains north_south, which is ALREADY single-sided.
    # Give only that native connected group a pixel-identical separate texture entry.
    # Existing source and single-stage native entries and all their UUIDs are untouched.
    for ti in sorted(native_tex):
        shared={u for u in fixed_ids if any(f['texture']==ti for f in byuuid[u]['faces'].values())}
        changing={u for u in old_double_ids if any(f['texture']==ti for f in byuuid[u]['faces'].values())}
        if shared and changing:
            newi=len(front['textures']);tex=copy.deepcopy(front['textures'][ti])
            tex['id']=str(newi)
            tex['uuid']=str(uuid.uuid5(uuid.NAMESPACE_URL, 'plant-culling-review/'+sha(raw)+'/fixed-native/'+str(ti)))
            front['textures'].append(tex)
            isolations.append({'old_index':ti,'new_index':newi,'new_uuid':tex['uuid'],
                               'reason':'Keep already-correct north_south Front while single-stage native texture alone becomes Double.',
                               'embedded_png_sha256':sha(base64.b64decode(tex['source'].split(',',1)[1]))})
            for ei,element in enumerate(front['elements']):
                if element['uuid'] in shared:
                    for direction,face in element['faces'].items():
                        if face['texture']==ti:
                            binding_changes.append({'path':['elements',ei,'faces',direction,'texture'],'before':ti,'after':newi})
                            face['texture']=newi
    double=copy.deepcopy(front)
    changed_textures=sorted({f['texture'] for e in front['elements'] if e['uuid'] in old_double_ids for f in e['faces'].values() if f['texture'] is not None})
    for ti in changed_textures:double['textures'][ti]['render_sides']='double'
    frontpath=OUT/(stem+'--policy-front.bbmodel');doublepath=OUT/(stem+'--old-policy-double.bbmodel')
    frontpath.write_bytes(raw if not isolations else dump(front))
    doublepath.write_bytes(dump(double))
    rec.update(policy_front=str(frontpath.relative_to(HERE)),policy_front_sha256=sha(frontpath.read_bytes()),
               old_policy_double=str(doublepath.relative_to(HERE)),old_policy_double_sha256=sha(doublepath.read_bytes()),
               changed_texture_indices=changed_textures,texture_isolations=isolations,binding_changes=binding_changes,
               changed_native_element_uuids=sorted(old_double_ids),preserved_connected_native_uuids=sorted(fixed_ids),
               one_factor_comparison='policy-front versus old-policy-double differs only at named texture render_sides front→double fields')
    views=['oblique-orthographic','reverse-orthographic']
    if stem.startswith('grapevine-'):views.append('reverse-low-orthographic')
    for view in views:
        reference=next(r for r in rec['existing_front_captures'] if r['view']==view)
        queue.append({'scene':stem,'view':view,'front_file':rec['policy_front'],'double_file':rec['old_policy_double'],
                      'reference_front_capture':reference['path'],'reference_sha256':reference['sha256'],
                      'camera_identity':reference['direction'],
                      'capture_order':['policy_front','old_policy_double'],'save_numeric_camera_on_first_capture':True,
                      'same_camera_between_pair_required':True,
                      'inspect':'Authored forward face and transparent holes; opposite mirrored fill from the reverse-directed face. For vine, north_south must stay unchanged and single-stage leaf sheets are the only policy variable.'})
    records.append(rec)

(HERE/'control-manifest.json').write_bytes(dump({'state':'prepared_not_gui_reviewed','scenes':records,
 'preservation':'Original bytes retained. Existing UUIDs/elements/UVs/hierarchy unchanged except listed face texture indices for pixel-identical texture isolation. PNG bytes unchanged.',
 'numeric_camera_limit':'Old JPEG receipts identify camera side/projection, not numeric camera matrices. New pair must record and preserve actual camera; do not claim pixel-aligned historical camera reproduction.'}))
(HERE/'capture-queue.json').write_bytes(dump({'state':'pending_parent_scheduled_GUI','queue':queue,'new_raw_capture_count':2*len(queue),
 'control_reuse_only':controls,'no_engine_claim':True,
 'instructions':['Use official Blockbench 5.2.2 free scenes, not bare Bedrock geometry imports.','Open exact files and do not save back. Preserve texture PNGs and model data.','Model names intentionally remain unchanged. Verify texture index 1 Front/Double in the UI before each capture; do not infer variant from the shared model title.','Record first camera position/target/projection/zoom through an authorized UI workflow if available; otherwise explicitly report missing numeric record.','Use matching view and exact same actual camera for each Front/Double pair. Existing JPEG references are orientation guides, not numeric camera evidence.','Capture raw unmodified application screenshots and visually inspect each. No synthesized or edited evidence.','Front/Double is an editor material control only, not BP material or native Bedrock execution.']}))
print(json.dumps({'scenes':len(records),'mandatory_pairs':len(queue),'new_raw_capture_count':len(queue)*2,'new_GUI_work':False}))
