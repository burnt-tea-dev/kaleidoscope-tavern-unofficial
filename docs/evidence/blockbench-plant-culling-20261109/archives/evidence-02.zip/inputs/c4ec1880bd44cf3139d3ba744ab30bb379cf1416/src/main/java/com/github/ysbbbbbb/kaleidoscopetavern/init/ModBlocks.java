package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.KaleidoscopeTavern;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.*;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.*;
import com.github.ysbbbbbb.kaleidoscopetavern.block.mixology.*;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.*;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.*;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.*;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.ShakerBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.SignatureCocktailBlockEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@SuppressWarnings("DataFlowIssue")
public interface ModBlocks {
    DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, KaleidoscopeTavern.MOD_ID);
    DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, KaleidoscopeTavern.MOD_ID);

    // 装饰部分
    // 沙发
    RegistryObject<Block> WHITE_SOFA = BLOCKS.register("white_sofa", SofaBlock::new);
    RegistryObject<Block> LIGHT_GRAY_SOFA = BLOCKS.register("light_gray_sofa", SofaBlock::new);
    RegistryObject<Block> GRAY_SOFA = BLOCKS.register("gray_sofa", SofaBlock::new);
    RegistryObject<Block> BLACK_SOFA = BLOCKS.register("black_sofa", SofaBlock::new);
    RegistryObject<Block> BROWN_SOFA = BLOCKS.register("brown_sofa", SofaBlock::new);
    RegistryObject<Block> RED_SOFA = BLOCKS.register("red_sofa", SofaBlock::new);
    RegistryObject<Block> ORANGE_SOFA = BLOCKS.register("orange_sofa", SofaBlock::new);
    RegistryObject<Block> YELLOW_SOFA = BLOCKS.register("yellow_sofa", SofaBlock::new);
    RegistryObject<Block> LIME_SOFA = BLOCKS.register("lime_sofa", SofaBlock::new);
    RegistryObject<Block> GREEN_SOFA = BLOCKS.register("green_sofa", SofaBlock::new);
    RegistryObject<Block> CYAN_SOFA = BLOCKS.register("cyan_sofa", SofaBlock::new);
    RegistryObject<Block> LIGHT_BLUE_SOFA = BLOCKS.register("light_blue_sofa", SofaBlock::new);
    RegistryObject<Block> BLUE_SOFA = BLOCKS.register("blue_sofa", SofaBlock::new);
    RegistryObject<Block> PURPLE_SOFA = BLOCKS.register("purple_sofa", SofaBlock::new);
    RegistryObject<Block> MAGENTA_SOFA = BLOCKS.register("magenta_sofa", SofaBlock::new);
    RegistryObject<Block> PINK_SOFA = BLOCKS.register("pink_sofa", SofaBlock::new);

    // 高脚凳
    RegistryObject<Block> WHITE_BAR_STOOL = BLOCKS.register("white_bar_stool", () -> new BarStoolBlock(DyeColor.WHITE));
    RegistryObject<Block> LIGHT_GRAY_BAR_STOOL = BLOCKS.register("light_gray_bar_stool", () -> new BarStoolBlock(DyeColor.LIGHT_GRAY));
    RegistryObject<Block> GRAY_BAR_STOOL = BLOCKS.register("gray_bar_stool", () -> new BarStoolBlock(DyeColor.GRAY));
    RegistryObject<Block> BLACK_BAR_STOOL = BLOCKS.register("black_bar_stool", () -> new BarStoolBlock(DyeColor.BLACK));
    RegistryObject<Block> BROWN_BAR_STOOL = BLOCKS.register("brown_bar_stool", () -> new BarStoolBlock(DyeColor.BROWN));
    RegistryObject<Block> RED_BAR_STOOL = BLOCKS.register("red_bar_stool", () -> new BarStoolBlock(DyeColor.RED));
    RegistryObject<Block> ORANGE_BAR_STOOL = BLOCKS.register("orange_bar_stool", () -> new BarStoolBlock(DyeColor.ORANGE));
    RegistryObject<Block> YELLOW_BAR_STOOL = BLOCKS.register("yellow_bar_stool", () -> new BarStoolBlock(DyeColor.YELLOW));
    RegistryObject<Block> LIME_BAR_STOOL = BLOCKS.register("lime_bar_stool", () -> new BarStoolBlock(DyeColor.LIME));
    RegistryObject<Block> GREEN_BAR_STOOL = BLOCKS.register("green_bar_stool", () -> new BarStoolBlock(DyeColor.GREEN));
    RegistryObject<Block> CYAN_BAR_STOOL = BLOCKS.register("cyan_bar_stool", () -> new BarStoolBlock(DyeColor.CYAN));
    RegistryObject<Block> LIGHT_BLUE_BAR_STOOL = BLOCKS.register("light_blue_bar_stool", () -> new BarStoolBlock(DyeColor.LIGHT_BLUE));
    RegistryObject<Block> BLUE_BAR_STOOL = BLOCKS.register("blue_bar_stool", () -> new BarStoolBlock(DyeColor.BLUE));
    RegistryObject<Block> PURPLE_BAR_STOOL = BLOCKS.register("purple_bar_stool", () -> new BarStoolBlock(DyeColor.PURPLE));
    RegistryObject<Block> MAGENTA_BAR_STOOL = BLOCKS.register("magenta_bar_stool", () -> new BarStoolBlock(DyeColor.MAGENTA));
    RegistryObject<Block> PINK_BAR_STOOL = BLOCKS.register("pink_bar_stool", () -> new BarStoolBlock(DyeColor.PINK));

    // 黑板
    RegistryObject<Block> CHALKBOARD = BLOCKS.register("chalkboard", ChalkboardBlock::new);
    RegistryObject<Block> TABLE = BLOCKS.register("table", TableBlock::new);

    // 展板
    RegistryObject<Block> BASE_SANDWICH_BOARD = BLOCKS.register("base_sandwich_board", SandwichBoardBlock::new);
    RegistryObject<Block> GRASS_SANDWICH_BOARD = BLOCKS.register("grass_sandwich_board", () -> new SandwichBoardBlock(Items.GRASS));
    RegistryObject<Block> ALLIUM_SANDWICH_BOARD = BLOCKS.register("allium_sandwich_board", () -> new SandwichBoardBlock(Items.ALLIUM));
    RegistryObject<Block> AZURE_BLUET_SANDWICH_BOARD = BLOCKS.register("azure_bluet_sandwich_board", () -> new SandwichBoardBlock(Items.AZURE_BLUET, Items.OXEYE_DAISY, Items.LILY_OF_THE_VALLEY));
    RegistryObject<Block> CORNFLOWER_SANDWICH_BOARD = BLOCKS.register("cornflower_sandwich_board", () -> new SandwichBoardBlock(Items.CORNFLOWER));
    RegistryObject<Block> ORCHID_SANDWICH_BOARD = BLOCKS.register("orchid_sandwich_board", () -> new SandwichBoardBlock(Items.BLUE_ORCHID));
    RegistryObject<Block> PEONY_SANDWICH_BOARD = BLOCKS.register("peony_sandwich_board", () -> new SandwichBoardBlock(Items.PEONY, Items.LILAC));
    RegistryObject<Block> PINK_PETALS_SANDWICH_BOARD = BLOCKS.register("pink_petals_sandwich_board", () -> new SandwichBoardBlock(Items.PINK_PETALS));
    RegistryObject<Block> PITCHER_PLANT_SANDWICH_BOARD = BLOCKS.register("pitcher_plant_sandwich_board", () -> new SandwichBoardBlock(Items.PITCHER_PLANT));
    RegistryObject<Block> POPPY_SANDWICH_BOARD = BLOCKS.register("poppy_sandwich_board", () -> new SandwichBoardBlock(Items.POPPY, Items.ROSE_BUSH));
    RegistryObject<Block> SUNFLOWER_SANDWICH_BOARD = BLOCKS.register("sunflower_sandwich_board", () -> new SandwichBoardBlock(Items.SUNFLOWER, Items.DANDELION));
    RegistryObject<Block> TORCHFLOWER_SANDWICH_BOARD = BLOCKS.register("torchflower_sandwich_board", () -> new SandwichBoardBlock(Items.TORCHFLOWER));
    RegistryObject<Block> TULIP_SANDWICH_BOARD = BLOCKS.register("tulip_sandwich_board", () -> new SandwichBoardBlock(Items.RED_TULIP, Items.ORANGE_TULIP, Items.WHITE_TULIP, Items.PINK_TULIP));
    RegistryObject<Block> WITHER_ROSE_SANDWICH_BOARD = BLOCKS.register("wither_rose_sandwich_board", () -> new SandwichBoardBlock(Items.WITHER_ROSE));

    // 彩灯
    RegistryObject<Block> STRING_LIGHTS_COLORLESS = BLOCKS.register("string_lights_colorless", () -> new StringLightsBlock(null));
    RegistryObject<Block> STRING_LIGHTS_WHITE = BLOCKS.register("string_lights_white", () -> new StringLightsBlock(Items.WHITE_DYE));
    RegistryObject<Block> STRING_LIGHTS_LIGHT_GRAY = BLOCKS.register("string_lights_light_gray", () -> new StringLightsBlock(Items.LIGHT_GRAY_DYE));
    RegistryObject<Block> STRING_LIGHTS_GRAY = BLOCKS.register("string_lights_gray", () -> new StringLightsBlock(Items.GRAY_DYE));
    RegistryObject<Block> STRING_LIGHTS_BLACK = BLOCKS.register("string_lights_black", () -> new StringLightsBlock(Items.BLACK_DYE));
    RegistryObject<Block> STRING_LIGHTS_BROWN = BLOCKS.register("string_lights_brown", () -> new StringLightsBlock(Items.BROWN_DYE));
    RegistryObject<Block> STRING_LIGHTS_RED = BLOCKS.register("string_lights_red", () -> new StringLightsBlock(Items.RED_DYE));
    RegistryObject<Block> STRING_LIGHTS_ORANGE = BLOCKS.register("string_lights_orange", () -> new StringLightsBlock(Items.ORANGE_DYE));
    RegistryObject<Block> STRING_LIGHTS_YELLOW = BLOCKS.register("string_lights_yellow", () -> new StringLightsBlock(Items.YELLOW_DYE));
    RegistryObject<Block> STRING_LIGHTS_LIME = BLOCKS.register("string_lights_lime", () -> new StringLightsBlock(Items.LIME_DYE));
    RegistryObject<Block> STRING_LIGHTS_GREEN = BLOCKS.register("string_lights_green", () -> new StringLightsBlock(Items.GREEN_DYE));
    RegistryObject<Block> STRING_LIGHTS_CYAN = BLOCKS.register("string_lights_cyan", () -> new StringLightsBlock(Items.CYAN_DYE));
    RegistryObject<Block> STRING_LIGHTS_LIGHT_BLUE = BLOCKS.register("string_lights_light_blue", () -> new StringLightsBlock(Items.LIGHT_BLUE_DYE));
    RegistryObject<Block> STRING_LIGHTS_BLUE = BLOCKS.register("string_lights_blue", () -> new StringLightsBlock(Items.BLUE_DYE));
    RegistryObject<Block> STRING_LIGHTS_PURPLE = BLOCKS.register("string_lights_purple", () -> new StringLightsBlock(Items.PURPLE_DYE));
    RegistryObject<Block> STRING_LIGHTS_MAGENTA = BLOCKS.register("string_lights_magenta", () -> new StringLightsBlock(Items.MAGENTA_DYE));
    RegistryObject<Block> STRING_LIGHTS_PINK = BLOCKS.register("string_lights_pink", () -> new StringLightsBlock(Items.PINK_DYE));

    // 挂画
    RegistryObject<Block> YSBB_PAINTING = BLOCKS.register("ysbb_painting", PaintingBlock::new);
    RegistryObject<Block> TARTARIC_ACID_PAINTING = BLOCKS.register("tartaric_acid_painting", PaintingBlock::new);
    RegistryObject<Block> CR019_PAINTING = BLOCKS.register("cr019_painting", PaintingBlock::new);
    RegistryObject<Block> UNKNOWN_PAINTING = BLOCKS.register("unknown_painting", PaintingBlock::new);
    RegistryObject<Block> MASTER_MARISA_PAINTING = BLOCKS.register("master_marisa_painting", PaintingBlock::new);
    RegistryObject<Block> SON_OF_MAN_PAINTING = BLOCKS.register("son_of_man_painting", PaintingBlock::new);
    RegistryObject<Block> DAVID_PAINTING = BLOCKS.register("david_painting", PaintingBlock::new);
    RegistryObject<Block> GIRL_WITH_PEARL_EARRING_PAINTING = BLOCKS.register("girl_with_pearl_earring_painting", PaintingBlock::new);
    RegistryObject<Block> STARRY_NIGHT_PAINTING = BLOCKS.register("starry_night_painting", PaintingBlock::new);
    RegistryObject<Block> VAN_GOGH_SELF_PORTRAIT_PAINTING = BLOCKS.register("van_gogh_self_portrait_painting", PaintingBlock::new);
    RegistryObject<Block> FATHER_PAINTING = BLOCKS.register("father_painting", PaintingBlock::new);
    RegistryObject<Block> GREAT_WAVE_PAINTING = BLOCKS.register("great_wave_painting", PaintingBlock::new);
    RegistryObject<Block> MONA_LISA_PAINTING = BLOCKS.register("mona_lisa_painting", PaintingBlock::new);
    RegistryObject<Block> MONDRIAN_PAINTING = BLOCKS.register("mondrian_painting", PaintingBlock::new);

    // 垂灯
    RegistryObject<Block> BELL_PENDANT_LAMP = BLOCKS.register("bell_pendant_lamp", PendantLampBlock::new);
    RegistryObject<Block> YELLOW_PENDANT_LAMP = BLOCKS.register("yellow_pendant_lamp", PendantLampBlock::new);
    RegistryObject<Block> BLUE_PENDANT_LAMP = BLOCKS.register("blue_pendant_lamp", PendantLampBlock::new);

    // 香薰
    RegistryObject<Block> SAKURA_INCENSE = BLOCKS.register("sakura_incense", () -> new IncenseBlock(
            ModParticles.SAKURA_INCENSE_PARTICLE, () -> ParticleTypes.CHERRY_LEAVES
    ));

    RegistryObject<Block> PINE_INCENSE = BLOCKS.register("pine_incense", () -> new IncenseBlock(
            ModParticles.PINE_INCENSE_PARTICLE, ModParticles.PINE_INCENSE_LARGE_PARTICLE
    ));

    RegistryObject<Block> GINKGO_INCENSE = BLOCKS.register("ginkgo_incense", () -> new IncenseBlock(
            ModParticles.GINKGO_INCENSE_PARTICLE, ModParticles.GINKGO_INCENSE_LARGE_PARTICLE
    ));

    RegistryObject<Block> SPORE_INCENSE = BLOCKS.register("spore_incense", () -> new IncenseBlock(
            ModParticles.SPORE_INCENSE_PARTICLE, () -> ParticleTypes.SPORE_BLOSSOM_AIR
    ));

    RegistryObject<Block> CATNIP_INCENSE = BLOCKS.register("catnip_incense", () -> new IncenseBlock(
            ModParticles.CATNIP_INCENSE_PARTICLE, ModParticles.CATNIP_INCENSE_LARGE_PARTICLE
    ));

    RegistryObject<Block> SNOW_INCENSE = BLOCKS.register("snow_incense", () -> new IncenseBlock(
            ModParticles.SNOW_INCENSE_PARTICLE, ModParticles.SNOW_INCENSE_LARGE_PARTICLE
    ));

    RegistryObject<Block> BUTTERFLY_INCENSE = BLOCKS.register("butterfly_incense", () -> new IncenseBlock(
            ModParticles.BUTTERFLY_INCENSE_PARTICLE, ModParticles.BUTTERFLY_INCENSE_LARGE_PARTICLE
    ));

    RegistryObject<Block> FIREFLY_INCENSE = BLOCKS.register("firefly_incense", () -> new IncenseBlock(
            ModParticles.FIREFLY_INCENSE_PARTICLE, ModParticles.FIREFLY_INCENSE_LARGE_PARTICLE,
            -0.67, 5.33
    ));

    // 吧台
    RegistryObject<Block> BAR_COUNTER = BLOCKS.register("bar_counter", BarCounterBlock::new);
    // 人字梯
    RegistryObject<Block> STEPLADDER = BLOCKS.register("stepladder", StepladderBlock::new);
    // 野生葡萄藤
    RegistryObject<Block> WILD_GRAPEVINE = BLOCKS.register("wild_grapevine", WildGrapevineBlock::new);
    RegistryObject<Block> WILD_GRAPEVINE_PLANT = BLOCKS.register("wild_grapevine_plant", WildGrapevinePlantBlock::new);
    // 藤架
    RegistryObject<Block> TRELLIS = BLOCKS.register("trellis", TrellisBlock::new);

    // 葡萄藤
    RegistryObject<Block> GRAPEVINE_TRELLIS = BLOCKS.register("grapevine_trellis", () -> new GrapevineTrellisBlock(
            (state, level, pos, random) -> 0.25F,
            () -> ModBlocks.GRAPE_CROP.get().defaultBlockState()
    ));
    RegistryObject<Block> ICE_GRAPEVINE_TRELLIS = BLOCKS.register("ice_grapevine_trellis", () -> new GrapevineTrellisBlock(
            (state, level, pos, random) ->
                    level.getBiome(pos).get().getBaseTemperature() < 0.15F ? 0.8F : 0.25F,
            () -> ModBlocks.ICE_GRAPE_CROP.get().defaultBlockState()
    ));
    RegistryObject<Block> GOLD_GRAPEVINE_TRELLIS = BLOCKS.register("gold_grapevine_trellis", () -> new GrapevineTrellisBlock(
            (state, level, pos, random) ->
                    level.getBiome(pos).get().getBaseTemperature() > 1.0F ? 0.8F : 0.25F,
            () -> ModBlocks.GOLD_GRAPE_CROP.get().defaultBlockState()
    ));

    // 葡萄
    RegistryObject<Block> GRAPE_CROP = BLOCKS.register("grape_crop", () -> new GrapeCropBlock(
            (state, level, pos, random) -> 0.25F,
            () -> new ItemStack(ModItems.GRAPE.get(), 3)
    ));
    RegistryObject<Block> ICE_GRAPE_CROP = BLOCKS.register("ice_grape_crop", () -> new GrapeCropBlock(
            (state, level, pos, random) ->
                    level.getBiome(pos).get().getBaseTemperature() < 0.15F ? 0.8F : 0.25F,
            () -> new ItemStack(ModItems.ICE_GRAPE.get(), 3)
    ));
    RegistryObject<Block> GOLD_GRAPE_CROP = BLOCKS.register("gold_grape_crop", () -> new GrapeCropBlock(
            (state, level, pos, random) ->
                    level.getBiome(pos).get().getBaseTemperature() > 1.0F ? 0.8F : 0.25F,
            () -> new ItemStack(ModItems.GOLD_GRAPE.get(), 3)
    ));


    // 果盆
    RegistryObject<Block> PRESSING_TUB = BLOCKS.register("pressing_tub", PressingTubBlock::new);
    // 龙头
    RegistryObject<Block> TAP = BLOCKS.register("tap", TapBlock::new);

    // 酒杯架
    RegistryObject<Block> GLASSWARE_HOLDER = BLOCKS.register("glassware_holder", GlasswareHolderBlock::new);

    // 空瓶
    RegistryObject<Block> EMPTY_BOTTLE = BLOCKS.register("empty_bottle", BottleBlock::new);
    RegistryObject<Block> EMPTY_GLASSWARE = BLOCKS.register("empty_glassware", GlasswareBlock::new);

    // 鸡尾酒
    RegistryObject<Block> SIGNATURE_COCKTAIL = BLOCKS.register("signature_cocktail", SignatureCocktailBlock::new);
    RegistryObject<Block> MYSTERY_COCKTAIL = BLOCKS.register("mystery_cocktail", MysteryCocktailBlock::new);
    RegistryObject<Block> WHITE_LADY = BLOCKS.register("white_lady", CocktailBlock::new);
    RegistryObject<Block> EMERALD = BLOCKS.register("emerald", CocktailBlock::new);
    RegistryObject<Block> BRASS_HEART = BLOCKS.register("brass_heart", CocktailBlock::new);
    RegistryObject<Block> GODFATHER = BLOCKS.register("godfather", CocktailBlock::new);
    RegistryObject<Block> GRASSHOPPER = BLOCKS.register("grasshopper", CocktailBlock::new);
    RegistryObject<Block> SCREWDRIVER = BLOCKS.register("screwdriver", CocktailBlock::new);
    RegistryObject<Block> MOJITO = BLOCKS.register("mojito", CocktailBlock::new);
    RegistryObject<Block> ALLIUM_GARDEN = BLOCKS.register("allium_garden", CocktailBlock::new);
    RegistryObject<Block> DEPTH_CHARGE = BLOCKS.register("depth_charge", CocktailBlock::new);
    RegistryObject<Block> NETHER_SPECIAL = BLOCKS.register("nether_special", CocktailBlock::new);
    RegistryObject<Block> BLOODY_MARY = BLOCKS.register("bloody_mary", CocktailBlock::new);
    RegistryObject<Block> SCULK_SPECIAL = BLOCKS.register("sculk_special", CocktailBlock::new);

    // 雪克杯
    RegistryObject<Block> SHAKER = BLOCKS.register("shaker", ShakerBlock::new);

    // 燃烧瓶
    RegistryObject<Block> MOLOTOV = BLOCKS.register("molotov", MolotovBlock::new);
    // 酒桶
    RegistryObject<Block> BARREL = BLOCKS.register("barrel", BarrelBlock::new);
    // 酒柜
    RegistryObject<Block> BAR_CABINET = BLOCKS.register("bar_cabinet", BarCabinetBlock::new);
    RegistryObject<Block> GLASS_BAR_CABINET = BLOCKS.register("glass_bar_cabinet", BarCabinetBlock::new);
    RegistryObject<Block> CELLAR_CABINET = BLOCKS.register("cellar_cabinet", CellarCabinetBlock::new);

    // 酒架
    RegistryObject<Block> TILTED_RACK = BLOCKS.register("tilted_rack", TiltedRackBlock::new);
    RegistryObject<Block> CIRCULAR_RACK = BLOCKS.register("circular_rack", CircularRackBlock::new);
    RegistryObject<Block> HOLDER = BLOCKS.register("holder", HolderBlock::new);

    // 杂项的瓶子
    RegistryObject<Block> WATER_BOTTLE = BLOCKS.register("water_bottle", BottleBlock::simpleBottle);
    RegistryObject<Block> HONEY_BOTTLE = BLOCKS.register("honey_bottle", BottleBlock::simpleBottle);
    RegistryObject<Block> DRAGON_BREATH_BOTTLE = BLOCKS.register("dragon_breath_bottle", BottleBlock::simpleBottle);
    RegistryObject<Block> POTION_BOTTLE = BLOCKS.register("potion_bottle", PotionBottleBlock::new);
    RegistryObject<Block> XP_BOTTLE = BLOCKS.register("xp_bottle", BottleBlock::simpleBottle);

    // 酒
    RegistryObject<Block> WINE = BLOCKS.register("wine", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> CHAMPAGNE = BLOCKS.register("champagne", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> VODKA = BLOCKS.register("vodka", DrinkBlock.create().maxCount(4).shapes(
            Block.box(4, 0, 4, 12, 15, 12),
            Block.box(0, 0, 4, 16, 15, 12),
            Shapes.or(
                    Block.box(0, 0, 8, 16, 15, 16),
                    Block.box(4, 0, 0, 12, 15, 16)
            ),
            Block.box(0, 0, 0, 16, 16, 16)
    ).build());

    RegistryObject<Block> BRANDY = BLOCKS.register("brandy", DrinkBlock.create().maxCount(3).shapes(
            Block.box(3, 0, 6, 13, 13, 10),
            Block.box(1, 0, 3, 15, 12, 12),
            Block.box(1, 0, 1, 16, 12, 13)
    ).build());

    RegistryObject<Block> CARIGNAN = BLOCKS.register("carignan", DrinkBlock.create().maxCount(3).shapes(
            Block.box(3, 0, 6, 13, 12, 10),
            Block.box(1, 0, 3, 15, 12, 12),
            Block.box(0, 0, 1, 16, 12, 13)
    ).build());

    RegistryObject<Block> SAKURA_WINE = BLOCKS.register("sakura_wine", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> PLUM_WINE = BLOCKS.register("plum_wine", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 12, 10),
            Block.box(3, 0, 6, 13, 12, 10),
            Shapes.or(
                    Block.box(3, 0, 9, 13, 12, 13),
                    Block.box(6, 0, 3, 10, 12, 13)
            ),
            Block.box(3, 0, 3, 13, 12, 13)
    ).build());

    RegistryObject<Block> WHISKEY = BLOCKS.register("whiskey", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> ICE_WINE = BLOCKS.register("ice_wine", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> POLARIS_SWEET_WHITE = BLOCKS.register("polaris_sweet_white", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> HONEY_WINE = BLOCKS.register("honey_wine", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> RED_QUEEN = BLOCKS.register("red_queen", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> MINERS_STAR = BLOCKS.register("miners_star", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> RUM = BLOCKS.register("rum", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> RIESLING_DRY_WHITE = BLOCKS.register("riesling_dry_white", DrinkBlock.create().maxCount(4).shapes(
            Block.box(4, 0, 4, 12, 15, 12),
            Block.box(0, 0, 4, 16, 15, 12),
            Shapes.or(
                    Block.box(0, 0, 8, 16, 15, 16),
                    Block.box(4, 0, 0, 12, 15, 16)
            ),
            Block.box(0, 0, 0, 16, 16, 16)
    ).build());

    RegistryObject<Block> SUNSET_GLOW = BLOCKS.register("sunset_glow", DrinkBlock.create().maxCount(3).shapes(
            Block.box(3, 0, 6, 13, 13, 10),
            Block.box(1, 0, 3, 15, 12, 12),
            Block.box(1, 0, 1, 16, 12, 13)
    ).build());

    RegistryObject<Block> MADAME_SHEXIANG = BLOCKS.register("madame_shexiang", DrinkBlock.create().maxCount(4).shapes(
            Block.box(4, 0, 4, 12, 15, 12),
            Block.box(0, 0, 4, 16, 15, 12),
            Shapes.or(
                    Block.box(0, 0, 8, 16, 15, 16),
                    Block.box(4, 0, 0, 12, 15, 16)
            ),
            Block.box(0, 0, 0, 16, 16, 16)
    ).build());

    RegistryObject<Block> SWEET_BERRY_WINE = BLOCKS.register("sweet_berry_wine", DrinkBlock.create().maxCount(4).shapes(
            Block.box(4, 0, 4, 12, 15, 12),
            Block.box(0, 0, 4, 16, 15, 12),
            Shapes.or(
                    Block.box(0, 0, 8, 16, 15, 16),
                    Block.box(4, 0, 0, 12, 15, 16)
            ),
            Block.box(0, 0, 0, 16, 16, 16)
    ).build());

    RegistryObject<Block> SHERRY = BLOCKS.register("sherry", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> MOTHER_SNOW = BLOCKS.register("mother_snow", DrinkBlock.create().maxCount(4).shapes(
            Block.box(4, 0, 4, 12, 15, 12),
            Block.box(0, 0, 4, 16, 15, 12),
            Shapes.or(
                    Block.box(0, 0, 8, 16, 15, 16),
                    Block.box(4, 0, 0, 12, 15, 16)
            ),
            Block.box(0, 0, 0, 16, 16, 16)
    ).build());

    RegistryObject<Block> LUMINOUS_BRIDE = BLOCKS.register("luminous_bride", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> GLOWFLOWER_BREW = BLOCKS.register("glowflower_brew", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> SAUVIGNON_BLANC_DRY_WHITE = BLOCKS.register("sauvignon_blanc_dry_white", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());
    RegistryObject<Block> VINEGAR = BLOCKS.register("vinegar", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    RegistryObject<Block> WATERMELON_JUICE = BLOCKS.register("watermelon_juice", DrinkBlock.create().maxCount(4).shapes(
            Block.box(6, 0, 6, 10, 16, 10),
            Block.box(2, 0, 6, 14, 16, 10),
            Shapes.or(
                    Block.box(2, 0, 10, 14, 16, 14),
                    Block.box(6, 0, 2, 10, 16, 14)
            ),
            Block.box(2, 0, 2, 14, 16, 14)
    ).build());

    // BlockEntity
    RegistryObject<BlockEntityType<ChalkboardBlockEntity>> CHALKBOARD_BE = BLOCK_ENTITIES.register(
            "chalkboard", () -> BlockEntityType.Builder
                    .of(ChalkboardBlockEntity::new, CHALKBOARD.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<BarStoolBlockEntity>> BAR_STOOL_BE = BLOCK_ENTITIES.register(
            "bar_stool", () -> BlockEntityType.Builder.of(BarStoolBlockEntity::new,
                    BLUE_BAR_STOOL.get(),
                    GREEN_BAR_STOOL.get(),
                    ORANGE_BAR_STOOL.get(),
                    PURPLE_BAR_STOOL.get(),
                    YELLOW_BAR_STOOL.get(),
                    BLACK_BAR_STOOL.get(),
                    WHITE_BAR_STOOL.get(),
                    GRAY_BAR_STOOL.get(),
                    BROWN_BAR_STOOL.get(),
                    LIME_BAR_STOOL.get(),
                    MAGENTA_BAR_STOOL.get(),
                    CYAN_BAR_STOOL.get(),
                    LIGHT_BLUE_BAR_STOOL.get(),
                    PINK_BAR_STOOL.get(),
                    LIGHT_GRAY_BAR_STOOL.get(),
                    RED_BAR_STOOL.get()).build(null)
    );

    RegistryObject<BlockEntityType<SandwichBlockEntity>> SANDWICH_BOARD_BE = BLOCK_ENTITIES.register(
            "sandwich_board", () -> BlockEntityType.Builder.of(SandwichBlockEntity::new,
                    BASE_SANDWICH_BOARD.get(),
                    GRASS_SANDWICH_BOARD.get(),
                    ALLIUM_SANDWICH_BOARD.get(),
                    AZURE_BLUET_SANDWICH_BOARD.get(),
                    CORNFLOWER_SANDWICH_BOARD.get(),
                    ORCHID_SANDWICH_BOARD.get(),
                    PEONY_SANDWICH_BOARD.get(),
                    PINK_PETALS_SANDWICH_BOARD.get(),
                    PITCHER_PLANT_SANDWICH_BOARD.get(),
                    POPPY_SANDWICH_BOARD.get(),
                    SUNFLOWER_SANDWICH_BOARD.get(),
                    TORCHFLOWER_SANDWICH_BOARD.get(),
                    TULIP_SANDWICH_BOARD.get(),
                    WITHER_ROSE_SANDWICH_BOARD.get()
            ).build(null)
    );

    RegistryObject<BlockEntityType<PressingTubBlockEntity>> PRESSING_TUB_BE = BLOCK_ENTITIES.register(
            "pressing_tub", () -> BlockEntityType.Builder
                    .of(PressingTubBlockEntity::new, PRESSING_TUB.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<DrinkBlockEntity>> DRINK_BE = BLOCK_ENTITIES.register(
            "drink", () -> BlockEntityType.Builder
                    .of(DrinkBlockEntity::new,
                            WINE.get(), CHAMPAGNE.get(), VODKA.get(), BRANDY.get(), CARIGNAN.get(),
                            SAKURA_WINE.get(), PLUM_WINE.get(), WHISKEY.get(), ICE_WINE.get(),
                            POLARIS_SWEET_WHITE.get(), HONEY_WINE.get(), RED_QUEEN.get(), MINERS_STAR.get(),
                            RUM.get(), RIESLING_DRY_WHITE.get(), SUNSET_GLOW.get(), MADAME_SHEXIANG.get(),
                            SWEET_BERRY_WINE.get(), SHERRY.get(), MOTHER_SNOW.get(), LUMINOUS_BRIDE.get(),
                            GLOWFLOWER_BREW.get(), SAUVIGNON_BLANC_DRY_WHITE.get(), VINEGAR.get(),
                            WATERMELON_JUICE.get()
                    ).build(null)
    );

    RegistryObject<BlockEntityType<BarrelBlockEntity>> BARREL_BE = BLOCK_ENTITIES.register(
            "barrel", () -> BlockEntityType.Builder
                    .of(BarrelBlockEntity::new, BARREL.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<TapBlockEntity>> TAP_BE = BLOCK_ENTITIES.register(
            "tap", () -> BlockEntityType.Builder
                    .of(TapBlockEntity::new, TAP.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<BarCabinetBlockEntity>> BAR_CABINET_BE = BLOCK_ENTITIES.register(
            "bar_cabinet", () -> BlockEntityType.Builder
                    .of(BarCabinetBlockEntity::new, BAR_CABINET.get(), GLASS_BAR_CABINET.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<CellarCabinetBlockEntity>> CELLAR_CABINET_BE = BLOCK_ENTITIES.register(
            "cellar_cabinet", () -> BlockEntityType.Builder
                    .of(CellarCabinetBlockEntity::new, CELLAR_CABINET.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<TiltedRackBlockEntity>> TILTED_RACK_BE = BLOCK_ENTITIES.register(
            "tilted_rack", () -> BlockEntityType.Builder
                    .of(TiltedRackBlockEntity::new, TILTED_RACK.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<CircularRackBlockEntity>> CIRCULAR_RACK_BE = BLOCK_ENTITIES.register(
            "circular_rack", () -> BlockEntityType.Builder
                    .of(CircularRackBlockEntity::new, CIRCULAR_RACK.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<HolderBlockEntity>> HOLDER_BE = BLOCK_ENTITIES.register(
            "holder", () -> BlockEntityType.Builder
                    .of(HolderBlockEntity::new, HOLDER.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<ShakerBlockEntity>> SHAKER_BE = BLOCK_ENTITIES.register(
            "shaker", () -> BlockEntityType.Builder
                    .of(ShakerBlockEntity::new, SHAKER.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<SignatureCocktailBlockEntity>> SIGNATURE_COCKTAIL_BE = BLOCK_ENTITIES.register(
            "signature_cocktail", () -> BlockEntityType.Builder
                    .of(SignatureCocktailBlockEntity::new, SIGNATURE_COCKTAIL.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<IncenseBlockEntity>> INCENSE_BE = BLOCK_ENTITIES.register(
            "incense", () -> BlockEntityType.Builder
                    .of(IncenseBlockEntity::new,
                            SAKURA_INCENSE.get(), PINE_INCENSE.get(), GINKGO_INCENSE.get(), SPORE_INCENSE.get(),
                            CATNIP_INCENSE.get(), SNOW_INCENSE.get(), BUTTERFLY_INCENSE.get(), FIREFLY_INCENSE.get()
                    ).build(null)
    );

    RegistryObject<BlockEntityType<GlasswareHolderBlockEntity>> GLASSWARE_HOLDER_BE = BLOCK_ENTITIES.register(
            "glassware_holder", () -> BlockEntityType.Builder
                    .of(GlasswareHolderBlockEntity::new, GLASSWARE_HOLDER.get())
                    .build(null)
    );

    RegistryObject<BlockEntityType<PotionBottleBlockEntity>> POTION_BOTTLE_BE = BLOCK_ENTITIES.register(
            "potion_bottle", () -> BlockEntityType.Builder
                    .of(PotionBottleBlockEntity::new, POTION_BOTTLE.get())
                    .build(null)
    );
}
