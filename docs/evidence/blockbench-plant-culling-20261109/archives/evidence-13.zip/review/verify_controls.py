"""Independent structural diff, resolved-face checks, and negative controls.

Only reads audit/scenes and pinned Git inputs; no runtime or scene mutation.
"""
from pathlib import Path
import base64, copy, hashlib, json, subprocess
H=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_bytes())

def diff(a,b,path=()):
    if type(a)!=type(b):return [(path,a,b)]
    if isinstance(a,dict):
        if a.keys()!=b.keys():return [(path,a,b)]
        return [d for k in a for d in diff(a[k],b[k],path+(k,))]
    if isinstance(a,list):
        if len(a)!=len(b):return [(path,a,b)]
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in diff(x,y,path+(i,))]
    return [] if a==b else [(path,a,b)]

def validate_pair(original,front,double,rec):
    allowed={('textures',i,'render_sides') for i in rec['changed_texture_indices']}
    delta=diff(front,double)
    assert {p for p,a,b in delta}==allowed
    assert all(a=='front' and b=='double' for p,a,b in delta)
    assert all(original[k]==front[k] for k in original if k not in ('elements','textures'))
    assert len(original['elements'])==len(front['elements'])
    listed={tuple(r['path']):(r['before'],r['after']) for r in rec['binding_changes']}
    actual={('elements',)+p:(a,b) for p,a,b in diff(original['elements'],front['elements'])}
    assert actual==listed
    assert front['textures'][:len(original['textures'])]==original['textures']
    assert len(front['textures'])==len(original['textures'])+len(rec['texture_isolations'])
    for isolation in rec['texture_isolations']:
        a=original['textures'][isolation['old_index']];b=front['textures'][isolation['new_index']]
        assert {p for p,x,y in diff(a,b)}=={('id',),('uuid',)}
        assert sha(base64.b64decode(b['source'].split(',',1)[1]))==isolation['embedded_png_sha256']
    for oe,fe,de in zip(original['elements'],front['elements'],double['elements'],strict=True):
        assert oe['uuid']==fe['uuid']==de['uuid']
        for side,of in oe['faces'].items():
            ti=of['texture']
            if ti is None:continue
            ft=front['textures'][fe['faces'][side]['texture']]
            dt=double['textures'][de['faces'][side]['texture']]
            ot=original['textures'][ti]
            assert ft['source']==dt['source']==ot['source']
            assert all(ft.get(k)==ot.get(k) for k in ('width','height','uv_width','uv_height','render_mode','render_sides'))
            expected='double' if oe['uuid'] in rec['changed_native_element_uuids'] else 'front'
            assert dt['render_sides']==expected, (oe['name'],expected)
    return len(delta)

control=read(H/'control-manifest.json');rows=[];negative=0
for rec in control['scenes']:
    original_raw=(H/rec['original_front']).read_bytes()
    assert sha(original_raw)==rec['original_sha256']
    assert original_raw==Path(rec['original_input']).read_bytes()
    if rec['role']!='candidate':continue
    front=read(H/rec['policy_front']);double=read(H/rec['old_policy_double']);original=json.loads(original_raw)
    count=validate_pair(original,front,double,rec)
    rows.append({'scene':rec['scene'],'material_field_differences':count,'isolation_face_bindings':len(rec['binding_changes']),
                 'all_original_uuid_geometry_uv_png_hierarchy_preserved':True,'resolved_front_faces_equal_original':True})
    mutants=[]
    x=copy.deepcopy(double);x['elements'][0]['from'][0]+=.01;mutants.append(x)
    x=copy.deepcopy(double);x['textures'][rec['source_texture_indices'][0]]['render_sides']='double';mutants.append(x)
    x=copy.deepcopy(double);x['textures'][rec['changed_texture_indices'][0]]['source']+='bad';mutants.append(x)
    for x in mutants:
        try:validate_pair(original,front,x,rec)
        except AssertionError:negative+=1
        else:raise AssertionError('Invalid material control accepted')

proposal=read(H/'proposal.json');repo=H.parent/'tavern-decor-publication-20261109';pr=[]
for rec in proposal['files']:
    raw=subprocess.check_output(['git','-C',str(repo),'show',proposal['pin']+':'+rec['path']])
    assert sha(raw)==rec['before_sha256']
    before=json.loads(raw);after=copy.deepcopy(before)
    for op in rec['operations']:
        assert op['op']=='replace' and op['before']=='alpha_test' and op['value']=='alpha_test_single_sided'
        parts=op['path'].strip('/').split('/');obj=after
        for k in parts[:-1]:obj=obj[int(k)] if isinstance(obj,list) else obj[k]
        assert parts[-1]=='render_method' and obj[parts[-1]]==op['before']
        obj[parts[-1]]=op['value']
    delta=diff(before,after)
    assert len(delta)==len(rec['operations']) and all(p[-1]=='render_method' for p,a,b in delta)
    encoded=(json.dumps(after,indent=2,ensure_ascii=False)+'\n').encode()
    assert sha(encoded)==rec['after_sha256']
    pr.append({'path':rec['path'],'fields':len(delta),'after_sha256':sha(encoded),'all_other_fields_equal':True})
assert sum(r['fields'] for r in pr)==36
result={'status':'passed','scene_checks':rows,'proposal_checks':pr,'negative_controls_rejected':negative,
        'independent_of_preparation_functions':True,'gui_execution':False,'runtime_files_written':False}
(H/'independent-diff.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','material_control_scenes':len(rows),'negative_controls_rejected':negative,'proposal_fields':36}))
