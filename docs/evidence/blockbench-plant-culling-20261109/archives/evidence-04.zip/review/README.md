# Plant culling-policy review, 2026-11-09

**Review-only proposal: 36 `render_method` fields in four BP owners. Not applied.**

Pin: canonical `origin/main` **cb2b37dfa2181ee042a090d8dbd434758a762afb**, runtime tree **38c5977dd6bfe14b1824734612e3c601e1e41028**, version **0.6.213**. The publication checkout's working HEAD is older, so this audit reads the pinned Git objects, not its runtime worktree. It does not touch the concurrent wild-vine 0.6.214 worktree, wild-vine files, runtime, version files, releases or remote Git.

## Finding and exact scope

The complete effective-route traversal corrects an initial base-only impression: ordinary grapevine's connected shapes are already single-sided and must not be changed.

| Owner | Current fields | Proposed changes |
| --- | --- | --- |
| `grape_crop` | 8 alpha_test | Base world wildcard, base item wildcard, and 6 age-permutation world wildcards: 8 |
| `gold_grape_crop` | 8 alpha_test | Same 8 routes |
| `ice_grape_crop` | 8 alpha_test | Same 8 routes |
| `grapevine_trellis` | 12 alpha_test, 48 already single-sided | Base world/item wildcard and unshaded; single-shape age 0–3 world wildcard and unshaded: 12 |
| `gold_grapevine_trellis` | 60 already single-sided | 0, A3 control only |
| `ice_grapevine_trellis` | 60 already single-sided | 0, A3 control only |

All changes are `alpha_test` → `alpha_test_single_sided`. The ordinary vine's **24 connected-shape permutations / 48 material fields remain byte-equivalent**. No blanket changes to other alpha materials or entities are proposed. `proposal.json` gives exact JSON paths, before/after file hashes and an in-memory, independently verified field delta. It does not contain replacement runtime files.

`route-audit.json` covers base declarations, every permutation, item inheritance, and every declared state combination including the six `minecraft:block_face` trait values. Each effective route names the winning component location, not just the base. There are **354 candidate state combinations** and **672 A3-control combinations**. Of the candidate world combinations, only 66 currently select double-sided alpha_test: 18 crop ages and 48 single-vine age/waterlogged/block-face combinations. The remaining 288 ordinary-vine combinations already select single-sided connected shapes. Native item_visual always inherits its base stage-zero binding; no permutation overrides it.

## Independent source and face checks

Both author branches were independently read from their exact Git objects:

- Forge: `c4ec1880bd44cf3139d3ba744ab30bb379cf1416`
- NeoForge: `a1afba34981a00e89d57130d3dc8f1e64f1820a2`

Every effective source blockstate points to one of the **48 audited models**: 18 crop stages and 30 vine forms, including controls. Every resolved model uses `cutout`. Both branch face records, UVs, shade and decoded PNG pixels agree. Some PNG file bytes differ between branches; this is explicitly recorded rather than misreported as byte equality.

`face-ownership.json` records every source directed face and every exact active runtime cube face/material tag, plus the previous ordered correspondence. All 417 original saved input hashes were rechecked, and each affected current BP, geometry and texture hash matches the original review input. Source model JSON was also checked directly against pinned Forge data. No original scenes were rebuilt.

- Each crop has 24 faces across six models: 12 east and 12 west, preserving both directed faces of each crossed sheet.
- Each vine kind has 196 faces across ten models, including explicit opposite north/south and up/down leaf faces and the solid wood faces. Ordinary-vine single stages retain both leaf directions.
- Across these 48 models, all 660 source/native directed faces have the existing ordered correspondence. **336 retain the reviewed ±0.08 displacement / 0.16 native thickness adaptation**. That adaptation is preserved, not normalized away or called exact geometry.
- No face absence justifies making an authored quad double-sided. Absence of Java `cullface` concerns neighbor occlusion; it is not a request to disable GPU backface culling.

## Why single-sided is the source policy

[Microsoft's material contract](https://learn.microsoft.com/en-us/minecraft/creator/reference/content/blockreference/examples/blockcomponents/minecraftblock_material_instances?view=minecraft-bedrock-stable) says alpha_test disables backface culling and alpha_test_single_sided enables it. All six atlas images contain transparent and opaque texels; their exact alpha histograms and RGBA hashes are in the route audit. Opposite explicit faces plus a double-sided material can add the farther face's mirrored texel through a transparent near-face texel. It is the same material-policy question as the wild-vine controls, not a reason to remove the opposite face or alter UVs/thickness.

The reused semantic receipts under `semantic-evidence/` establish default CULL in official Java **1.20.1 and 1.21.1** class bytes, parsed as data without execution. Pinned maintained Forge `8bdaec882b9bfd76e9dfdf67a22a924f677b1062` and NeoForge `624c929f49920c250166e2a8df7af87f16d220ef` map named cutout world rendering to vanilla cutout and item rendering to ITEM_LAYERED_CUTOUT without a cull override. All four local loader-source hashes were rechecked. This work reuses that proof; it does not claim to have repeated a class analysis or engine test. The exact Forge 47.3.0 archive returned 403 in the prior investigation and remains unverified; it was not retried. Exact loader-release archives and 26.1.2 renderer behavior remain outside the claim.

**Item caveat:** the six crop/filled-vine block names have no same-name Java item model on either pinned author branch. The source registry uses separate fruit, grapevine and bare-trellis items. The proposed native `minecraft:item_visual` change keeps the existing stage-zero block fallback consistent with its source-backed geometry policy; it does not certify ordinary fruit/trellis inventory icons, held poses, acquisition or every Java item context. Existing transforms remain unchanged.

## Minimal functional owner for a later repair

Extend the current shared **cultivation resource contract**, `tools/cultivation_source_contract.py`, with source-backed cutout checks for the four affected block resources, using its existing negative-control suite. Do not add an A2-specific/version-specific generator or another postimage ledger. Its gameplay owners remain `runtime/BP/scripts/core/cultivation.js` and `bedrock/cultivation.js`, with the actual board/farm interaction suite; none needs a behavior change for this material proposal.

The four affected BP paths still occur in `data/baseline-reconciliation.json` → `files` and `data/launch-repair-reference.json` → `reviewedChanges`. A future integrated repair should retire those eight historical entries as those paths enter the current owner, matching AGENTS and current cultivation boundaries. `proposal.json` lists them, but no ledger/contract edit is made here. Rebase that work on the accepted wild-vine owner work rather than overwriting the concurrent branch. Keep release identity/history separate and run the current required aggregate checks if runtime is eventually changed.

Preserve geometry, all explicit face ownership, PNGs, UVs, AO, `face_dimming`/shade, held transforms, collision/selection, ticks, growth, waterlogging, block-face and connection states, loot and old accepted behavior. This review does not run the release gate or gameplay suite because no runtime candidate exists.

## Small GUI queue: 18 new raw captures, not 84 again

`capture-queue.json` has **9 paired views / 18 pending raw screenshots**:

1. Ordinary, gold and ice crop stages 4–5, using each exact `*-crop-stages-2` original scene: oblique orthographic and the reverse oblique, Front then native-Double at the same actual camera.
2. Ordinary `grapevine-shapes-stages-2`: oblique orthographic, reverse oblique and reverse-low oblique, each Front then native-Double. This covers single stages 0–2 and retains already-correct north_south as an in-scene invariant.
3. Gold/ice `grapevine-shapes-stages-2` remain already-single-sided A3 controls. Their unchanged original Front scenes and exact previous capture hashes are included for reference; **no additional captures are required** absent a new discrepancy.

The existing Front captures are real original Blockbench JPEGs listed with exact paths/hashes in `control-manifest.json`. They are reused evidence, not new screenshots or native-engine acceptance. This audit visually re-opened only the saved ordinary crop oblique and ordinary vine reverse-low JPEGs to check the chosen queue; it did not operate Blockbench.

### Texture isolation is explicit

Every original scene already separates source and native texture entries (source index 0, native index 1) even when PNG bytes match. Crop controls need only one changed field: native texture 1 `render_sides` front → double.

The ordinary vine scene shares native texture 1 between single stages and the north_south connected form. It would be wrong to double-side that whole entry and claim it reproduces the current runtime. Both compared variants therefore add one identical Front texture entry (index 2, deterministic new texture UUID) and rebind **18 north_south native face texture indices** to it. All original element/group/texture UUIDs, geometry, UV coordinates, PNG bytes, hierarchy and source bindings remain unchanged. This setup isolates the already-correct connected form. Between `--policy-front` and `--old-policy-double`, **only texture 1 `render_sides` changes**. Original `--original-front` bytes are retained separately, and independently resolved Front faces equal the originals.

`independent-diff.json` verifies these conditions without importing preparation functions. It checks every element/face's resolved PNG and sidedness, exact allowed isolation changes, 36 proposal fields, and rejection of **12 negative controls** (coordinate, source-sidedness and PNG mutation).

### Camera and acceptance limits

Source is lower world X and native higher world X within every pair; exact offsets and group/element UUIDs are in the manifest. The negative-X/negative-Z oblique camera projects native screen-left/source screen-right. Reverse positive-X/positive-Z oblique views project source screen-left/native screen-right. Consult each prior image record, not a universal screen-side assumption.

The old captures record view/projection/direction, **not numeric camera matrices**. Use them to recover orientation, then record the actual camera and keep it identical within each new Front/Double pair. Do not claim pixel-aligned reproduction of historical cameras without additional evidence. Do not move geometry to fit the view. The queue deliberately does not require reconstructing old scenes.

Front/Double controls test editor texture sidedness only. The Free-format texture hint is not execution of BP material_instances. Bare `.geo.json` imports defaulting to Auto/DoubleSide are not native BP execution. Alpha cutoff, depth/lighting, water, AO and shader behavior can differ. Numerical/semantic proofs and old Front acceptance do not certify a Bedrock client, BDS, saved world, LIVE deployment, native item appearance or every unpictured growth stage under the new policy. New GUI acceptance remains pending with the parent.

## Reproduce locally

Run these bounded, single-process commands from this folder:

```
python audit_routes.py
python collect_semantics.py
python prepare_controls.py
python verify_controls.py
```

The route script requires the pinned existing checkouts, verifies current origin/main still equals the recorded pin, and reads Git objects. If main advances, explicitly re-audit the new pin; do not silently reuse a stale proposal. The scripts write review artifacts here only. No GUI, remote fetch/push, download, runtime write or release action is performed.
