"""Read-only Tavern review scenes. Does not edit the source checkout or run a game."""
from pathlib import Path
import base64, copy, hashlib, io, json, math, re, subprocess, tarfile
from collections import Counter
from PIL import Image
import review_codec as C
from concurrent.futures import ThreadPoolExecutor

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'tavern-visual-review-20261108/source'
JAVA = HERE.parent / 'tavern-visual-review-20261108/java-reference'
ASSETS = JAVA / 'src/main/resources/assets/kaleidoscope_tavern'
OUT = HERE / 'scenes'
OUT.mkdir(exist_ok=True)
C.OUT = OUT
read = C.read
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pins = {'Forge': 'c4ec1880bd44cf3139d3ba744ab30bb379cf1416',
        'NeoForge': 'a1afba34981a00e89d57130d3dc8f1e64f1820a2',
        'unpublished_26_1_2': '9b8f165a'}
manifest = {'schema': 1, 'runtime_version': '0.6.212', 'runtime_pin': '4700ede2',
            'source_pins': pins, 'gui_reviewed': False, 'inputs': {},
            'source_verification': {}, 'scenes': [], 'cases': [],
            'layout': 'Source at world -X, native at world +X within each pair. Default BB 5.2.2 perspective projects native screen-left and source screen-right. Camera-dependent; no fixed screen-side claim.'}

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

assert git(JAVA, 'rev-parse', 'HEAD').decode().strip() == pins['Forge']
assert not git(ROOT, 'diff', '4700ede2', 'HEAD', '--', 'runtime')
manifest['source_checkout_head_at_build'] = git(ROOT, 'rev-parse', 'HEAD').decode().strip()
manifest['runtime_tree'] = git(ROOT, 'rev-parse', '4700ede2:runtime').decode().strip()

def track(p):
    p = Path(p)
    manifest['inputs'][str(p)] = {'sha256': sha(p), 'bytes': p.stat().st_size}
    return p

lock = read(track(ROOT / 'art/source-jar.lock.json'))
manifest['author_archive'] = lock['input']
jar_assets = {r['path']: r for r in lock['asset_files']}
# Read-only Git object lookups use bounded single-object commands.


def source(p):
    """Preserve author source, and independently verify actual locked archive bytes."""
    p = track(p)
    if str(p) in manifest['source_verification']:
        return p
    rel = str(p.relative_to(JAVA))
    cache = HERE / 'source-receipts' / (hashlib.sha256(rel.encode()).hexdigest() + '.json')
    if cache.exists():
        cached = read(cache)
        if cached['worktree_sha256'] == sha(p):
            manifest['source_verification'][str(p)] = cached['verification']
            jar = cached['verification'].get('jar', {})
            if 'path' in jar: track(Path(jar['path']))
            return p
    rec = {}
    current = p.read_bytes()
    forge = git(JAVA, 'show', pins['Forge'] + ':' + rel)
    assert (json.loads(forge) == json.loads(current)) if p.suffix == '.json' else (forge == current)
    rec['Forge'] = {'git_bytes_sha256': hashlib.sha256(forge).hexdigest(), 'worktree_bytes_equal': forge == current, 'json_equal': json.loads(forge) == json.loads(current) if p.suffix == '.json' else None}
    for branch in ('NeoForge', 'unpublished_26_1_2'):
        proc = subprocess.run(['git', '-C', str(JAVA), 'show', pins[branch] + ':' + rel], capture_output=True, timeout=60)
        b = proc.stdout
        if proc.returncode:
            rec[branch] = {'path_present': False}
        else:
            rec[branch] = {'path_present': True, 'sha256': hashlib.sha256(b).hexdigest(), 'bytes_equal': b == current}
            if p.suffix == '.json':
                rec[branch]['json_equal'] = json.loads(b) == json.loads(current)
            if p.suffix == '.png':
                im, other = Image.open(io.BytesIO(b)).convert('RGBA'), Image.open(p).convert('RGBA')
                rec[branch]['pixels_equal'] = im.size == other.size and im.tobytes() == other.tobytes()
    jar_rel = 'assets/kaleidoscope_tavern/' + str(p.relative_to(ASSETS))
    a = jar_assets.get(jar_rel)
    if a:
        existing = HERE / 'verified-jar-assets' / jar_rel
        b = existing.read_bytes() if existing.exists() else git(ROOT, 'cat-file', 'blob', a['git_blob_sha1'])
        assert len(b) == a['bytes'] and hashlib.sha256(b).hexdigest() == a['sha256']
        dst = HERE / 'verified-jar-assets' / jar_rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(b)
        track(dst)
        rec['jar'] = {'path': str(dst), 'git_blob_sha1': a['git_blob_sha1'], 'sha256': a['sha256'], 'bytes_equal': b == current}
        if p.suffix == '.json':
            rec['jar']['json_equal'] = json.loads(b) == json.loads(current)
        elif p.suffix == '.png':
            im, other = Image.open(io.BytesIO(b)).convert('RGBA'), Image.open(p).convert('RGBA')
            rec['jar']['pixels_equal'] = im.size == other.size and im.tobytes() == other.tobytes()
    else:
        rec['jar'] = {'asset_not_in_lock': jar_rel}
    manifest['source_verification'][str(p)] = rec
    cache.parent.mkdir(exist_ok=True)
    cache.write_text(json.dumps({'worktree_sha256': sha(p), 'verification': rec}, indent=2))
    return p

terrain = read(track(ROOT / 'runtime/RP/textures/terrain_texture.json'))['texture_data']
geometry = {}
for p in (ROOT / 'runtime/RP/models').rglob('*.json'):
    for g in read(p).get('minecraft:geometry', []):
        key = g['description']['identifier']
        assert key not in geometry
        geometry[key] = (p, g)

def resolve_model(path, seen=()):
    assert path not in seen, 'Cyclic Java model parent'
    child = read(source(path))
    if child.get('parent'):
        ns, rel = child['parent'].split(':')
        assert ns == 'kaleidoscope_tavern', 'External Java parents need separate review'
        parent = resolve_model(ASSETS / 'models' / (rel + '.json'), (*seen, path))
        model = {**parent, **child, 'textures': {**parent.get('textures', {}), **child.get('textures', {})}}
    else:
        model = child
    assert isinstance(model.get('elements'), list)
    return model

def texture_ref(model, ref):
    seen = set()
    while ref.startswith('#'):
        assert ref not in seen, 'Cyclic Java texture alias'
        seen.add(ref)
        ref = model['textures'][ref[1:]]
    ns, name = ref.split(':')
    assert ns == 'kaleidoscope_tavern'
    return source(ASSETS / 'textures' / (name + '.png'))

def condition(text, states):
    def replace(m):
        key = m[1]
        assert key in states, ('Missing explicit state', key, text)
        return repr(states[key])
    expr = re.sub(r"q\.block_state\('([^']+)'\)", replace, text)
    expr = expr.replace('&&', ' and ').replace('||', ' or ')
    assert not re.search(r'[^A-Za-z0-9_\s\'"=<>!().-]', expr), expr
    return eval(expr, {'__builtins__': {}}, {})

def native_binding(block, short_states):
    path = track(ROOT / 'runtime/BP/blocks' / (block + '.json'))
    b = read(path)['minecraft:block']
    states = {('minecraft:' if k == 'cardinal_direction' else 'kaleidoscope_tavern:') + k: v for k, v in short_states.items()}
    for k, vals in b['description'].get('states', {}).items():
        assert k in states and states[k] in vals
    c = copy.deepcopy(b['components'])
    matched = []
    for p in b.get('permutations', []):
        if condition(p['condition'], states):
            c.update(copy.deepcopy(p['components']))
            matched.append(p['condition'])
    gp, g = geometry[c['minecraft:geometry']['identifier']]
    track(gp)
    assert c.get('minecraft:transformation', {}).get('rotation', [0, 0, 0]) == [0, 0, 0], 'Only untransformed baseline pose in this batch'
    assert 'bone_visibility' not in c['minecraft:geometry']
    assert c.get('minecraft:transformation', {}).get('scale', [1,1,1]) == [1,1,1]
    assert c.get('minecraft:transformation', {}).get('translation', [0,0,0]) == [0,0,0]
    materials = c['minecraft:material_instances']
    for m in materials.values():
        tp = terrain[m['texture']]['textures']
        assert isinstance(tp, str)
        m['_path'] = str(track(ROOT / 'runtime/RP' / (tp + '.png')))
    return gp, g, materials, {'block': str(path), 'identifier': b['description']['identifier'], 'states': states,
                              'matched_conditions': matched, 'geometry': str(gp), 'geometry_id': g['description']['identifier'],
                              'materials': materials}

def add_java(scene, path, offset):
    model = resolve_model(path)
    node = scene.group('Source world -X | ' + str(path.relative_to(ASSETS / 'models')), offset)
    add = lambda a: [a[k] + offset[k] + (-8 if k != 1 else 0) for k in range(3)]
    before = len(scene.j['elements'])
    for i, e in enumerate(model['elements']):
        fr, to = e['from'][:], e['to'][:]
        assert all(math.isfinite(v) for v in fr + to)  # Authored reversed endpoints remain literal, never silently sorted.
        r = e.get('rotation', {})
        axis = 'xyz'.index(r.get('axis', 'y'))
        rot = [0, 0, 0]
        rot[axis] = r.get('angle', 0)
        pivot = r.get('origin', [8, 0, 8])
        if r.get('rescale'):
            assert abs(rot[axis]) in (0, 22.5, 45)
            factor = 1 / math.cos(math.radians(rot[axis]))
            for k in range(3):
                if k != axis:
                    fr[k] = pivot[k] + (fr[k] - pivot[k]) * factor
                    to[k] = pivot[k] + (to[k] - pivot[k]) * factor
        faces = {}
        for side, f in e['faces'].items():
            assert f.get('tintindex', -1) == -1, 'Tint requires a separate colour review'
            tp = texture_ref(model, f['texture'])
            wh = Image.open(tp).size
            tex = scene.texture(tp)
            assert 'uv' in f, 'Implicit Java UV not supported by this review converter'
            faces[side] = {'uv': [v * wh[k % 2] / 16 for k, v in enumerate(f['uv'])], 'texture': tex, 'rotation': f.get('rotation', 0)}
        scene.cube('Source element ' + str(i), add(fr), add(to), faces, add(pivot), rot, node)
        scene.j['elements'][-1]['shade'] = e.get('shade', True)
    return model, copy.deepcopy(scene.j['elements'][before:])

def add_native(scene, gp, g, materials, offset, label):
    root = scene.group('Native world +X | ' + label, offset)
    nodes = {}
    add = lambda a: [a[k] + offset[k] for k in range(3)]
    before = len(scene.j['elements'])
    for bone in g['bones']:
        assert not bone.get('mirror') and not bone.get('inflate') and not bone.get('reset')
        assert not bone.get('parent') or bone['parent'] in nodes, 'Parent must precede child'
        p, r = bone.get('pivot', [0, 0, 0]), bone.get('rotation', [0, 0, 0])
        node = scene.group(bone['name'], add([-p[0], p[1], p[2]]), [-r[0], -r[1], r[2]], nodes.get(bone.get('parent'), root))
        nodes[bone['name']] = node
        assert r == [0, 0, 0], 'Nonzero native bone transforms need world-space audit extension'
        for n, cube in enumerate(bone.get('cubes', [])):
            assert not cube.get('inflate') and not cube.get('mirror')
            assert isinstance(cube['uv'], dict), 'Box UV intentionally rejected by this bounded batch'
            o, z = cube['origin'], cube['size']
            assert all(math.isfinite(v) for v in o + z) and all(v >= 0 for v in z)
            fr = [-o[0] - z[0], o[1], o[2]]
            to = [fr[k] + z[k] for k in range(3)]
            p, r = cube.get('pivot', [0, 0, 0]), cube.get('rotation', [0, 0, 0])
            faces, shades = {}, set()
            for side, f in cube['uv'].items():
                material = materials.get(f.get('material_instance', '*'), materials['*'])
                tp = Path(material['_path'])
                wh = Image.open(tp).size
                assert wh == (g['description']['texture_width'], g['description']['texture_height'])
                tex = scene.texture(tp)
                u, v = f['uv']; du, dv = f['uv_size']
                uv = [u, v, u + du, v + dv]
                if side in ('up', 'down'):
                    uv = uv[2:] + uv[:2]
                faces[side] = {'uv': uv, 'texture': tex, 'rotation': f.get('uv_rotation', 0)}
                shades.add(material.get('face_dimming', True))
            assert len(shades) == 1, 'Mixed shade faces require split preview cubes'
            scene.cube('Native ' + bone['name'] + ' ' + str(n), add(fr), add(to), faces,
                       add([-p[0], p[1], p[2]]), [-r[0], -r[1], r[2]], node)
            scene.j['elements'][-1]['shade'] = next(iter(shades))
    return copy.deepcopy(scene.j['elements'][before:])

def normalized(e, off):
    out = {'from': [round(e['from'][k] - off[k], 6) for k in range(3)],
           'to': [round(e['to'][k] - off[k], 6) for k in range(3)],
           'rotation': e['rotation'], 'shade': e['shade'],
           'faces': {s: {k: v for k, v in f.items() if k != 'texture'} for s, f in e['faces'].items() if f['texture'] is not None}}
    if any(e['rotation']):
        out['origin'] = [round(e['origin'][k] - off[k], 6) for k in range(3)]
    return out

def audit_pair(scene, java, native, jo, no):
    js, ns = [normalized(e, jo) for e in java], [normalized(e, no) for e in native]
    deltas = []
    if len(js) != len(ns):
        deltas.append({'element_count': [len(js), len(ns)]})
    images = {i: Image.open(io.BytesIO(base64.b64decode(t['source'].split(',', 1)[1]))).convert('RGBA') for i, t in enumerate(scene.j['textures'])}
    for i, (a, b) in enumerate(zip(js, ns)):
        d = {k: {'source': a.get(k), 'native': b.get(k)} for k in set(a) | set(b) if a.get(k) != b.get(k)}
        if d:
            deltas.append({'index': i, 'differences': d})
    texture_pairs = set()
    for a, b in zip(java, native):
        for side in C.SIDES:
            aa, bb = a['faces'][side]['texture'], b['faces'][side]['texture']
            if aa is not None and bb is not None:
                texture_pairs.add((aa, bb))
    textures = [{'source': scene.j['textures'][a]['name'], 'native': scene.j['textures'][b]['name'],
                 'source_size': images[a].size, 'native_size': images[b].size,
                 'pixels_equal': images[a].size == images[b].size and images[a].tobytes() == images[b].tobytes()} for a, b in sorted(texture_pairs)]
    return {'source_elements': len(js), 'native_cubes': len(ns), 'direct_normalized_equal': js == ns,
            'deltas': deltas, 'texture_pairs': textures}

def case(label, model, block, **states):
    return {'label': label, 'source_model': model, 'block': block, 'states': states}

table = [case('table ' + n, 'deco/table/' + n, 'table', position=pos, axis=0 if not n.endswith('_rot') else 1,
              cardinal_direction='east' if n.endswith('_rot') else 'north')
         for n, pos in [('single', 0), ('left', 3), ('middle', 2), ('right', 1), ('left_rot', 3), ('middle_rot', 2), ('right_rot', 1)]]
lights = [case('string lights ' + p.stem, 'deco/string_lights/' + p.stem, 'light_' + p.stem, facing=0)
          for p in sorted((ASSETS / 'models/block/deco/string_lights').glob('*.json'))]
incenses = [case(p.stem + ' ' + state, 'deco/' + folder + '/' + p.stem, p.stem, open=opened)
            for p in sorted((ASSETS / 'models/block/deco/incense').glob('*.json'))
            for state, folder, opened in [('closed', 'incense', 0), ('open', 'incense_open', 1)]]
trellises = [case('bare trellis ' + p.stem, 'plant/trellis/' + p.stem, 'trellis', shape=p.stem, waxed=False, waterlogged=False)
             for p in sorted((ASSETS / 'models/block/plant/trellis').glob('*.json'))]
batches = []
for prefix, cases, size in [('tables', table, 4), ('string-lights', lights, 4), ('incenses', incenses, 4), ('bare-trellises', trellises, 4)]:
    for i in range(0, len(cases), size):
        batches.append((prefix + '-' + str(i // size + 1), cases[i:i + size]))
for kind in ('grape', 'gold_grape', 'ice_grape'):
    crops = [case(kind + ' crop stage ' + str(age), 'plant/' + kind + '_crop/stage' + str(age), kind + '_crop', age=age) for age in range(6)]
    for i in range(0, len(crops), 4):
        batches.append((kind + '-crop-stages-' + str(i // 4 + 1), crops[i:i+4]))
    cases = []
    for p in sorted((ASSETS / ('models/block/plant/' + kind + 'vine_trellis')).glob('*.json')):
        shape, age = ('single', int(p.stem[-1])) if p.stem.startswith('single_stage') else (p.stem, 3)
        cases.append(case(kind + 'vine ' + p.stem, 'plant/' + kind + 'vine_trellis/' + p.stem, kind + 'vine_trellis', shape=shape, age=age, waterlogged=False))
    for i in range(0, len(cases), 4):
        batches.append((kind + 'vine-shapes-stages-' + str(i // 4 + 1), cases[i:i+4]))

preflight_sources = set()
for _, cases in batches:
    for c in cases:
        p = ASSETS / 'models/block' / (c['source_model'] + '.json')
        preflight_sources.add(p)
        for t in read(p).get('textures', {}).values():
            if not t.startswith('#') and t.startswith('kaleidoscope_tavern:'):
                preflight_sources.add(ASSETS / 'textures' / (t.split(':', 1)[1] + '.png'))
print('Preflight', len(preflight_sources), 'unique source assets', flush=True)
with ThreadPoolExecutor(max_workers=8) as pool:
    for n, _ in enumerate(pool.map(source, sorted(preflight_sources))):
        if n % 20 == 0: print('Source assets verified', n + 1, flush=True)

for name, cases in batches:
    scene = C.Scene('Tavern review | ' + name)
    rows = math.ceil(len(cases) / 2)
    records = []
    for i, c in enumerate(cases):
        x, z = (i % 2) * 76 - 54, (i // 2 - (rows - 1) / 2) * 40
        jo, no = [x, 0, z], [x + 28, 0, z]
        jp = ASSETS / 'models/block' / (c['source_model'] + '.json')
        model, je = add_java(scene, jp, jo)
        gp, g, materials, binding = native_binding(c['block'], c['states'])
        ne = add_native(scene, gp, g, materials, no, c['label'])
        rec = {**c, 'source_model': str(jp), 'scene': name + '.bbmodel', 'source_world_offset': jo, 'native_world_offset': no,
               'binding': binding, 'java_render_type': model.get('render_type'),
               'source_reversed_elements': [i for i, e in enumerate(model['elements']) if any(a > b for a, b in zip(e['from'], e['to']))],
               'source_rescale_elements': [i for i, e in enumerate(model['elements']) if e.get('rotation', {}).get('rescale')],
               'audit': audit_pair(scene, je, ne, jo, no)}
        manifest['cases'].append(rec)
        records.append(c['label'])
    scene.save(name + '.bbmodel')
    path = OUT / (name + '.bbmodel')
    manifest['scenes'].append({'file': str(path), 'sha256': sha(path), 'cases': records,
                               'elements': len(scene.j['elements']), 'textures': len(scene.j['textures']), 'gui_reviewed': False})
    print(name, len(cases), 'cases', len(scene.j['elements']), 'cubes', flush=True)

manifest['summary'] = {'scenes': len(manifest['scenes']), 'paired_cases': len(manifest['cases']),
                       'direct_normalized_equal_cases': sum(c['audit']['direct_normalized_equal'] for c in manifest['cases']),
                       'cases_with_recorded_deltas': sum(bool(c['audit']['deltas']) for c in manifest['cases']),
                       'family_counts': dict(Counter(c['block'] for c in manifest['cases']))}
manifest['limitations'] = [
    'Prepared scenes only; no Blockbench GUI acceptance, native Minecraft rendering, BDS, deployment, or user-computer access.',
    'Source Java UVs use actual referenced PNG width/height divided by 16, with parent/texture aliases resolved and rescale applied.',
    'Native geometry decoding reflects X and rotation signs per Blockbench 5.2.2; native BP material_instances resolve texture and face_dimming per face. No guess based only on a tag.',
    'A BB shade flag approximates face_dimming, not Minecraft ambient occlusion, emissivity, light emission, shader behavior, or tint. Preview textures use front faces; alpha_test double-sided differences remain engine-unmapped.',
    'Geometry and UV deltas are recorded rather than silently normalized away. Plant zero-thickness vs native 0.16 thickness and incense hidden-face removal need explicit interpretation.',
    'Source model state forms are compared at baseline native facing. Runtime connection updates, growth timing, particle effects, waterlogging, item display/held poses, and interaction behavior are not exercised.',
    'Vine scenes cover all 10 distinct model forms per crop, not every 28 shape-age routing combination; later audit expands routing without creating redundant scenes.',
    'Boards, device renderers, barrel assembly, text, and all remaining addon work stay unreviewed by this batch.',
    'Unpublished 26.1.2 comparison is per matching asset path only, not full branch parity. Archive lock is user-upload provenance, not publisher checksum verification.'
]
(HERE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['summary'], indent=2))
