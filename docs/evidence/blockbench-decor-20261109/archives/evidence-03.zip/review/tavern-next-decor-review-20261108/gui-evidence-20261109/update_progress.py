import json,hashlib,pathlib,datetime,collections
from PIL import Image
p=pathlib.Path(__file__).resolve().parent
root=p.parent
m=json.load(open(root/'manifest.json'))
d=json.load(open(root/'magenta-branch-difference.json'))
sha=lambda f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
scenes={pathlib.Path(s['file']).stem:s for s in m['scenes'] if 'incenses' not in s['file']}
scenes['magenta-three-way-branch-difference']={'file':d['scene'],'sha256':d['scene_sha256'],'cases':['Forge','native','NeoForge/JAR']}
notes=json.load(open(p/'observations.json'))
result={'schema':2,'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'application':'Official Blockbench 5.2.2','window_id':44040196,'bounds':[88,88,1188,848],'input_reuse_report':{'file':'../latest-input-reuse-20261109.json','sha256':sha(root/'latest-input-reuse-20261109.json')},'prepared_runtime_version':'0.6.212','reviewed_against_runtime_version':'0.6.213','latest_verified_main':'d42a39745f25082aa129f4d4bb823684e4174771','latest_verified_runtime_tree':'38c5977dd6bfe14b1824734612e3c601e1e41028','ordinary_pairs':sum(len(s['cases']) for s in scenes.values())-3,'target_scenes':len(scenes),'excluded':'All incenses scenes and catnip; separately completed and repaired.','limits':['Bounded editor preview only, not Bedrock shader, alpha culling, emissivity, gameplay, connection or growth mechanics.','336 plant faces retain known ±0.08 offsets / 0.16 native thickness, not exact geometry.','Magenta retains known Forge/native 47 versus NeoForge/JAR 35 face branch divergence.','Orthographic camera angles intentionally remain oblique to expose different Z rows without frontal overlap; both sides of leaf/light sheets are reviewed, with extra undersides for horizontal vine sheets.','This review does not reopen or supersede incense repair; does not include wild vines, boards, devices, particles, native gameplay or other unassigned families.'],'capture_method':'Every evidence image is the unmodified JPEG byte array returned by app.getScreenshot({emit:false}), emitted for actual visual inspection and written from the same local variable. No render, crop, stitch or reencode.','final_gui_state':'Own read-only scene tabs closed without saving; window 44040196 verified New Tab and no modal. GUI handed to OTC; other windows and terminals untouched.','runtime_changes':False,'publication':False,'images':[],'scenes':[]}
for name,s in scenes.items():
 imgs=[]
 for f in sorted(p.glob(name+'-*.jpg')):
  view=f.stem[len(name)+1:]
  if name=='magenta-three-way-branch-difference':
   if view=='perspective': direction='Default perspective: NeoForge/JAR screen-left, native center, Forge screen-right. World X: Forge -30, native 0, NeoForge/JAR +30.'
   else: direction='BOTTOM or underside perspective: Forge screen-left, native center, NeoForge/JAR screen-right. World +X projects right; Forge -30, native 0, NeoForge/JAR +30.'
  elif view=='perspective': direction='Default oblique from negative X and negative Z; native screen-left, source screen-right within each pair.'
  elif view in ['top','bottom']: direction='World +X to screen-right: source screen-left, native screen-right within each pair. Top/bottom row order reverses.'
  elif view=='oblique-orthographic': direction='Oblique orthographic from negative X and negative Z; native screen-left, source screen-right within each pair.'
  elif view=='reverse-orthographic': direction='Opposite oblique orthographic with positive X and positive Z toward viewer; source screen-left, native screen-right within each pair.'
  elif view=='reverse-low-orthographic': direction='Underside oblique orthographic from positive X, negative Y and positive Z; source screen-left, native screen-right within each pair. Exposes horizontal leaf-sheet undersides.'
  else: raise ValueError(view)
  with Image.open(f) as image:
   image.verify()
   fmt=image.format; size=list(image.size)
  assert fmt=='JPEG' and size==[1188,848]
  im={'file':f.name,'sha256':sha(f),'bytes':f.stat().st_size,'captured_utc':datetime.datetime.fromtimestamp(f.stat().st_mtime,datetime.timezone.utc).isoformat(),'format':fmt,'dimensions':size,'view':view,'direction':direction,'visually_reviewed':name in notes,'accepted_evidence':name in notes}
  imgs.append(im);result['images'].append(im)
 expected={'perspective','oblique-orthographic','reverse-orthographic'}
 if name.startswith(('tables-','bare-trellises-')):expected={'perspective','top','bottom'}
 if 'grapevine-' in name:expected.add('reverse-low-orthographic')
 if name=='magenta-three-way-branch-difference':expected={'perspective','bottom','low-underside-perspective'}
 actual={i['view'] for i in imgs}
 assert expected==actual,(name,expected,actual)
 cases=[{'label':c['label'],'source_world_offset':c['source_world_offset'],'native_world_offset':c['native_world_offset']} for c in m['cases'] if pathlib.Path(c['scene']).stem==name]
 result['scenes'].append({'scene':name,'scene_file':'../scenes/'+name+'.bbmodel','scene_sha256':sha(s['file']),'manifest_hash_matches':sha(s['file'])==s['sha256'],'cases':s['cases'],'case_offsets':cases,'status':'reviewed_bounded_editor' if name in notes else 'pending','observation':notes.get(name),'evidence':[i['file'] for i in imgs]})
result['reviewed_scenes']=sum(s['status']=='reviewed_bounded_editor' for s in result['scenes'])
result['image_count']=len(result['images'])
counts=collections.Counter(i['sha256'] for i in result['images'])
result['validation']={'all_scene_hashes_match':all(s['manifest_hash_matches'] for s in result['scenes']),'all_views_present':True,'all_images_valid_jpeg_1188x848':True,'unique_image_hashes':len(counts),'duplicate_image_hashes':[x for x,c in counts.items() if c>1],'white_or_failed_captures_included':False,'all_evidence_visually_inspected':all(i['visually_reviewed'] for i in result['images'])}
assert result['ordinary_pairs']==79 and result['reviewed_scenes']==25 and result['image_count']==84 and len(counts)==84
(p/'review.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'scenes':result['reviewed_scenes'],'pairs':result['ordinary_pairs'],'images':result['image_count'],'validation':result['validation']},indent=2))
