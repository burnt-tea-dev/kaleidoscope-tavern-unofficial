# Tavern decorative GUI review, 2026-11-09

**Completed bounded Blockbench editor review: 25 scenes, 79 ordinary source/native pairs, and one separate magenta three-way comparison.** The 84 evidence JPEGs are original 1188×848 Blockbench window captures, individually viewed before acceptance. They are not crops, reconstructions, renders or edited screenshots. All 84 image hashes are distinct and all 25 scene hashes still match their preparation records.

## Result

- **7 table forms:** perspective, TOP and BOTTOM. Top trim and marks, connected ends, supports and feet agree in the visible comparisons.
- **17 string-light colours/forms:** perspective and opposite oblique orthographic views expose both sides. Wire path, hanging forms and texture features agree in the Forge/native comparison.
- **7 bare trellis forms:** perspective, TOP and BOTTOM. Wood grain, straight/crossed members and exposed ends agree.
- **18 crop stages:** all six stages for ordinary, golden and ice grapes. Perspective and opposite oblique orthographic views expose both sides of crossed sheets.
- **30 vine forms:** ten forms per ordinary, golden and ice grapevine. Perspective, opposite oblique orthographic and underside oblique orthographic views cover vertical and horizontal leaf-sheet backs as well as wood members.
- **Magenta branch divergence is visible:** BOTTOM and underside perspective show Forge and native retaining magenta petal backs, whereas NeoForge/JAR lacks those backs. Existing static totals remain 47 Forge/native faces versus 35 NeoForge/JAR faces. No automatic rollback or runtime defect classification is made.

No additional unexplained source/native discrepancy was observed in the 79 ordinary comparisons. This is not a claim of pixel-identical rendering or exact plant geometry: the known 336 plant faces displaced by ±0.08, giving native thickness 0.16, remain an explicit adaptation.

## Provenance and evidence

`review.json` records each scene hash, case labels and world offsets, screenshot hash, capture time, view, source/native screen orientation, observation and review limits. `observations.json` holds the human visual observations. `update_progress.py` rebuilds the manifest and verifies image encoding/dimensions, required views, pair counts and hash uniqueness; it does not generate or alter screenshots.

The parent `latest-input-reuse-20261109.json` formally checks the prepared inputs against main `d42a39745f25082aa129f4d4bb823684e4174771` / runtime tree `38c5977dd6bfe14b1824734612e3c601e1e41028` / 0.6.213. All 417 saved input hashes match their preparation record. Of 149 canonical inputs checked against that main, only the two excluded incense geometries changed; the other 147 match exactly. The 25 reviewed scene files remain unchanged.

Ordinary scene layout is Java/source at the lower world X and native at the higher world X within each pair. The default negative-X/negative-Z perspective and matching oblique orthographic put native screen-left and source screen-right. TOP/BOTTOM and the opposite positive-X/positive-Z oblique views put source screen-left and native screen-right. Always consult each image record, especially the three-way magenta comparison. Named TOP/BOTTOM views show their camera label in the raw image. Oblique orthographic was enabled through Blockbench's viewport menu and preserves the oblique direction so multiple rows do not overlap as they would in a straight FRONT/BACK view.

## Scope and limits

This is a real official Blockbench 5.2.2 preview in cloud window 44040196, not a substitute for native Bedrock shader/culling, alpha-test sidedness, emission, ambient lighting, connection/growth behavior or gameplay acceptance. Existing scene adapters and their limitations remain in force. All incense/catnip scenes are excluded because their separate repair/review was already completed. Wild vines, boards, device renderers, barrel assembly, particles and unrelated addon families are outside this batch.

No runtime, source model or source texture was edited. No Minecraft client, BDS, LIVE or user-local computer was used. No publication occurred. Only this review's read-only tabs were opened and closed without saving; other windows and terminals were untouched. Blockbench ended on New Tab with no modal and was handed to the OTC reviewer.
