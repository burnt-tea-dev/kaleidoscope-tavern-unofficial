# Tavern decorative and plant review batch

Prepared against runtime **0.6.212 / 4700ede2**. The source checkout's later commits changed evidence only; its runtime tree matched the pin. No source-repository edits, GUI interaction, Minecraft client, BDS, LIVE deployment, or user-local-computer access occurred.

**Status: 29 self-contained Blockbench scenes ready for GUI review. None has GUI acceptance.**

## Findings to inspect first

1. **Incense underside candidate, not a verified engine defect.** Sixteen source fill-bottom faces are absent from native geometry. The existing regression calls them hidden, but the base texture's central 4×4 area is transparent. Independent front-face first-hit rays see the source fill bottom at Y=1 and the native lid bottom at Y=4. All 256 central rays differ in depth; 254 differ in sampled RGBA. Inspect **BOTTOM and a low underside perspective** in all four `incenses-*.bbmodel` scenes. Do not call these removed faces proven occluded. Details: `incense-underside-candidate.json`.
2. **Magenta author-branch divergence.** Native retains Forge's 12 petal back faces. NeoForge, the actual pinned JAR, and the matching unpublished 26.1.2 model omit those faces. All 35 remaining NeoForge faces match native exactly; native has 47. No automatic rollback or runtime repair is proposed. Open `magenta-three-way-branch-difference.bbmodel` and inspect **BOTTOM, then a low underside/rear perspective**, not only the top. Forge is world X=-30, native X=0, NeoForge/JAR X=+30. Details: `magenta-branch-difference.json`.
3. **Existing plant thickness is explicitly unequal.** The paired face audit identifies 336 plant faces displaced by exactly ±0.08 model units around source zero-thickness sheets, giving native thickness 0.16. UVs and shade match. This is recorded as an observed adaptation, not exact geometry or proven engine equivalence.

## Coverage

The main 28 scenes contain **95 source/native pairs**, at most four pairs per scene:

- `tables-1..2`: all 7 table shapes, including the rotated connected forms.
- `string-lights-1..5`: all 17 colours/colourless forms.
- `incenses-1..4`: 8 incense types, each closed and open.
- `bare-trellises-1..2`: all 7 bare trellis shapes.
- `grape-crop-stages-1..2`, `gold_grape-crop-stages-1..2`, `ice_grape-crop-stages-1..2`: all 18 crop stage models.
- `grapevine-shapes-stages-1..3`, `gold_grapevine-shapes-stages-1..3`, `ice_grapevine-shapes-stages-1..3`: all 30 distinct vine stage/connection forms.
- The 29th scene is the separate magenta three-way branch comparison.

`manifest.json` lists the exact cases and offsets in each scene. Pair source is **world -X** and native is **world +X**. The default BB 5.2.2 perspective projects native screen-left and source screen-right; other cameras differ. Use group names/world coordinates rather than assuming fixed screen sides.

For ordinary pairs, inspect perspective and the orthographic view that exposes the asset's thin faces or connected ends. Inspect both sides of lights/crops and incense foliage. Connected-form and age scenes are static resource previews, not tests of connection or growth mechanics.

## Completed static checks

- 417 tracked input hashes; 28 main scene hashes; 88 embedded textures; 1,005 preview cubes and 3,900 textured face entries. UUID references and embedded texture dimensions are valid.
- **1,802 ordered nondegenerate face pairs:** 1,466 exact geometry pairs; 336 separately classified plant-thickness pairs. No paired UV, shade, or source/native texture-pixel mismatches. Sixteen unmatched source incense underside faces remain the specific candidate above. No unmatched native faces in the Forge comparison.
- **378 native state combinations across 33 blocks** resolve geometry, every material tag, texture binding, and face dimming. Every distinct native model has a scene. The 95 paired source state selections independently match pinned Forge and NeoForge blockstate JSON.
- 134 unique source assets checked against pinned Forge; all have verified actual-JAR blobs. All referenced texture pixels match. The sole semantic model difference from NeoForge/JAR is magenta; it is separately documented. Twenty-four selected same-path assets are absent in unpublished 26.1.2, so this is not a complete 26.1.2 asset audit.
- The existing `check_incense_surfaces.py` passes its eight-type/two-model cutout and overlap checks. Its result does **not** prove underside equivalence.

Machine-readable reports: `structural-validation.json`, `ordered-face-audit.json`, `routing-validation.json`, `manifest.json`, and the two candidate/divergence reports above.

## Converter and provenance boundaries

- Java parents and texture aliases resolve before conversion. UVs use each actual PNG's dimensions divided by 16. The batch preserves 164 rescale elements, Java shade, signed/reversed endpoints, and face UV quarter-turns. No tintindex was present.
- Six author elements have reversed endpoints: three light-blue X dimensions and three purple Y dimensions. Official BB 5.2.2 Java parse and Cube.extend preserve these values; preview passes signed endpoints to setShape. The independent ordered-corner audit handles them, including native per-face splits. See `blockbench-codec-provenance.json` for application/bundle/source hashes and exact source locations. Raw application code is not included.
- Native materials are resolved from the actual BP permutations and `material_instances`, including `face_dimming`; no inference is made from a material tag's name. This batch rejects box UV, inflate, mirror, nonzero bone rotations, and mixed cube face-dimming rather than silently approximating them.
- BB shade and front-face preview hints do not reproduce engine ambient occlusion, emissions, alpha-test sidedness, lighting, shaders, particles, or water behavior. BB itself gives zero-thickness preview geometry a 0.001 epsilon; this is not native geometry.
- The archive lock is a verified user-upload SHA-256/blob record, not a publisher checksum. No JAR was executed. Forge c4ec1880 and NeoForge a1afba34 are independently pinned; unpublished 26.1.2 uses 9b8f165a.

## Reproduction

Run `python build_scenes.py`, `python validate_scenes.py`, `python check_routing.py`, `python make_magenta_branch_scene.py`, and `python check_incense_underside.py` from this folder with the referenced checkout paths present. These commands only write review artifacts here. Source receipts are local hash-checked lookup caches; scenes themselves need no external texture files.

Boards/text, barrel/device renderers, wild-grape hanging variants, particles, item/held poses, gameplay, GUI acceptance, and remaining addon families are not completed by this batch. Existing accepted held poses are unchanged.
