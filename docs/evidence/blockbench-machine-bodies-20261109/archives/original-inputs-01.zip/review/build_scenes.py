"""Bounded, read-only machine body fixtures. Runtime is never edited.
Java JSON elements and actual Java ModelPart declarations are independent inputs.
Nested rotations are retained (each node single-axis here); no affine decomposition.
"""
from pathlib import Path
import json, re, copy, math, hashlib, subprocess, sys, io, base64
import numpy as np
from PIL import Image
H=Path(__file__).resolve().parent; W=H.parent
sys.path.insert(0,str(H))
import review_codec as C
C.OUT=H/'scenes'
REPO=W/'tavern-bottles-publication-20261109'; JAVA=W/'tavern-visual-review-20261108/java-reference'; R=H/'snapshot'
MAIN='d42a39745f25082aa129f4d4bb823684e4174771'; FORGE='c4ec1880bd44cf3139d3ba744ab30bb379cf1416'; NEO='a1afba34981a00e89d57130d3dc8f1e64f1820a2'
AS='src/main/resources/assets/kaleidoscope_tavern/'; JA='src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/'
sha=lambda b:hashlib.sha256(b).hexdigest()
M={'schema':1,'main':MAIN,'runtime_version':'0.6.213','runtime_tree':'38c5977dd6bfe14b1824734612e3c601e1e41028','source_pins':{'Forge':FORGE,'NeoForge':NEO},'inputs':{},'source_comparison':{},'scenes':[],'cases':[],'gui_reviewed':False}
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
assert git(REPO,'rev-parse',MAIN+':runtime').decode().strip()==M['runtime_tree']
def track(p,owner=None,rel=None):
 b=p.read_bytes(); M['inputs'][str(p.relative_to(H))]={'sha256':sha(b),'bytes':len(b),'owner':owner,'original_path':rel};return p
def native(rel):return track(R/rel,'canonical '+MAIN,rel)
def source(rel):
 dst=H/'inputs/forge'/rel
 if not dst.exists():dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(git(JAVA,'show',FORGE+':'+rel))
 track(dst,'Forge '+FORGE,rel)
 if rel not in M['source_comparison']:
  b=dst.read_bytes(); proc=subprocess.run(['git','-C',str(JAVA),'show',NEO+':'+rel],capture_output=True)
  row={'path_present':proc.returncode==0}
  if proc.returncode==0:
   nd=H/'inputs/neoforge'/rel;nd.parent.mkdir(parents=True,exist_ok=True);nd.write_bytes(proc.stdout);track(nd,'NeoForge '+NEO,rel)
   row.update(sha256=sha(proc.stdout),bytes_equal=b==proc.stdout)
   if rel.endswith('.json'):row['json_equal']=json.loads(b)==json.loads(proc.stdout)
   elif rel.endswith('.png'):
    a,c=Image.open(io.BytesIO(b)).convert('RGBA'),Image.open(io.BytesIO(proc.stdout)).convert('RGBA');row['pixels_equal']=a.size==c.size and a.tobytes()==c.tobytes()
   else:row['text_equal_ignoring_line_endings']=b.decode().splitlines()==proc.stdout.decode().splitlines()
  M['source_comparison'][rel]=row
 return dst
read=lambda p:json.loads(p.read_text())
def rot(r):
 x,y,z=np.radians(r);X=np.array([[1,0,0],[0,np.cos(x),-np.sin(x)],[0,np.sin(x),np.cos(x)]]);Y=np.array([[np.cos(y),0,np.sin(y)],[0,1,0],[-np.sin(y),0,np.cos(y)]]);Z=np.array([[np.cos(z),-np.sin(z),0],[np.sin(z),np.cos(z),0],[0,0,1]])
 return Z@Y@X

def boxfaces(uv,size,mirror=False):
 u,v=uv;w,h,d=size
 ff={'east':[u,v+d,u+d,v+d+h],'west':[u+d+w,v+d,u+2*d+w,v+d+h],'up':[u+d+w,v+d,u+d,v],'down':[u+d+2*w,v,u+d+w,v+d],'south':[u+2*d+w,v+d,u+2*d+2*w,v+d+h],'north':[u+d,v+d,u+d+w,v+d+h]}
 if mirror:
  for k,(a,b,c,d) in ff.copy().items():ff[k]=[c,b,a,d]
  ff['east'],ff['west']=ff['west'],ff['east']
 return {k:{'uv':v,'rotation':0} for k,v in ff.items()}

def add_native(sc,stem,tex,off,parent=None,anim=None):
 gp=native('runtime/RP/models/entity/'+stem+'.geo.json');g=read(gp)['minecraft:geometry'][0]
 assert Image.open(tex).size==(g['description']['texture_width'],g['description']['texture_height'])
 ti=sc.texture(tex);nodes={};a=lambda v:[v[k]+off[k] for k in range(3)]
 top=parent or sc.group('CURRENT world +X | '+stem,off)
 for b in g['bones']:
  assert 'scale' not in b and not b.get('reset')
  p=b.get('pivot',[0,0,0]);r=b.get('rotation',[0,0,0]);ap=(anim or {}).get(b['name'],{});pos=ap.get('position',[0,0,0]);r=[r[k]+ap.get('rotation',[0,0,0])[k] for k in range(3)]
  assert sum(abs(x)>1e-8 for x in r)<=1,'Non-single-axis group needs explicit Euler review'
  # Position is a local bone-space translation. Represent by a parent translation group,
  # shifting its entire subtree while retaining its original rotation pivot.
  base=[-p[0],p[1],p[2]];node=sc.group(b['name'],a(base),[-r[0],-r[1],r[2]],nodes.get(b.get('parent'),top));nodes[b['name']]=node
  sc.j['groups'][-1]['_review_position']=[-pos[0],pos[1],pos[2]]
  for i,c in enumerate(b.get('cubes',[])):
   assert not c.get('inflate') and not c.get('mirror') or isinstance(c['uv'],list)
   o,z=c['origin'],c['size'];fr=[-o[0]-z[0],o[1],o[2]];to=[fr[k]+z[k] for k in range(3)];p=c.get('pivot',[0,0,0]);r=c.get('rotation',[0,0,0])
   if isinstance(c['uv'],list):ff=boxfaces(c['uv'],z,c.get('mirror',b.get('mirror',False)))
   else:
    ff={}
    for side,f in c['uv'].items():
     u,v=f['uv'];du,dv=f['uv_size'];uv=[u,v,u+du,v+dv]
     if side in ('up','down'):uv=uv[2:]+uv[:2]
     ff[side]={'uv':uv,'rotation':f.get('uv_rotation',0)}
   ff={s:{**f,'texture':ti} for s,f in ff.items()}
   sc.cube(stem+':'+b['name']+':'+str(i),a(fr),a(to),ff,a([-p[0],p[1],p[2]]),[-r[0],-r[1],r[2]],node);sc.j['elements'][-1]['shade']=True
 return gp,g

def resolve(rel):
 j=read(source(AS+'models/'+rel+'.json'))
 if j.get('parent'):
  ns,p=j['parent'].split(':');assert ns=='kaleidoscope_tavern';pa=resolve(p);j={**pa,**j,'textures':{**pa.get('textures',{}),**j.get('textures',{})}}
 return j

def add_java(sc,rel,off,parent=None):
 j=resolve(rel);node=parent or sc.group('SOURCE world -X | '+rel,off);add=lambda v:[v[k]+off[k]+(-8 if k!=1 else 0) for k in range(3)]
 for i,e in enumerate(j['elements']):
  fr,to=e['from'][:],e['to'][:];r=e.get('rotation',{});axis='xyz'.index(r.get('axis','y'));angles=[0,0,0];angles[axis]=r.get('angle',0);p=r.get('origin',[8,0,8])
  if r.get('rescale'):
   assert abs(angles[axis]) in (0,22.5,45);scale=1/math.cos(math.radians(angles[axis]))
   for k in range(3):
    if k!=axis:fr[k]=p[k]+(fr[k]-p[k])*scale;to[k]=p[k]+(to[k]-p[k])*scale
  faces={}
  for s,f in e['faces'].items():
   t=f['texture'];seen=set()
   while t.startswith('#'):assert t not in seen;seen.add(t);t=j['textures'][t[1:]]
   ns,tr=t.split(':');assert ns=='kaleidoscope_tavern';tp=source(AS+'textures/'+tr+'.png');wh=Image.open(tp).size;assert 'uv'in f and f.get('tintindex',-1)==-1
   faces[s]={'uv':[v*wh[k%2]/16 for k,v in enumerate(f['uv'])],'texture':sc.texture(tp),'rotation':f.get('rotation',0)}
  sc.cube(rel+':'+str(i),add(fr),add(to),faces,add(p),angles,node);sc.j['elements'][-1]['shade']=e.get('shade',True)
 return j

NUM=r'-?\d+(?:\.\d+)?'
def entity_parts(filename):
 text=source(JA+'client/model/'+filename+'.java').read_text()
 patt=r'PartDefinition\s+(\w+)\s*=\s*(\w+)\.addOrReplaceChild\("([^"]+)",\s*(.*?),\s*PartPose\.(offsetAndRotation|offset)\((.*?)\)\);'
 parts={}
 for var,parent,name,body,typ,args in re.findall(patt,text,re.S):
  vals=[float(x) for x in re.findall(NUM,args)];off=vals[:3];r=vals[3:] if len(vals)==6 else [0,0,0];boxes=[];uv=None;mirror=False
  for token in re.finditer(r'\.texOffs\(([^)]*)\)|\.mirror\(([^)]*)\)|\.addBox\((.*?)new CubeDeformation\(([^)]*)\)\)',body,re.S):
   if token[1]:uv=[float(x) for x in re.findall(NUM,token[1])]
   elif token[2] is not None:mirror=token[2].strip()!='false'
   else:
    vals=[float(x) for x in re.findall(NUM,token[3])];assert len(vals)==6 and float(token[4].replace('F',''))==0 and uv is not None
    boxes.append({'from':vals[:3],'size':vals[3:],'uv':uv[:],'mirror':mirror})
  parts[var]={'parent':parent if parent in parts else None,'name':name,'offset':off,'rotation_rad':r,'boxes':boxes}
 assert parts and 'root'in parts
 return parts

def add_entity_source(sc,filename,tex,off,exclude=(),anim=None,shaker=False):
 parts=entity_parts(filename);top=sc.group('SOURCE world -X | '+filename,off,[0,180,0] if shaker else [0,0,0]);ti=sc.texture(tex);nodes={};absolute={};a=lambda v:[v[k]+off[k] for k in range(3)]
 for key,p in parts.items():
  absolute[key]=np.array(p['offset'])+(absolute[p['parent']] if p['parent'] else 0)
  if key in exclude or p['parent'] in exclude:continue
  q=absolute[key];pivot=[-q[0],24-q[1],q[2]];ap=(anim or {}).get(key,{})
  r=np.degrees(p['rotation_rad'])+np.array(ap.get('rotation',[0,0,0]));assert sum(abs(v)>1e-8 for v in r)<=1
  node=sc.group(key,a(pivot),[-r[0],-r[1],r[2]],nodes.get(p['parent'],top));nodes[key]=node
  pos=ap.get('position',[0,0,0]);sc.j['groups'][-1]['_review_position']=[-pos[0],pos[1],pos[2]]
  for i,c in enumerate(p['boxes']):
   o=q+np.array(c['from']);z=c['size'];fr=[-o[0]-z[0],24-o[1]-z[1],o[2]];to=[fr[k]+z[k] for k in range(3)]
   ff={s:{**f,'texture':ti} for s,f in boxfaces(c['uv'],z,c['mirror']).items()}
   sc.cube(filename+':'+key+':'+str(i),a(fr),a(to),ff,a(pivot),[0,0,0],node);sc.j['elements'][-1]['shade']=True
 return parts

# Bake only animation translations into descendant absolute pivots/positions.
# Leave nested single-axis rotations intact; no decomposition or angle normalization.
def bake_positions(sc):
 gs={g['uuid']:g for g in sc.j['groups']};es={e['uuid']:e for e in sc.j['elements']}
 def walk(node,inherited):
  g=gs[node['uuid']];d=np.array(inherited)+g.pop('_review_position',[0,0,0]);g['origin']=(np.array(g['origin'])+d).tolist()
  for ch in node['children']:
   if isinstance(ch,dict):walk(ch,d)
   else:
    e=es[ch]
    for key in ('from','to','origin'):e[key]=(np.array(e[key])+d).tolist()
 for n in sc.j['outliner']:walk(n,[0,0,0])

terrain=read(native('runtime/RP/textures/terrain_texture.json'))['texture_data']
def blocktex(block):
 b=read(native('runtime/BP/blocks/'+block+'.json'))['minecraft:block'];mat=b['components']['minecraft:material_instances'];tp=terrain[mat['*']['texture']]['textures'];assert isinstance(tp,str)
 return native('runtime/RP/'+tp+'.png'),mat

def entitytex(ent):
 p=native('runtime/RP/entity/'+ent+'.entity.json');d=read(p)['minecraft:client_entity']['description'];return native('runtime/RP/'+d['textures']['default']+'.png'),d

def record(sc,name,cases,views):
 bake_positions(sc);sc.save(name+'.bbmodel');p=H/'scenes'/ (name+'.bbmodel')
 M['scenes'].append({'file':str(p),'sha256':sha(p.read_bytes()),'cases':[c['id'] for c in cases],'recommended_views':views,'gui_reviewed':False})
 for c in cases:M['cases'].append({**c,'scene':name+'.bbmodel'})
 print(name,len(sc.j['elements']),'cubes',flush=True)

# Two large barrel fixtures retain authored hinges and zero-thickness strut.
for mode in ('closed','open'):
 sc=C.Scene('N02 barrel '+mode+' | SOURCE -X | CURRENT +X');jo=[-32,0,0];no=[32,0,0]
 tex,route=entitytex('runtime_barrel_'+mode);sp=source(AS+'textures/entity/brew/barrel.png')
 parts=add_entity_source(sc,'brew/BarrelModel',sp,jo,exclude=('open','open_r1','open_r2') if mode=='closed' else ('close',))
 gp,g=add_native(sc,'barrel_'+mode,tex,no)
 record(sc,'barrel-'+mode,[{'id':'barrel-'+mode,'source_kind':'Java ModelPart','source_model':'brew/BarrelModel','source_offset':jo,'native_offset':no,'source_render_transform':'translate(0.5,1.5,0.5); rotate Z -180; rotate Y 0 for north; review center removes X/Z +8','native_route':route,'facing':'north','materials':{'source':'entityCutoutNoCull','native':route['materials']}}],['perspective','top','back (open hinge)' if mode=='open' else 'bottom'])

for family,specs in [('pressing-tubs',[('upright','block/brew/pressing_tub','pressing_tub'),('tilt','block/brew/tilt_pressing_tub','pressing_tub_tilt')]),('taps',[('closed','block/brew/tap/close','tap_closed'),('open','block/brew/tap/open','tap_open')])]:
 sc=C.Scene('N02 '+family+' | SOURCE -X | CURRENT +X');cases=[];block='pressing_tub' if family=='pressing-tubs' else 'tap';tex,mat=blocktex(block)
 for idx,(label,jm,ng) in enumerate(specs):
  jo=[-15,0,idx*32];no=[15,0,idx*32];j=add_java(sc,jm,jo);add_native(sc,ng,tex,no)
  cases.append({'id':block+'-'+label,'source_model':jm,'source_kind':'Java JSON','source_offset':jo,'native_offset':no,'facing':'north','native_geometry':ng,'materials':{'source':j.get('render_type'),'native':mat},'states':{'block_face':'north' if label=='tilt' or block=='tap' else 'up','cardinal_direction':'north',**({'open':int(label=='open')} if block=='tap' else {})}})
 record(sc,family,cases,['perspective','top','bottom' if family=='pressing-tubs' else 'front / back'])

# Runtime placement uses TWO blocks. The assembled entity is not spawned by the current helper.
sc=C.Scene('N02 stepladder placed assembly | SOURCE -X | CURRENT +X');jo=[-20,0,0];no=[20,0,0];tex,mat=blocktex('stepladder')
for half,y in [('bottom',0),('top',16)]:add_java(sc,'block/deco/stepladder/'+half,[jo[0],y,0]);add_native(sc,'stepladder_'+half,tex,[no[0],y,0])
record(sc,'stepladder-placed-assembly',[{'id':'stepladder-placed-assembly','source_kind':'Java JSON two blocks','source_offset':jo,'native_offset':no,'source_models':['block/deco/stepladder/bottom','block/deco/stepladder/top'],'native_geometry':['stepladder_bottom','stepladder_top'],'native_route':'runtime/BP/blocks/stepladder.json; decorations.js placeStepladder creates bottom + top at +1 block','not_active_route':'runtime/RP/entity/stepladder_assembled.entity.json is an asset, not the actual placed helper route','materials':mat}],['perspective','side (join seam)','bottom'])
entitytex('stepladder_assembled');native('runtime/RP/models/entity/stepladder_assembled.geo.json')

# Placed shaker idle and two exact keyframes, no interpolation claims.
an=read(native('runtime/RP/animations/shaker.animation.json'))['animations']['animation.kt_assets_a8.shaker.put']
java_anim=source(JA+'client/animation/ShakerAnimation.java').read_text();put=java_anim.split('public static final AnimationDefinition PUT =',1)[1].split(').build();',1)[0]
# Compare the actual Java PUT channels to the native animation keyframe numbers.
channels={}
for bone,target,body in re.findall(r'\.addAnimation\("(\w+)", new AnimationChannel\(AnimationChannel.Targets\.(\w+),(.*?)(?=\.addAnimation|$)',put,re.S):
 vals={}
 for time,method,args in re.findall(r'new Keyframe\(('+NUM+r')F, KeyframeAnimations\.(degreeVec|posVec)\((.*?)\), AnimationChannel.Interpolations.CATMULLROM\)',body):vals[time]=[float(x) for x in re.findall(NUM,args)]
 channels.setdefault(bone,{})['rotation' if target=='ROTATION' else 'position']=vals
assert channels and set(channels)==set(an['bones'])
for bone,ch in channels.items():
 for prop,frames in ch.items():
  assert {float(k):v for k,v in frames.items()}=={float(k):v['post'] for k,v in an['bones'][bone][prop].items()}
sc=C.Scene('N02 placed shaker | SOURCE -X | CURRENT +X');cases=[];tex,route=entitytex('runtime_shaker');sp=source(AS+'textures/block/mixology/shaker.png')
for idx,t in enumerate([0,.0833,.2083]):
 # root returns to 0 by .1667, so later keyframe clamping is exact.
 state={};jstate={}
 for bone,ch in an['bones'].items():
  state[bone]={};jstate[bone]={}
  for prop,frames in ch.items():
   keys=sorted(float(k) for k in frames);key=t if t in keys else max(k for k in keys if k<=t);assert t in keys or t>=max(keys)
   native_frame=next(v['post'] for k,v in frames.items() if float(k)==key);java_frame=next(v for k,v in channels[bone][prop].items() if float(k)==key)
   state[bone][prop]=native_frame;jstate[bone][prop]=java_frame
 jo=[-12,0,idx*26];no=[12,0,idx*26];add_entity_source(sc,'mixology/ShakerModel',sp,jo,anim=jstate,shaker=True);add_native(sc,'shaker',tex,no,anim=state)
 cases.append({'id':'shaker-put-'+str(t),'source_kind':'Java ModelPart + PUT','source_model':'mixology/ShakerModel','source_offset':jo,'native_offset':no,'time_seconds':t,'evaluated_keyframe':state,'materials':{'source':'entityCutoutNoCull','native':route['materials']},'native_route':'shaker_station base for idle; put_visual=1 hides block; immersion.js spawns shaker_visual at same origin for 8 ticks; controller plays PUT once'})
record(sc,'shaker-placed-put-keyframes',cases,['perspective','side (lid lift and pitch)','top (root yaw)'])

# Relevant source/runtime routes, including existing protected evidence.
for rel in ['runtime/BP/blocks/barrel_core.json','runtime/BP/blocks/shaker_station.json','runtime/BP/scripts/bedrock/machines.js','runtime/BP/scripts/core/machine-visuals.js','runtime/BP/scripts/bedrock/decorations.js','runtime/BP/scripts/bedrock/immersion.js','runtime/RP/animation_controllers/runtime_shaker_put.controller.json','runtime/RP/attachables/shaker.attachable.json','runtime/RP/animations/runtime_shaker.animation.json','runtime/RP/models/entity/runtime_shaker_held.geo.json','runtime/RP/models/entity/runtime_shaker_put_hidden.geo.json','runtime/BP/entities/shaker_visual.json','runtime/BP/entities/barrel_open_visual.json','runtime/BP/entities/barrel_closed_visual.json','docs/evidence/blockbench-20261108/README.md','docs/evidence/blockbench-20261108/scene-records.json','docs/evidence/t174-held-shells/native-review.json','docs/evidence/t175-rack-lift/native-review.json','docs/NATIVE-ITEM-VIEW-LIMITS.md']:native(rel)
for rel in ['client/render/block/BarrelBlockEntityRender.java','client/render/block/PressingTubBlockEntityRender.java','client/render/block/ShakerBlockEntityRender.java','block/deco/StepladderBlock.java','datagen/model/BlockStateGenerator.java']:source(JA+rel)
for block in ['pressing_tub','tap','stepladder','shaker']:source('src/generated/resources/assets/kaleidoscope_tavern/blockstates/'+block+'.json')
# Static controller routing is real, but its engine shader is not executed here.
for p in (R/'runtime/RP/render_controllers').glob('*.json'):
 if 'controller.render.kt_assets_a1.static' in p.read_text():track(p,'canonical '+MAIN,str(p.relative_to(R)))
M['layout']='Source at negative world X, current at positive X. Default BB camera normally projects current screen-left. Camera-dependent, never infer from filename.'
M['limits']=['No GUI or game was run.','Static editor fixtures are not controller/timing/material/collision/placement acceptance.','No held poses, tilted rack lift, runtime bytes, computer settings, plugins or deployments changed.','Shaker samples are exact keyframes only; Catmull-Rom between-key timing and engine float/query behavior remain unverified.','Source/nested transforms are rigid and all participating nodes have one nonzero axis; no affine/shear approximation is used.','Entity alpha-test and source no-cull are material hints, not proof of shader equivalence.']
(H/'manifest.json').write_text(json.dumps(M,indent=2)+'\n')
