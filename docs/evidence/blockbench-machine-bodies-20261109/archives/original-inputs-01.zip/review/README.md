# N02 machine and utility body review preparation

Prepared against canonical Tavern **0.6.213**, main `d42a39745f25082aa129f4d4bb823684e4174771`, runtime tree `38c5977dd6bfe14b1824734612e3c601e1e41028`.

**Preparation is complete. GUI review is pending. No runtime defect was found by the bounded data checks.** This folder does not claim Minecraft, BDS, controller, placement, physics, held-view or all-addon acceptance. No runtime files, accepted poses, plugins, settings or deployment were changed.

## Capture queue

Six self-contained `.bbmodel` files cover ten source/current pairs. Original PNG bytes are embedded, with source at negative world X and current at positive X. The default Blockbench perspective normally projects **current on screen-left, source on screen-right**. Confirm the named groups if the camera is changed. Do not use LEFT/RIGHT filenames as identity evidence.

| Scene | Cases | Discriminating views |
| --- | --- | --- |
| `scenes/barrel-closed.bbmodel` | Closed body, lid, feet | Perspective, top, bottom |
| `scenes/barrel-open.bbmodel` | Open lid, zero-width hinge strut, cavity | Perspective, top, rear hinge |
| `scenes/pressing-tubs.bbmodel` | Upright at Z=0; tilted at Z=32 | Perspective, top, bottom |
| `scenes/taps.bbmodel` | Closed at Z=0; open at Z=32 | Perspective, top, front/back handle and spout |
| `scenes/stepladder-placed-assembly.bbmodel` | Bottom plus top at Y+16 | Perspective, side seam, bottom |
| `scenes/shaker-placed-put-keyframes.bbmodel` | Idle at Z=0; 0.0833 s at Z=26; 0.2083 s at Z=52 | Perspective, side lid lift/pitch, top root yaw |

The queue is about 18-20 useful captures, not an exhaustive camera sweep. Save original screenshots and their hashes after actual GUI inspection. Open without plugins; never export these review fixtures over runtime assets. The parent schedules GUI use. This preparation did not open or change a GUI.

## Source authority and what was actually resolved

- Forge source: `c4ec1880bd44cf3139d3ba744ab30bb379cf1416`.
- NeoForge 1.21.1 source: `a1afba34981a00e89d57130d3dc8f1e64f1820a2`.
- Exact Git object bytes are retained under `inputs/forge` and `inputs/neoforge`. `manifest.json` pins original path, owner, byte length and SHA-256 for each used input.
- Barrel body comes from actual `BarrelModel.createBodyLayer` plus `BarrelBlockEntityRender`, not barrel item JSON. Closed/open visibility and nested hinge pivots are preserved.
- Pressing tub and tap bodies come from their actual JSON block models and selected north states. PressingTubBlockEntityRender renders ingredients/liquid, not a different body. Contents belong to N03 and are excluded here.
- **Placed stepladder uses two blocks**, bottom at Y=0 and top at Y=16. `decorations.js` calls `ladderPair`; it does not spawn `stepladder_assembled`. That retained entity asset was inspected but is not falsely labeled the active placed route or added to the GUI queue.
- Placed shaker comes from `ShakerModel`, its actual renderer and PUT channels. The station hides its block mesh while `shaker_visual` runs PUT. The helper is spawned at the same base origin, not the superseded +0.78 offset. Its controller ends at 0.375 seconds; script and entity cleanup use eight ticks / 0.4 seconds.
- The three shaker fixtures are **frozen exact keyframes**, not a running animation or Catmull-Rom interpolation test. The root channel is clamped to its final zero after 0.1667 s for the 0.2083 s sample. Java `posVec` Y inversion is evaluated explicitly.
- Relevant ModelPart declarations, PUT channels and renderer pose calls match both pinned source branches. NeoForge API signatures and barrel render bounding box differ, so full renderer equivalence is not asserted. See `source-branch-semantics.json`.
- Eleven applicable original locked-JAR assets were read as actual Git blobs and checked against the author lock. Six JSON models are semantically equal despite byte/line-ending differences; five textures have equal pixels. See `author-archive-verification.json`.

## Coordinate and material limits

The entity comparisons intentionally stop at the **documented body/reference frame**. Java renderer translation and pose transforms are evaluated; the current side is decoded model geometry plus its internal bones/PUT pose. No Bedrock engine entity-to-world transform is simulated. In particular, barrel north routes through `facingYaw(0)=180`, while shaker helper rotation is `facing*90`. These external rotations are recorded in `routing-validation.json` and the manifest. Body agreement must not be described as in-world facing or placement acceptance.

Java entity bodies request `entityCutoutNoCull`; native helpers request `entity_alphatest`. Block bodies request cutout/alpha-test and their recorded face-dimming/AO settings. Fixtures preserve original texture alpha and show editor surfaces. They do not execute either engine material, no-cull behavior, lighting, PBR, transparency sorting, selection or controller transitions.

## Independent validation

`ordered-face-world-audit.json` reports:

- 10 cases, 452 paired nonzero-area faces, complete one-to-one UV-constrained matching.
- Zero UV, texture-pixel or carried shade-flag mismatches.
- Largest coordinate difference: **8.85e-9 model pixels**, due to stored barrel radian-to-degree rounding.
- All 170 saved cubes / 1,360 vertices are evaluated through their complete nested group matrices.
- Independently parsed original Java ModelPart local matrices check 336 source vertices directly. Original ModelPart polygon/atlas assignments independently check 208 UV faces, including the mirrored zero-width barrel strut.
- All 680 original native-geometry vertices and 496 native UV face records are independently decoded and compared to the saved scenes, without importing the builder.
- Another 344 original JSON model vertices are evaluated directly, including source rotations, rescale semantics and the stepladder upper block offset.
- 94 original-input hashes and all six scene hashes are verified. Twelve embedded PNG entries are readable and match their declared actual/virtual dimensions.

These checks evaluate the saved scenes, not only the builder's own intermediate arrays. Zero-area faces are excluded from face matching, not silently inflated. Blockbench may display its own tiny zero-plane preview epsilon; that is not a native geometry fix.

## Converter boundaries

`review_codec.py` is an unchanged copy of the robust earlier helper. This builder adds explicitly audited handling for box UV, mirror, nested ModelPart groups and keyframe translation. Source JSON rescale and shade are preserved. Each scene has a single texture size, so no cross-texture virtual-dimension normalization is needed.

Every participating group has at most one nonzero rotation axis. Nested yaw/pitch remains a hierarchy. No multi-axis group-Euler assumption, matrix decomposition, nonuniform scale or shear approximation is used. Keyframe translations move the entire correct descendant subtree while retaining the local rotation pivot; the independent raw Java matrix check confirms that operation. Future scale/shear cases must be evaluated faithfully or left pending, not fitted to cubes.

## Prior accepted scope is preserved

The earlier Blockbench shaker review covers held idle and two held-shake samples, not these placed PUT poses. Its held geometry, texture, attachable and animation are **byte-identical** to current inputs, so those observations are not repeated. T175 tilted-rack +6 lift remains byte-identical and unchanged. T174 was consulted for scope, not generalized to this review. The recorded Allium first-person clipping remains unresolved.

See `prior-evidence-reuse.json`. No broad transform correction was made or proposed.

## Reproduce

From this folder, with the pinned repositories already present in the workspace:

1. `python build_scenes.py`
2. `python finalize_provenance.py`
3. `python validate_scenes.py`

This is local read-only source analysis plus writing review artifacts. Source checkout paths used for reproduction are in the scripts; saved `.bbmodel` files need no checkout or external texture files to open. After preparation, the snapshot is reduced to only manifest-listed inputs. Runtime/publication work remains outside this task.
