# N06 outline/scoping audit, 2026-11-09

## Decision

**Explicit unresolved native adaptation. No supported minimal scoping patch established.** The Java first-person-scoping override is real and absent from the active native condition. The inspected supported addon APIs do not establish how this board helper can observe the current viewer's actual first-person AND active spyglass state. Do not replace that missing observation with held-item, FOV, nearest-player, global-property or board-entity first-person heuristics. No runtime edit or engine acceptance is warranted by this audit.

This is not proof that every possible future client API cannot implement it. It is a bounded finding for the current helper architecture and declared dependencies. The current stable documentation is newer than the declared API, and exact 2.7.0 archived declarations were not retrieved. No beta installation or upgrade was attempted.

## Reproducible identity

Canonical native main: `7fb1afc86439d67703df202d04923d4bcdc4466b`, package 0.6.215. Native files in `inputs/current` were read directly with `git show` at this commit, with lazy fetching and all Git protocols disabled. The local plant worktree HEAD is a different development commit, so worktree identity is not treated as canonical. Active board entity/controller/animation/scripts match the N06 prep snapshots byte-for-byte. The prep's package.json is a minimal local module stub, not the canonical package: this audit snapshots the real pinned package.json instead.

Forge: `c4ec1880bd44cf3139d3ba744ab30bb379cf1416`; NeoForge: `a1afba34981a00e89d57130d3dc8f1e64f1820a2`. Java sources and licenses are bounded copies from the N06 pinned source snapshots. TextBlockEntityRender is identical across those two snapshots. `snapshot-manifest.json` contains SHA256 and provenance for 21 inputs. `reused-upstream-freshness.json` is explicitly reused evidence from pressing-card integration, checked 2026-11-09T04:07:14Z, not a fresh branch check by this worker. This report does not claim current branch heads beyond that receipt or include a .216 candidate.

Native BP manifest declares minimum engine 1.26.50, `@minecraft/server` 2.7.0 and `@minecraft/server-ui` 2.0.0. Board BP entity format is 1.21.80; RP client entity is 1.10.0. No installed package versions override these declarations.

## Exact Java predicate and boundaries

Let C = distance from main camera position to board block center; E = distance from camera ENTITY position to board block center; G = board glowing; B = text color equals DyeColor.BLACK text color; S = local player exists AND camera option is first person AND local player.isScoping(); H = camera entity exists. Subject to nonblank text and normal renderer dispatch:

- Text is attempted iff C <= 48 (TextBlockEntityRender.java lines 41–47).
- Outline is attempted iff C <= 48 AND G AND (B OR S OR (H AND E² < 256)) (lines 77–86, 98–103, 134–145).
- Non-glowing text never gets outline, including black and scoping.
- Glowing black always gets outline inside the outer text gate. It does not need a player, camera entity, first-person state or near distance.
- Glowing non-black with S=true gets outline throughout C <= 48, irrespective of E or H.
- Glowing non-black with S=false requires H and E < 16. Exactly E=16 is excluded, not included. Exactly C=48 is included; C>48 excludes all text/outline, including black and scoping.
- Third-person scoping does not activate S. Holding a spyglass without active isScoping does not activate S. The renderer calls Minecraft's isScoping; it does not inspect hand inventory itself. The body of Minecraft's method is not present in this Tavern snapshot and has not been independently executed.

Do not collapse C and E into one distance. They can differ with eye height, third-person displacement, attached/spectator cameras and other camera behavior. Thus '16–48 blocks' is only a shorthand under a common-distance assumption, not the exact Java rule.

`predicate-truth-table.json` enumerates 144 finite predicate combinations, with C around 16/48 and E around 16. This is an analytical Boolean table, not a Java, Molang, client or renderer test. With C=E=d and a camera entity present: d<16 gives glowing outlines for both black/non-black; 16<=d<=48 gives black always, non-black only with S; d>48 gives neither. For G=false every row is false.

Java source: https://github.com/KaleidoscopeMods/KaleidoscopeTavern/blob/c4ec1880bd44cf3139d3ba744ab30bb379cf1416/src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/client/render/block/TextBlockEntityRender.java#L134-L145
Neo equivalent: https://github.com/KaleidoscopeMods/KaleidoscopeTavern/blob/a1afba34981a00e89d57130d3dc8f1e64f1820a2/src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/client/render/block/TextBlockEntityRender.java#L134-L145

## Native active route

All paths below are relative to inputs/current.

- `runtime/BP/scripts/bedrock/board-text.js` lines 27–30 stores full RGB for glow and floor(channel*0.6) otherwise. Lines 42–50 place EVERY glyph helper root at the owning block center; glyph positioning is carried through offsets, not displaced entity roots. Lines 78–86 spawn the helper and publish color/glow/layout properties.
- `runtime/BP/entities/board_glyph_visual.json` declares client-synced glyph/color/glow/layout properties. It is a stationary non-player helper, not a player, attachable or camera proxy. It has no scoped or local-viewer observation property.
- `runtime/RP/entity/board_glyph_visual.entity.json` lines 783–789 runs the layout animation and scale. Lines 791–797 selects outline iff D<=48 AND glowing AND (RGB sum==0 OR D<16); glyph iff D<=48. D is q.distance_from_camera. There is no S override.
- `runtime/RP/render_controllers/board_glyph_visual.render_controllers.json` lines 533–553 picks glyph cell/page, optional bold and default/glow material. Lines 1083–1108 picks outline cell/page, optional outline-bold, glow material and cream RGB (240,235,204) for black or floor(channel*0.6) otherwise. The renderer does not independently observe player scoping.
- `runtime/RP/animations/board_glyph_line.animation.json` applies property-driven root offsets/tilt and eight surrounding outline offsets plus bold copies. It does not select camera state or override controller visibility.

Molang documents D as root-to-camera distance. Because these helper roots are centered, the native D approximately targets Java's C, not its distinct E. The no-scope distance mismatch at the 16 boundary is therefore also an explicit adaptation. This audit does not authorize changing that metric to an unproven player-distance guess.

Glowing black stays black foreground with a separate cream outline, not cream foreground. Non-glowing black remains black without outline. Java supplies 0xf000f0 lighting for glow and packed lighting otherwise; native material names match intended roles but static inspection cannot establish actual emissive/lighting/depth equivalence. Existing left/center/right and top behavior, justified/distributed and vertical extensions are untouched.

Native source: https://github.com/burnt-tea-dev/kaleidoscope-tavern-unofficial/blob/7fb1afc86439d67703df202d04923d4bcdc4466b/runtime/RP/entity/board_glyph_visual.entity.json#L791-L797

## API capability evidence and limits

Authoritative Microsoft Learn pages were read on 2026-11-09. Bounded paraphrased receipts and exact relevant section/line ranges are in `documentation-evidence.md`. Important distinctions:

1. q.distance_from_camera has the needed viewer-local distance contract. q.is_using_item is about the queried entity, not the current viewer. A board helper is not using a spyglass.
2. The dedicated current q.is_first_person page now says it is deprecated and always returns 0, suggesting variable.is_first_person. Older search-index snippets still describe entity first-person rendering. Neither is evidence that a custom board's render-controller query reads the player's camera setting. No documented contract establishing variable.is_first_person plus active scoping in this custom helper context was found. The dedicated page was updated November 6, so this is not asserted as a historical behavior change in every 1.26.50 build.
3. q.is_local_player classifies the entity being evaluated as the local player for the current window (with explicit split-screen semantics); it does not return a local-player reference or project the player's state into an arbitrary helper. Its documented required format >=1.19.60 is also newer than this RP client entity's 1.10.0. Merely adding this query is not a fix.
4. Camera API exposes control methods, including setCamera, not an observed current user-selected first/third-person getter or scoping getter in the inspected method list. getControlScheme is a control scheme, not proof of actual first-person perspective. Setting a camera to force the desired state would alter gameplay and is not a parity repair.
5. itemStartUse/itemStopUse/itemReleaseUse document chargeable-item transitions; itemUse reports successful use. Those contracts alone do not establish a continuously accurate spyglass-scoping observation, camera perspective, reconnect initialization, cancellation and timing in this exact version. Even a working spyglass event observation would not supply first-person state by itself.
6. Important correction to a tempting blanket limitation: per-player property overrides DO have an official API contract. Player.setPropertyOverrideForEntity affects a client-synced property only for that player on the next tick. Changelog records its introduction in 1.19.0, before 2.x; it is not a new beta-only solution. That can transport a *known* viewer-specific value, unlike shared Entity.setProperty. It does not observe the missing state. Current API docs are 2.11.0 rather than an archived 2.7.0 surface; the requested exact archive could not be opened, so a future implementation must verify the exact target declarations too. Do not state that all per-viewer properties are impossible.
7. Protocol packet camera/spyglass flags and native renderer internals, if separately documented, are not automatically Script API or Molang addon contracts. No packet interception, custom protocol server or renderer hook exists in this pack's active route. No such mechanism was introduced or claimed supported here.

## What would permit a future repair

First obtain a supported target-version API contract for actual viewer first-person AND active scoping (and, for strict distance parity, camera-entity identity/position). Only then design a viewer-local gate or per-player override with lifecycle clearing. Do not ship a heuristic simply because it makes the 16–48 sample look right.

Required subsequent engine checks: glowing non-black and black plus non-glowing controls at either side of E=16 and C=48; first/third person, active/released/held-only spyglass; different camera positions; two simultaneous viewers with opposite scope states and split-screen where supported; join/leave, dimension changes, helper replacement and reload clearing. Recheck current outline tint/material, bold and layering. These checks are prospective, not performed, and not a new request that the owner must operate a client.

No GUI, runtime edit, install, network write, release, broad test suite or engine observation was performed. Only bounded local snapshots, Boolean enumeration, read-only source/docs research and this report were created.
