# Bounded authoritative documentation receipts

Read 2026-11-09 through connected web tools. These are paraphrased findings, not full copied pages. Web line numbers refer to the tool's text extraction; use named sections if later page revisions shift them. Current Learn pages are mutable and are not archived 1.26.50/2.7.0 documentation. Some include pre-release members even under stable view; no pre-release member is proposed for use.

## Molang distance and item context

URL: https://learn.microsoft.com/en-us/minecraft/creator/reference/content/molangreference/examples/molangconcepts/queryfunctions?view=minecraft-bedrock-stable

Extracted lines 86 and 242: distance_from_camera measures current entity/emitter root to camera; is_using_item tests the current entity. No scoping query was found in the inspected index. The main index omitted first_person and local_player on this live retrieval, although older indexed snippets retain them. Dedicated pages below were therefore read rather than relying on search excerpts.

## First-person query

URL: https://learn.microsoft.com/en-us/minecraft/creator/reference/content/molangreference/examples/molangconcepts/queryfunctions/query_is_first_person?view=minecraft-bedrock-stable

Extracted line 32, page update line 56 = 2026-11-06. Exact bounded quote (8 words excluding code identifiers): “DEPRECATED (Use 'variable.is_first_person'): Always returns 0.0.” This page does not specify a board-helper contract for the suggested variable or establish which historical engine builds implement the deprecation. Do not map a board render pass to player camera mode without additional documentation.

## Local-player query

URL: https://learn.microsoft.com/en-us/minecraft/creator/reference/content/molangreference/examples/molangconcepts/queryfunctions/query_is_local_player?view=minecraft-bedrock-stable

Lines 32–36: classifies whether the evaluated entity is the current window's player; other split-screen views do not qualify, and behavior-pack evaluations are false. Requires format 1.19.60 or above. It is not a getter returning the viewer entity.

## Camera

URL: https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/camera?view=minecraft-bedrock-stable

Lines 34–56 list isValid plus camera-control methods. No getter for current first/third-person choice or scoping is listed. setCamera/setDefaultCamera control perspective; setFov controls rather than observes FOV. setCameraWithEase is explicitly cautioned as pre-release (lines 159–166), and was not considered a supported target-version repair. Page update 2026-09-16.

## Player and per-viewer delivery

URL: https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/player?view=minecraft-bedrock-stable

Lines 444–450: getControlScheme returns a control-scheme enum. Lines 816–842: setPropertyOverrideForEntity overrides a client-synced entity property for the selected player on the next tick without affecting other players. Lines 399–414: clearPropertyOverridesForEntity clears that player's overrides. These are real delivery contracts, not a way to observe scoped first-person state.

## Module/version and changelog

URL: https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/minecraft-server?view=minecraft-bedrock-stable

Lines 36–59: live module page is 2.11.0; available versions include 2.7.0. This page must not be represented as pinned 2.7.0 documentation.

URL: https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/changelog?view=minecraft-bedrock-stable

Lines 624–635: 2.7.0 changes add biome tag functionality/BiomeTypes and Entity.addItem. Lines 666–669: Camera attachment/animation added in 2.6.0. Lines 851–854: control-scheme getter/setter introduced in 2.4.0. Lines 1346–1350: per-player property-override APIs introduced in 1.19.0. Thus per-viewer delivery should not be dismissed as a newly invented beta feature. No observed first-person/scoping accessor was identified from these inspected surfaces.

## Use-event semantics

URL: https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/worldafterevents?view=minecraft-bedrock-stable

Lines 332–403: complete/release/start/stop use are described in chargeable-item terms; itemUse is successful item use. This is insufficient by itself to assert active spyglass state and perspective through all lifecycle transitions.

## Exact declaration retrieval limit

Attempted read-only URL https://unpkg.com/@minecraft/server@2.7.0/index.d.ts was inaccessible via the web tool (internal-error retrieval result, not an authorization denial). No install or alternate network access was attempted. Existing neighboring node_modules declarations are 2.11.0 and were not substituted for 2.7.0. A guessed Molang variables documentation URL was likewise unavailable; no claim is made that it establishes helper context.
