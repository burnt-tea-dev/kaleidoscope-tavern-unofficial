import fs from 'node:fs';
import {renderBoardText} from './inputs/current/runtime/BP/scripts/bedrock/board-text.js';
import {splitBoardLines,boardLayoutOptions,boardGlyphOffsets,boardVerticalOffset} from './inputs/current/runtime/BP/scripts/core/board-layout.js';
const defs=[
 ['sandwich-left-top','sandwich',false,'north','left','top','Fj W.i!\nAB 12',false,'white'],
 ['sandwich-center-middle-outline','sandwich',false,'north','center','middle','Fj R!',true,'black'],
 ['small-right-bottom','chalk',false,'north','right','bottom','Fj W.i!\nR 12',false,'red'],
 ['small-justify-wrap','chalk',false,'north','justify','top','Fj W.i! AB CD EF GH IJ',false,'white'],
 ['large-distributed-east','chalk',true,'east','distributed','top','Fj W.i!\nR 12',false,'white'],
 ['large-fallback-blank-lines','chalk',true,'north','center','top','F\u200c j\n\n\uE000\u{1F600}!',false,'white'],
 ['blank-boundary','chalk',false,'north','left','top',' \n\u200c',false,'white']
];
const results=[];
for(const [id,kind,large,facing,alignment,verticalAlignment,text,glowing,color] of defs){
 const info={kind,large,facing,rotation:0,root:{x:0,y:0,z:0}},data={text,alignment,verticalAlignment,glowing,color},entities=[];
 const d={id,getEntities:()=>[],spawnEntity(type,location,options){const e={location,options,props:{},dyn:{},setProperty(k,v){this.props[k.split(':')[1]]=v},setDynamicProperty(k,v){this.dyn[k]=v},addTag(){}};entities.push(e);return e}};
 renderBoardText(d,info,data,null,id);const options=boardLayoutOptions(kind,large),layout=splitBoardLines(text,options);
 results.push({id,info,data,options,layout,rows:layout.lines.map(l=>boardGlyphOffsets(l,alignment,options.width,options.bold)),verticalOffset:boardVerticalOffset(verticalAlignment,layout.lines.length,options.maxLines,kind==='sandwich'?10:12),entities});
}
fs.writeFileSync(new URL('./layouts.json',import.meta.url),JSON.stringify(results,null,2)+'\n');
console.log('Bounded pure mock captures:',results.length,'cases;',results.map(r=>r.entities.length).join(','),'glyph entities. No Minecraft executed.');
