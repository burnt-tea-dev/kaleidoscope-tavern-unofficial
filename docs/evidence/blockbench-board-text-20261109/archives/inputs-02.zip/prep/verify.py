from pathlib import Path
import json,base64,hashlib,io,math,gzip,re
from PIL import Image
import numpy as np
H=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());R=H/'inputs/current';sha=lambda b:hashlib.sha256(b).hexdigest();M=read(H/'manifest.json');layouts={x['id']:x for x in read(H/'layouts.json')};maxerr=0;count=0;hostcount=0;pngcount=0;poseerr=0
for p,v in M['inputs'].items():assert sha((H/p).read_bytes())==v['sha256']
for q in read(H/'capture-queue.json')['scenes']:
 d=read(H/q['file']);c=layouts[q['id']];info=c['info'];sand=info['kind']=='sandwich';yaw=math.radians((180 if sand or info['facing']=='north'else 270));t=math.radians(22.5 if sand else 0);scale=.01 if sand else .012
 host=read(H/('inputs/host/'+('sandwich-bodies-1'if sand else'chalkboard-'+info['facing'])+'.bbmodel'));he={e['uuid']:e for e in host['elements']}
 for texture in d['textures']:
  b=base64.b64decode(texture['source'].split(',')[1]);im=Image.open(io.BytesIO(b));assert(im.width,im.height)==(texture['uv_width'],texture['uv_height']);pngcount+=1
  if texture.get('_review_input','').startswith('inputs/current/runtime/RP/textures/board_font'):assert b==(H/texture['_review_input']).read_bytes()
  else:assert any(texture['source']==v['source']for v in host['textures'])
 for e in d['elements']:
  r=e['_review']
  if r['kind']=='native_geometry':
   old=he[e['uuid']];assert e['faces']==old['faces'];shift=np.array(r['N06_host_translation'])
   for k,v in e['vertices'].items():assert np.allclose(v,np.array(old['vertices'][k])+shift,rtol=0,atol=1e-12)
   hostcount+=1;continue
  en=c['entities'][r['entity_index']];props=en['props'];cp=props['char_0'];assert r['cell']==cp%256 and r['page']==cp//256
  geom=read(R/('runtime/RP/models/entity/board_glyph_'+r['geometry_kind']+'.geo.json'))['minecraft:geometry'][cp%256];bn=next(b for b in geom['bones']if b['name']==r['bone']);cube=bn['cubes'][r['cube']];o=cube['origin'];s=cube['size'];dx=dy=0
  if r['bone']=='bold':dx=-.5
  if r['bone'].startswith('outline_'):
   idx=int(r['bone'].split('_')[-1]);offsets=[(x,y)for x in [-1,0,1]for y in [-1,0,1]if(x,y)!=(0,0)];dx,dy=np.array(offsets[idx])*.5
   if 'bold'in r['bone']:dx-=.5
  location=json.loads(en['dyn']['kt:writingBoard/signature'])['location'];anchor=np.array([location['x']*16-8,location['y']*16,location['z']*16-8]);u=np.array([math.cos(yaw),0,math.sin(yaw)]);v=np.array([math.sin(yaw)*math.sin(t),math.cos(t),-math.cos(yaw)*math.sin(t)]);w=np.array([math.sin(yaw)*math.cos(t),-math.sin(t),-math.cos(yaw)*math.cos(t)])
  coords=[(o[0]+dx,o[1]+s[1]+dy,o[2]),(o[0]+dx,o[1]+dy,o[2]),(o[0]+s[0]+dx,o[1]+dy,o[2]),(o[0]+s[0]+dx,o[1]+s[1]+dy,o[2])]
  for k,(x,y,z)in enumerate(coords):maxerr=max(maxerr,float(np.max(abs(np.array(e['vertices'][str(k)])-(anchor+16*scale*(u*x+v*y+w*z))))));count+=1
  uv=cube['uv']['north'];a,b=uv['uv'];du,dv=uv['uv_size'];assert list(e['faces']['north']['uv'].values())==[[a,b],[a,b+dv],[a+du,b+dv],[a+du,b]]
 # Source Java pose pen: independent Rodrigues rotation about (-cos(yaw),0,-sin(yaw)); left/center/right positioning or intentional extension supplied offsets.
 axis=np.array([-math.cos(yaw),0,-math.sin(yaw)]);a,b,z=axis;K=np.array([[0,-z,b],[z,0,-a],[-b,a,0]]);rot=np.eye(3)*math.cos(t)+(1-math.cos(t))*np.outer(axis,axis)+math.sin(t)*K
 base=np.array([.5-math.sin(yaw)*.06,1.06,.5+math.cos(yaw)*.06])if sand else np.array([.5+math.sin(yaw)*.42,1.535,.5-math.cos(yaw)*.42])
 for en in c['entities']:
  row,index=map(int,en['dyn']['kt:writingBoard/anchor'].split('|')[-2:]);x=c['rows'][row][index];down=row*(10 if sand else 12)+c['verticalOffset']-19;expected=base+rot@(np.array([math.cos(yaw)*x,-down,math.sin(yaw)*x])*scale);actual=json.loads(en['dyn']['kt:writingBoard/signature'])['location'];poseerr=max(poseerr,float(np.max(abs(expected-np.array([actual[k]for k in ['x','y','z']])))))
assert maxerr<1e-10 and poseerr<1e-12
assert not layouts['blank-boundary']['entities'];fallback=layouts['large-fallback-blank-lines'];assert any(e['props']['char_0']==0x25a1 for e in fallback['entities']);assert any(e['props']['char_0']==0xe000 for e in fallback['entities']);assert all(e['props']['char_0']not in [32,0x200c]for e in fallback['entities'])
# Selected exact atlas cells, using authorized GNU Unifont source, no alternative raster font.
hexes=dict(line.split(':')for line in gzip.decompress((R/'art/fonts/unifont-15.0.06.hex.gz').read_bytes()).decode().splitlines());digits=re.search("FONT_ADVANCE_DIGITS='([^']+)'",(R/'runtime/BP/scripts/data/board-font.js').read_text()).group(1);atlas=[]
for cp in sorted({e['props']['char_0']for c in layouts.values()for e in c['entities']}):
 png=Image.open(R/f'runtime/RP/textures/board_font/glyph_{cp//256:02X}.png').getchannel('A');cell=png.crop(((cp%16)*16,((cp%256)//16)*16,(cp%16+1)*16,((cp%256)//16+1)*16));h=hexes.get(f'{cp:04X}')
 if cp==0xe000:assert digits[cp]=='6';atlas.append({'cp':cp,'private_use':'excluded by generator; actual fallback cell retained','cell_sha256':sha(cell.tobytes())});continue
 im=Image.frombytes('1',(len(h)//4,16),bytes.fromhex(h)).convert('L');box=im.getbbox();left,right=(box[0],box[2]-1)if box else(0,-1);expected=Image.new('L',(16,16));expected.paste(im.crop((left,0,right+1,16)),(0,0));assert cell.tobytes()==expected.tobytes();assert int(digits[cp])==(right-left+1)//2+1;atlas.append({'cp':cp,'exact_source_cell_and_advance':True})
report={'status':'PASS static saved-scene and selected route/atlas checks; NOT GUI/native acceptance','vertices_independently_reconstructed':count,'maximum_vertex_error_pixels':maxerr,'maximum_source_pose_pen_error_blocks':poseerr,'host_meshes_exact_except_presentation_translation':hostcount,'embedded_png_records_verified':pngcount,'selected_atlas_checks':atlas,'blank_and_fallback_boundaries':'PASS','input_hashes_verified':len(M['inputs']),'limits':['Java Font and Minecraft not executed','Atlas differs intentionally from Minecraft Font; no font parity claim','Colour/glow/depth/distance/scoping require engine behavior; neutral atlas scenes do not emulate them']}
(H/'independent-saved-scene-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['selected_atlas_checks','limits']}))
