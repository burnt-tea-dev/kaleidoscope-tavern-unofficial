from pathlib import Path
import subprocess,os,json,hashlib
H=Path(__file__).resolve().parent;W=H.parent;R=W/'tavern-plant-culling-repair-20261109';J=W/'tavern-visual-review-20261108/java-reference'
MAIN='7fb1afc86439d67703df202d04923d4bcdc4466b';F='c4ec1880bd44cf3139d3ba744ab30bb379cf1416';N='a1afba34981a00e89d57130d3dc8f1e64f1820a2'
ENV={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_CONFIG_COUNT':'1','GIT_CONFIG_KEY_0':'protocol.allow','GIT_CONFIG_VALUE_0':'never'}
def git(r,*args):return subprocess.check_output(['git','-C',str(r),*args],env=ENV)
sha=lambda b:hashlib.sha256(b).hexdigest()
M={'canonical_commit':MAIN,'runtime_tree':git(R,'rev-parse',MAIN+':runtime').decode().strip(),'source_pins':{'forge':F,'neoforge':N},'inputs':{},'gui_reviewed':False}
assert M['runtime_tree']=='a62a8655d96a71a9d1d6395b5fa8216ca298f197'
def put(path,b,owner,original):
 p=H/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);M['inputs'][path]={'sha256':sha(b),'owner':owner,'original_path':original}
def native(p):put('inputs/current/'+p,git(R,'show',MAIN+':'+p),MAIN,p)
for p in ['AGENTS.md','docs/BASELINE-MAINTENANCE.md','family/UPDATE-WORKFLOW.md','docs/PARITY-MATRIX.md','LICENSE-ASSETS','LICENSE-CODE','tools/build_board_font.py','tools/check_board_layout.mjs']+['art/fonts/'+f for f in ['README.md','README-Unifont.txt','COPYING-Unifont.txt','unifont-15.0.06.hex.gz']]+['runtime/BP/scripts/'+f for f in ['core/board-layout.js','core/boards.js','core/util.js','core/java-placement.js','data/board-font.js','bedrock/board-text.js']]+['runtime/RP/'+f for f in ['entity/board_glyph_visual.entity.json','render_controllers/board_glyph_visual.render_controllers.json','animations/board_glyph_line.animation.json','models/entity/board_glyph_line.geo.json','models/entity/board_glyph_outline.geo.json']]+['runtime/RP/textures/board_font/glyph_'+f+'.png' for f in ['00','25','E0']]:native(p)
for label,pin in [('forge',F),('neoforge',N)]:
 for p in ['LICENSE-ASSETS','LICENSE-CODE']+['src/main/java/com/github/ysbbbbbb/kaleidoscopetavern/client/render/block/'+f+'.java'for f in ['TextBlockEntityRender','ChalkboardBlockEntityRender','SandwichBlockEntityRender']]:put('inputs/'+label+'/'+p,git(J,'show',pin+':'+p),pin,p)
body=W/'tavern-board-body-review-20261109';B=json.loads((body/'manifest.json').read_text());n=0
for p,v in B['inputs'].items():
 if p.startswith('inputs/current/'):
  assert sha(git(R,'show',MAIN+':'+v['original_path']))==v['sha256'],p;n+=1
M['host_reuse']={'all_current_inputs_identical_to_N05':n,'manifest_sha256':sha((body/'manifest.json').read_bytes()),'frozen_artifact_manifest_sha256':sha((body/'artifact-sha256.json').read_bytes())}
for f in ['sandwich-bodies-1','chalkboard-north','chalkboard-east']:put('inputs/host/'+f+'.bbmodel',(body/'scenes'/ (f+'.bbmodel')).read_bytes(),'frozen N05 reuse','tavern-board-body-review-20261109/scenes/'+f+'.bbmodel')
p=W/'tavern-pressing-card-repair-20261109/docs/evidence/pressing-card-integration-20261109/upstream-freshness.json';put('inputs/reused-upstream-freshness.json',p.read_bytes(),'reused parent receipt; NOT this worker fetch',str(p.relative_to(W)))
(H/'manifest.json').write_text(json.dumps(M,indent=2)+'\n');(H/'inputs/current/package.json').write_text('{"type":"module"}\n')
print('Pinned inputs:',len(M['inputs']),'unchanged host inputs:',n)
