from pathlib import Path
import json,math,uuid,copy,base64,io,hashlib
import numpy as np
from PIL import Image
H=Path(__file__).resolve().parent;R=H/'inputs/current/runtime/RP';read=lambda p:json.loads(p.read_text());uid=lambda:str(uuid.uuid4())
def T(v):m=np.eye(4);m[:3,3]=v;return m
def Q(axis,a):
 m=np.eye(4);c=math.cos(math.radians(a));s=math.sin(math.radians(a));i,j={'x':(1,2),'y':(2,0)}[axis];m[i,i]=m[j,j]=c;m[i,j]=-s;m[j,i]=s;return m
G={kind:read(R/('models/entity/board_glyph_'+kind+'.geo.json'))['minecraft:geometry']for kind in ['line','outline']}
A=read(R/'animations/board_glyph_line.animation.json')['animations']['animation.kt_runtime.board_glyph_line']['bones'];queue=[]
for case in read(H/'layouts.json'):
 if not case['entities']:continue
 id=case['id'];info=case['info'];sand=info['kind']=='sandwich';large=info['large'];facing=info['facing'];host='sandwich-bodies-1'if sand else'chalkboard-'+facing;cid='base-rotation-0'if sand else('large'if large else'small')+'-chalk-'+facing
 old=read(H/('inputs/host/'+host+'.bbmodel'));elements=[copy.deepcopy(e)for e in old['elements']if e['_review']['kind']=='native_geometry'and e['_review']['case']==cid];off=np.array([24,0,0]if sand else[40,0,44 if large else 0]);textures=copy.deepcopy(old['textures'])
 # Extract exact CURRENT body, translating only presentation offset to local block-centre coordinates.
 for e in elements:
  for k,v in e['vertices'].items():e['vertices'][k]=(np.array(v)-off).tolist()
  e['_review']['N06_host_translation']=(-off).tolist()
 ids=[e['uuid']for e in elements];group={'uuid':uid(),'name':'CURRENT host (unaltered N05 surfaces)','origin':[0,0,0],'rotation':[0,0,0]};out=[{'uuid':group['uuid'],'children':ids}];groups=[group];tc={}
 for entity_index,en in enumerate(case['entities']):
  props=en['props'];cp=props['char_0'];page=cp//256;cell=cp%256
  if page not in tc:
   p=R/f'textures/board_font/glyph_{page:02X}.png';b=p.read_bytes();im=Image.open(io.BytesIO(b));tc[page]=len(textures);textures.append({'name':p.name+' EXACT PNG / tint not baked','id':str(len(textures)),'uuid':uid(),'width':im.width,'height':im.height,'uv_width':im.width,'uv_height':im.height,'source':'data:image/png;base64,'+base64.b64encode(b).decode(),'internal':True,'saved':True,'render_sides':'front','_review_input':str(p.relative_to(H))})
  grp={'uuid':uid(),'name':f'U+{cp:04X} glyph {entity_index} (native card, neutral atlas)','origin':[0,0,0],'rotation':[0,0,0]};groups.append(grp);child={'uuid':grp['uuid'],'children':[]};out.append(child)
  for kind in ['outline','line']if props['glowing']else['line']:
   g=G[kind][cell];bones={b['name']:b for b in g['bones']};cache={}
   def bone(name):
    if name in cache:return cache[name]
    b=bones[name];pos=np.zeros(3);rot=0
    if name=='anchor':pos=np.array([props['x_0'],props['x_1'],props['x_2']])*[-1,1,1]
    elif name=='ink':rot=-props['tilt']
    elif name=='bold'or name.startswith('outline_bold_'):pos[0]=props['bold_offset']
    elif name.startswith('outline_'):
     a=A[name]['position'];pos=np.array([float(a[i].split(' * ')[0])*props['bold_offset']if isinstance(a[i],str) else a[i]for i in range(3)])*[-1,1,1]
    cache[name]=(bone(b['parent'])if b.get('parent')else np.eye(4))@T(pos)@Q('x',rot);return cache[name]
   for bn in g['bones']:
    if ('bold'in bn['name'])and not props['bold']:continue
    for ci,cube in enumerate(bn.get('cubes',[])):
     o=cube['origin'];s=cube['size'];x=-o[0]-s[0];X=-o[0];y=o[1];Y=y+s[1];z=o[2];raw=[[X,Y,z],[X,y,z],[x,y,z],[x,Y,z]]
     mat=T([0,8,0])@Q('y',180-en['options']['initialRotation'])@np.diag([props['font_scale']]*3+[1])@bone(bn['name']);vertices={str(i):(mat@np.r_[p,1])[:3].tolist()for i,p in enumerate(raw)};uv=cube['uv']['north'];u,v=uv['uv'];du,dv=uv['uv_size'];uvs=[[u,v],[u,v+dv],[u+du,v+dv],[u+du,v]]
     e={'type':'mesh','uuid':uid(),'name':f'{kind} {bn["name"]} U+{cp:04X}','origin':[0,0,0],'rotation':[0,0,0],'vertices':vertices,'faces':{'north':{'vertices':list(vertices),'uv':dict(zip(vertices,uvs)),'texture':tc[page]}},'visibility':True,'shade':False,'_review':{'kind':'native_glyph_card','case':id,'entity_index':entity_index,'geometry_kind':kind,'cell':cell,'page':page,'bone':bn['name'],'cube':ci,'matrix':mat.tolist(),'neutral_atlas_only':True,'effective_rgb':[props[k]for k in ['red','green','blue']]}};elements.append(e);child['children'].append(e['uuid'])
 d={'meta':{'format_version':'5.0','model_format':'free','box_uv':False},'name':id+' | exact native atlas / no engine tint proof','resolution':{'width':256,'height':256},'elements':elements,'groups':groups,'outliner':out,'textures':textures};p=H/'scenes'/ (id+'.bbmodel');p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
 front=[0,28,-65]if facing=='north'else[-65,28,0]
 queue.append({'id':id,'file':str(p.relative_to(H)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'status':'prepared_not_captured','purpose':'Text orientation, spacing, wrapping and host-board offsets; original neutral white atlas, not tint acceptance','cameras':[{'label':'writing face close','position':front,'target':[0,23,0]},{'label':'raking depth / front face','position':[front[0]-18,34,front[2]-18],'target':[0,22,0]},{'label':'reverse culling control','position':[-front[0],25,-front[2]],'target':[0,22,0]}]})
(H/'capture-queue.json').write_text(json.dumps({'batch':'N06','actual_screenshots':0,'scenes':queue},indent=2)+'\n');print('Prepared',len(queue),'standalone scenes')
