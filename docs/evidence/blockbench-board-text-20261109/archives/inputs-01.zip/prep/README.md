# N06 board text: bounded static preparation

**Six standalone Blockbench scenes prepared; no GUI capture and no native text acceptance.** Seven bounded layout cases include a zero-visible-glyph blank control. This is text-on-host review, not another N05 body-only batch.

## Identity and provenance

Canonical `burnt-tea-dev/kaleidoscope-tavern-unofficial` main `7fb1afc86439d67703df202d04923d4bcdc4466b`, v0.6.215, runtime tree `a62a8655d96a71a9d1d6395b5fa8216ca298f197`. Forge `c4ec1880bd44cf3139d3ba744ab30bb379cf1416`; NeoForge `a1afba34981a00e89d57130d3dc8f1e64f1820a2`. Pinned local Git reads only, lazy fetch disabled and all Git protocols disabled. The parent’s pressing-card upstream freshness receipt is copied as **reused evidence, not this worker’s fetch**. No missing Git objects were encountered.

`manifest.json` records exact input SHA256, original paths and owners. Source and current LICENSE-ASSETS/LICENSE-CODE are copied verbatim. Font input includes the original GNU Unifont 15.0.06 hex archive, readme and license: the project distributes derived Tavern Board Font under SIL OFL 1.1; upstream also offers GPL with font embedding exception. Embedded PNG bytes are unchanged, not redrawn. Per-texture dimensions are their actual PNG dimensions.

All 270 N05 current input hashes match this runtime. Current host meshes are extracted from frozen N05 scenes and translated only to remove their paired-comparison presentation offsets. Source-body meshes are not duplicated. The frozen 863-file N05 artifact set is unchanged. The separate chalk-edge candidate is review-only and is not included: the current chalk bodies retain the documented N05 narrow-edge issues.

## Useful capture queue

`capture-queue.json` provides writing-face, raking depth and reverse-side camera positions/targets for:

- Sandwich left/top: asymmetric F/j/R-style features, mixed widths, space, punctuation and multiline; native bold layers and 22.5° tilt.
- Sandwich center/middle glowing-black structural outline: eight surrounding offsets and bold copies. **Neutral white atlas only**; toggle named outline meshes to inspect coverage. Cream/black contrast is not simulated.
- Small chalk right/bottom: multiline and vertical extension with short final row.
- Small chalk justified wrap: paragraph wrap and expanded word gaps, natural final line.
- Large chalk east/distributed: actual east-facing host, every character gap expansion and multiple rows.
- Large chalk fallback/blank lines: U+200C suppressed, spaces advance without cards, empty row preserved, private-use U+E000 fallback and supplementary emoji mapped to U+25A1.

The separate blank control (`space`, newline, U+200C) emits zero glyph helpers and needs no redundant body-only scene. The 512 shared glyph/outline cell geometries are two owners with indexed cells, not 512 jobs. No exhaustive glyph/RGB enumeration was made.

## What was checked

`layout.mjs` executes only pinned pure local layout/render code against an in-memory entity stub, not Minecraft. `layouts.json` preserves the input text, all resulting entity properties, line boundaries and offsets. No Java Font was executed. Independent Python checks reconstruct saved vertices from card coordinates and analytical world basis vectors rather than replaying the builder’s matrix chain. A separate Rodrigues source-pose calculation checks the Java translation, rotation, scale and legacy row offset against glyph pen locations; intentional justified/distributed and middle/bottom extensions remain enabled, not treated as defects.

`independent-saved-scene-checks.json`: 524 independently reconstructed glyph-card vertices, maximum error 3.56e-15 model pixels; source pose pen maximum error 3.34e-16 blocks. 36 current host meshes preserve exact N05 surfaces/UVs apart from presentation translation. All 36 embedded texture records have verified exact PNG bytes/dimensions. Selected Unifont glyph cells and metric advances match their licensed source archive exactly. Blank and fallback boundaries pass.

`routing-and-source-audit.json` independently resolves all page/cell indices, active geometry, original atlas, material, bold/outline visibility, animation and color/distance conditions. Forge and Neo Text/Sandwich renderer sources are identical. Chalk text pose is unchanged; body API and bounding-box differences are recorded, not claimed as new text differences.

## Findings and limits

**No font parity claim:** Java delegates splitting/width/raster rendering to Minecraft’s runtime Font. This port uses licensed Unifont atlas cards and Unifont-derived advances. The source Java font provider/resources were not part of these pinned Tavern inputs; editor evidence cannot establish matching Java glyph appearance or wrapping. Existing bounded layout tests were inspected as references, not reported as newly run full regressions.

**Source-backed unresolved adaptation (updated from independent scoping audit):** Java uses two different distances: C from the actual main camera position to the board block center, and E from the camera ENTITY position to that center. Text uses C≤48. Glowing outline uses C≤48 AND (black OR first-person active scoping OR camera entity exists with E<16). Native uses helper-root-to-camera distance D for both D≤48 and D<16; each helper is anchored at the board block center. It lacks the scoping override and does not reproduce Java's distinct E metric. “16–48 blocks” is only shorthand when the distances coincide. Exactly C=48 is included; exactly E=16 is excluded.

Official Player.setPropertyOverrideForEntity **does** support delivery of a known client-synced value per viewer. The blocker is not a blanket inability to carry per-viewer state: the bounded audit found no reliable supported observation of the viewer's actual first-person AND active scoping state in this helper/API context. Do not infer it from holding a spyglass, FOV, nearest player or this non-player helper's entity queries. No heuristic runtime repair was made or proposed.

The current authoritative q.is_first_person page marks the query deprecated and always 0. Its suggested variable does not establish a board-helper viewing-state contract. The exact declared @minecraft/server 2.7.0 archive could not be retrieved; newer 2.11.0 live documentation is not a substitute for target-version declarations. These are bounded documentation findings, not a claim that future APIs cannot support the feature or that all historical engine builds changed identically.

Full reused reasoning, exact predicates, official documentation links and prospective engine checks are in `inputs/scope-audit/README.md` and `documentation-evidence.md`. `predicate-truth-table.json` is an analytical Boolean table, **not** a Java/Molang/client test. `scope-audit-integration-receipt.json` pins this reused audit. No new GUI, runtime or native acceptance accompanies the metadata update.

**Package/dependency provenance:** `inputs/current/package.json` is a locally authored `type:module` fixture stub only. It is explicitly classified separately in `manifest.json`, never as canonical package or version/dependency evidence. Actual pinned Git bytes are under `inputs/canonical/package.json`, `runtime/BP/manifest.json`, and `runtime/RP/manifest.json`: package 0.6.215, minimum engine 1.26.50, @minecraft/server 2.7.0, @minecraft/server-ui 2.0.0. The integration verified these bytes against the independent audit snapshot hashes.

Native non-glowing foreground is floor(channel×0.6), glowing foreground uses full RGB, and outline is cream for black or darkened RGB otherwise. These effective facts are recorded, but original white PNG editor previews do **not** claim tint, emissive brightness, lighting, alpha sorting, polygon offset, face culling, distance cutoff, camera/entity distance equivalence or spyglass behavior. Raking cameras can inspect card placement but not native depth semantics. Engine controller selection and entity lifecycle also remain outside editor proof.

No GUI, user computer, Minecraft, BDS, LIVE, installation, remote write, runtime edit or release was performed. Accepted held transforms including tilted-rack +6 lift are untouched. Known Allium held clipping remains unresolved. No screenshot is fabricated or claimed.

## Reproduction

Original single-process bounded scene-preparation commands in order: `python prepare.py`, `node layout.mjs`, `python build_scenes.py`, `python verify.py`, `python audit_routes.py`. They write only this preparation directory. The input snapshot scripts are local tooling, not retrieved author executables; no general test suite is invoked. Scene imports should remain single-owner while N05 GUI work is active.

The later `integrate_scope_audit.py` pass updates only provenance and reused audit inputs. Do not rerun scene generation for this documentation update. Its receipt preserves the prior scene hashes; the final artifact manifest freezes all current deliverables.
