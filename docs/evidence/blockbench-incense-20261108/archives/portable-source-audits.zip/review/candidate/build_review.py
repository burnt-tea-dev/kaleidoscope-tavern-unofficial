"""Self-contained source/current/candidate incense previews. No application use."""
from pathlib import Path
import base64, copy, hashlib, io, json, subprocess, sys
from PIL import Image
import review_codec as C

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'tavern-incense-underside-repair-20261108'
OLD_REVIEW = HERE.parent / 'tavern-next-decor-review-20261108'
JAVA = HERE.parent / 'tavern-visual-review-20261108/java-reference'
BASE = '83ad03f3a19b937da057df1377e816438a4c0957'
KINDS = ('butterfly', 'catnip', 'firefly', 'ginkgo', 'pine', 'sakura', 'snow', 'spore')
read = C.read
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git', '-C', str(REPO), *args])
INPUTS = HERE / 'inputs'
SCENES = HERE / 'scenes'; SCENES.mkdir(exist_ok=True)
stored = '--stored-inputs' in sys.argv
cached = read(HERE/'manifest.json') if stored else {}
manifest = {'base_commit': BASE, 'candidate_commit': cached['candidate_commit'] if stored else git('rev-parse', 'HEAD').decode().strip(), 'candidate_runtime_tree': cached['candidate_runtime_tree'] if stored else git('rev-parse', 'HEAD:runtime').decode().strip(), 'inputs': {}, 'cases': [], 'scenes': [], 'source_pins': {'Forge': 'c4ec1880bd44cf3139d3ba744ab30bb379cf1416', 'NeoForge': 'a1afba34981a00e89d57130d3dc8f1e64f1820a2'}, 'gui_reviewed': False, 'client': False, 'bds': False}
prior = None if stored else read(OLD_REVIEW/'manifest.json')


def save_input(name, data):
    path = INPUTS/name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
    manifest['inputs'][str(path.relative_to(HERE))] = {'sha256': sha(path), 'bytes': len(data)}
    return path


def verify_prior(path):
    assert sha(path) == prior['inputs'][str(path)]['sha256']


if stored:
    for name, record in cached['inputs'].items():
        path = HERE/name
        assert path.resolve().is_relative_to(INPUTS.resolve())
        assert sha(path) == record['sha256'] and path.stat().st_size == record['bytes']
    manifest['inputs'] = cached['inputs']
    for key in ('candidate_source_tree', 'BP_tree', 'RP_tree'):
        if key in cached:
            manifest[key] = cached[key]
else:
    # Exactly the two missing down faces may differ in exported runtime.
    changed = git('diff', '--name-only', BASE, '--', 'runtime').decode().splitlines()
    assert changed == [f'runtime/RP/models/entity/incense_{s}.geo.json' for s in ('closed', 'open')]
    for state in ('closed', 'open'):
        name = f'runtime/RP/models/entity/incense_{state}.geo.json'
        original = git('show', BASE+':'+name)
        candidate = (REPO/name).read_bytes()
        current_json, candidate_json = json.loads(original), json.loads(candidate)
        candidate_minus_face = copy.deepcopy(candidate_json)
        del candidate_minus_face['minecraft:geometry'][0]['bones'][0]['cubes'][3]['uv']['down']
        assert candidate_minus_face == current_json
        save_input(f'current/incense_{state}.geo.json', original)
        save_input(f'candidate/incense_{state}.geo.json', candidate)
    for kind in KINDS:
        name = f'runtime/BP/blocks/{kind}_incense.json'
        data = (REPO/name).read_bytes(); assert data == git('show', BASE+':'+name)
        save_input(f'blocks/{kind}_incense.json', data)
        source_texture = JAVA/f'src/main/resources/assets/kaleidoscope_tavern/textures/block/deco/incense/{kind}_incense.png'
        verify_prior(source_texture)
        native_texture = REPO/f'runtime/RP/textures/kaleidoscope_tavern/block/deco/incense/{kind}_incense.png'
        assert source_texture.read_bytes() == native_texture.read_bytes()
        save_input(f'textures/{kind}_incense.png', native_texture.read_bytes())
        for state, folder in (('closed', 'incense'), ('open', 'incense_open')):
            source = JAVA/f'src/main/resources/assets/kaleidoscope_tavern/models/block/deco/{folder}/{kind}_incense.json'
            verify_prior(source)
            save_input(f'java/{kind}_{state}.json', source.read_bytes())


def add_triplet(scene, kind, state, row, spacing=14):
    z = row
    offsets = {'source': [-spacing, 0, z], 'current': [0, 0, z], 'candidate': [spacing, 0, z]}
    texture = INPUTS/f'textures/{kind}_incense.png'
    block = read(INPUTS/f'blocks/{kind}_incense.json')['minecraft:block']
    context = copy.deepcopy(block['components'])
    if state == 'open':
        context.update(block['permutations'][0]['components'])
    materials = context['minecraft:material_instances']
    ranges = {}
    for variant, offset in offsets.items():
        start = len(scene.j['elements'])
        if variant == 'source':
            scene.java(INPUTS/f'java/{kind}_{state}.json', texture, offset)
            scene.j['groups'][-1]['name'] = f'SOURCE X={offset[0]}, Z={z} | {kind} {state}'
        else:
            path = INPUTS/f'{variant}/incense_{state}.geo.json'
            scene.bedrock(path, texture, offset, name=f'{variant.upper()} X={offset[0]}, Z={z} | {kind} {state}')
            geometry = read(path)['minecraft:geometry'][0]
            assert len(geometry['bones']) == 1 and geometry['bones'][0].get('rotation', [0, 0, 0]) == [0, 0, 0]
            for element, cube in zip(scene.j['elements'][start:], geometry['bones'][0]['cubes']):
                shades = {materials[f.get('material_instance', '*')].get('face_dimming', True) for f in cube['uv'].values()}
                assert len(shades) == 1
                element['shade'] = shades.pop()
        ranges[variant] = [start, len(scene.j['elements'])]
    source, current, candidate = [scene.j['elements'][a:b] for a,b in ranges.values()]
    # Prove preview content differs only at the intended restored face, after
    # translation. Source has harmless degenerate foliage edge entries.
    def normalized(element, offset):
        result = {k: copy.deepcopy(element[k]) for k in ('from', 'to', 'rotation', 'shade', 'faces')}
        for key in ('from', 'to'):
            result[key] = [round(v-offset[i], 6) for i,v in enumerate(result[key])]
        if any(element['rotation']):
            result['origin'] = [round(v-offset[i], 6) for i,v in enumerate(element['origin'])]
        for side in list(result['faces']):
            f = result['faces'][side]
            axis = {'east':0,'west':0,'up':1,'down':1,'north':2,'south':2}[side]
            if f['texture'] is None or any(abs(element['to'][i]-element['from'][i]) < 1e-8 for i in range(3) if i != axis):
                del result['faces'][side]
            else:
                f.pop('texture')
        return result
    source_n, current_n, candidate_n = [[normalized(e, offsets[v]) for e in rows] for v, rows in [('source',source),('current',current),('candidate',candidate)]]
    assert source_n == candidate_n, (kind, state, 'Candidate preview must equal source nondegenerate faces')
    without_down = copy.deepcopy(candidate_n); del without_down[3]['faces']['down']
    assert without_down == current_n
    return {'kind':kind,'state':state,'offsets':offsets,'element_ranges':ranges,'source_candidate_nondegenerate_equal':True,'current_missing_only':'element 3 down','texture_sha256':sha(texture)}


def save_scene(name, rows):
    scene = C.Scene(name)
    cases = []
    for i,(kind,state) in enumerate(rows):
        cases.append(add_triplet(scene, kind, state, (i-(len(rows)-1)/2)*24))
    for t in scene.j['textures']:
        im = Image.open(io.BytesIO(base64.b64decode(t['source'].split(',',1)[1])))
        assert im.size == (t['width'], t['height']) == (32,32)
        assert t['render_sides'] == 'front'
    ids = [e['uuid'] for e in scene.j['elements']] + [g['uuid'] for g in scene.j['groups']]
    assert len(ids) == len(set(ids))
    def leaves(node):
        return [node] if isinstance(node,str) else sum((leaves(c) for c in node['children']),[])
    assert set(sum((leaves(n) for n in scene.j['outliner']),[])) == {e['uuid'] for e in scene.j['elements']}
    path = SCENES/(name+'.bbmodel'); path.write_text(json.dumps(scene.j,indent=2)+'\n')
    manifest['scenes'].append({'file':str(path.relative_to(HERE)),'sha256':sha(path),'elements':len(scene.j['elements']),'textures':len(scene.j['textures'])})
    for case in cases:
        case['scene'] = str(path.relative_to(HERE)); manifest['cases'].append(case)


save_scene('catnip-closed-source-current-candidate', [('catnip','closed')])
save_scene('catnip-open-source-current-candidate', [('catnip','open')])
rows = [(kind,state) for kind in KINDS for state in ('closed','open')]
for i in range(4):
    save_scene('incense-all16-triplets-'+str(i+1), rows[i*4:i*4+4])
manifest['summary'] = {'unique_states':16,'representative_repeats':2,'scenes':6,'source_current_candidate':True,'all_textures_identical_bytes':True,'native_runtime_delta':'exactly two cube3/down UV entries; open shade remains unshaded'}
manifest['view'] = 'Use BOTTOM and low underside perspective. World source X=-14, current X=0, candidate X=+14; on BOTTOM +X gizmo right this means source/current/candidate left to right. Default perspective reverses the screen order. Never infer world identity from screen side alone.'
(HERE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['summary']))
