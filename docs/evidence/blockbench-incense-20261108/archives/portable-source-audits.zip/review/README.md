# Tavern incense underside: portable visual evidence

**2026-11-08. The 13 repaired-candidate Blockbench captures cover six scenes and all 16 incense type/state combinations. All original JPEGs were inspected individually. The candidate restores the visible source underside pattern; old current still differs. This is bounded editor/static evidence, not Minecraft-engine or release acceptance.**

## Contents

- `candidate/evidence/`: all 13 original candidate JPEGs, unchanged.
- `candidate/scenes/`: the exact six self-contained scene files used for those captures.
- `baseline/evidence/` and `baseline/scenes/`: 11 original source/current captures and their five exact scenes, retained as failure evidence.
- `candidate/inputs/`: two current and two candidate geometry files, 16 authored models, eight block bindings and eight original PNGs. Textures are also embedded in every scene.
- `image-index.md` and `.json`: per-image captions, camera order, scene/hash associations, framing review and limitations.
- `audits/`: bounded consumer, source, fill-face and codec provenance. No full application archive, extracted application source, JAR, unrelated addon data or private investigation report is bundled.
- `archives/candidate-scenes.zip`: exactly six unchanged `.bbmodel` entries. `archives/scene-zip-entries.json` records each entry's size and SHA256. A separate baseline scene archive contains the five old scenes.
- `inventory.json` and `SHA256SUMS`: file identities. `archives/evidence-bundle.zip` is the complete portable payload; its outer hash is in `archives/bundle-sha256.json`.

Open a `.bbmodel` directly in Blockbench. No plugin, service, texture-path repair or Minecraft installation is needed. The capture environment was reported as official Blockbench 5.2.2, window 29360132, without plugins, server or security bypass. Packaging itself opened no GUI and changed no runtime or author worktree file.

## Read the camera correctly

Candidate scenes place source at world X=-14, old current at X=0 and repaired candidate at X=+14. Catnip representative scenes use Z=0. In captured **BOTTOM** views, the +X gizmo points right: **source left / current middle / candidate right**. The default perspective reverses that projected order within each triplet: **candidate left / current middle / source right**. Group names and world coordinates are authoritative. Do not carry a screen-side caption to another camera.

The four candidate sheets use rows at Z=-36,-12,+12,+36 in creation order. BOTTOM shows those rows in reverse order, top to bottom:

1. Sheet 1: Catnip open, Catnip closed, Butterfly open, Butterfly closed.
2. Sheet 2: Ginkgo open, Ginkgo closed, Firefly open, Firefly closed.
3. Sheet 3: Sakura open, Sakura closed, Pine open, Pine closed.
4. Sheet 4: Spore open, Spore closed, Snow open, Snow closed.

Every BOTTOM row contains the source/current/candidate triplet. Every sheet is also captured in default perspective. Catnip closed and open have separate enlarged BOTTOM and perspective captures. Catnip closed has one additional shallow orbit from BOTTOM. That orbit is **not a measured or exact-angle view**.

Historical baseline sheets use a different two-row/two-pair layout, not the candidate four-row triplet layout. In baseline BOTTOM images the second named type is the top row, first type the bottom row; each row has closed pair then open pair from left to right. Each pair is source left/current right. Baseline perspective reverses each pair. The baseline Catnip close scene uses source X=-7/current X=+7.

## What the actual images show

All 13 candidate JPEGs are uncropped 1364×1024 captures. All four BOTTOM rows and all three columns fit fully within the viewport with margin. Source and candidate centre patterns agree across Butterfly, Catnip, Firefly, Ginkgo, Pine, Sakura, Snow and Spore, closed and open. Current shows the different lid pattern through the missing fill underside. Catnip close-ups make the purple source/candidate versus brown current difference particularly clear. The tilted view supports the observed underside colour difference. A small green mark is visible near the current model; origin was not diagnosed, and it is not used as defect evidence.

All 12 models on each candidate perspective sheet are present and within the viewport; all complete Catnip close-up models are also framed. No new source/candidate mismatch was observed in the visible tops, foliage or base outlines. The sheets are **overview evidence**: small projected size and some foliage overlap limit fine-detail and all-face inspection. BOTTOM footprints on the sheets are about 48 pixels wide. They are adequate for the missing-bottom pattern difference, not a pixel-perfect UV verdict. Close-ups are larger. BOTTOM hides upper geometry, while default perspective naturally hides underside. No dedicated TOP capture or measured-angle camera calibration is claimed.

All 11 baseline JPEGs were inspected too. Their eight-model sheets and Catnip pair are fully within the viewport. They document the same original source/current difference and must not be mislabeled as repaired-candidate acceptance. No JPEG was edited, re-encoded, recreated, annotated or generated for this package.

## Exact identity and source scope

The candidate scene snapshot is commit **df2559ef4ac9984d89d2dc4f01cfb60d1e7b7be7**, runtime tree **fbde705a2a6042201eba7b06f1c22192f05448a6**. The candidate's old-current base is **83ad03f3a19b937da057df1377e816438a4c0957**, version 0.6.212. The earlier baseline scene manifest recorded runtime pin 4700ede2/tree e269f993ad73f091e49866e31df4929817505480; its relevant incense geometry, block and texture input bytes are checked against the included current snapshot rather than assuming entire runtime trees equal.

Only cube 3's missing down UV entry changes in each of the two shared models. Candidate closed SHA256 is `47bf58ff0226a56c60cfd220a7f61119a0ff87b4983f31914ef5b1f71de9fb07`; open is `d79d4c47bf08d7444c2619ac00763a70ce009720bd9e885f323e9d9575f338e7`. The original fill shade/material, remaining model geometry, all eight PNGs and block bindings stay unchanged. Source model geometry is compared after explicit Java/Bedrock coordinate and UV conversion. Original zero-area foliage edge entries are not visible native faces.

Forge and NeoForge author pins and 24 bounded asset receipts are in `audits/source-receipts.json`. Eight bounded source-code files support the ownership summary. The supplied JAR identity is kaleidoscopetavern-1.2.0-neoforge+mc1.21.1.jar, SHA256 `03f35e1e614953b22cd1f5e34345613f3a6a283bf1b1c99659b57d58970edeff`. The original record says publisher checksum not verified; the JAR was not executed and is not included.

Original candidate manifests and concise audits preserve their original bytes and historical fields, including `gui_reviewed: false`. That describes builder-time status. `review-status.json` and the image index separately record the later actual JPEG inspection; historical records are not rewritten to manufacture GUI acceptance.

## Reproduce safely

Use Python 3.12 with Pillow (the recorded run used Pillow 13.0.0). From any directory run:

```sh
python /path/to/extracted-bundle/verify_bundle.py
```

This checks inventory hashes, all 24 JPEG identities/dimensions, all 11 scene identities and embedded PNGs, both scene ZIPs, bounded author/source inputs, exact two-face geometry change and baseline input compatibility. It copies only `candidate/` to a temporary directory and invokes the unchanged `build_review.py --stored-inputs` there. No Git checkout, network, GUI, application source, runtime export or installation is needed. Rebuilt scenes are compared semantically to the captured originals after rebasing UUID identifiers; the original scenes are never overwritten. New UUIDs mean regenerated scene byte hashes differ even when content is identical. Do not replace captured scenes with regenerated files.

The original builder's default mode expects development checkout locations. Use only its `--stored-inputs` mode in a disposable copy, or use the verifier above. A builder rerun proves bounded input/model consistency, not that screenshots were freshly captured or that the Bedrock engine matches the editor. Stored independent 256-ray and 576-ray findings are attributed in the source-owner summary; this verifier does not claim to rerun those independent algorithms.

## Pending and excluded acceptance

At the captured candidate snapshot the actual two-face runtime repair passed independent static review, but effective-open lifecycle override checks and root bone_visibility regression tests had gaps and were being refined separately. **This package does not claim final contract or release PASS.** Later tools-only commits may reuse these exact visual inputs only after their hashes are checked. A release with changed exported runtime still needs its paired version/freeze/CI/package workflow.

Editor preview, source/resource equality, runtime regression, native client rendering, BDS startup, gameplay, item use/held poses, animation and particles, release validation, deployment and saved-world acceptance are distinct. This evidence does not establish Minecraft lighting, filtering, shaders, culling/transparency or behavior, nor all-surface acceptance from two cameras. No client, BDS, release, publication, deployment or saved-world test was performed by this packaging task. It covers incense only, not the completion of all addon ports.

## Credits and licensing

Original code/artwork: Kaleidoscope Official Production Team / YSBB, [Kaleidoscope Tavern](https://github.com/KaleidoscopeMods/KaleidoscopeTavern). Bedrock adaptation: casama233 and contributors, [unofficial port](https://github.com/casama233/kaleidoscope-tavern-unofficial).

Code uses BSD-3-Clause (`LICENSE-CODE`); original artwork and derivatives use CC BY-NC-SA 4.0 (`LICENSE-ASSETS`, [license](https://creativecommons.org/licenses/by-nc-sa/4.0/)). Previews rearrange and decode geometry/UV conventions without repainting textures. The candidate restores the two source underside faces described above. Preserve attribution, noncommercial and share-alike terms when sharing. This package implies no author, Mojang or Microsoft endorsement.
