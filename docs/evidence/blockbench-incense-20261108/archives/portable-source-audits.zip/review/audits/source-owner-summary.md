# Source contract and repair ownership

This is a bounded evidence summary, not a release or engine-acceptance report.

## Author inputs

Forge source is pinned to c4ec1880bd44cf3139d3ba744ab30bb379cf1416 and NeoForge to a1afba34981a00e89d57130d3dc8f1e64f1820a2. `source-receipts.json` retains checks for exactly 16 source models and eight PNGs, including the distinction between worktree bytes and Git bytes. JSON model differences from Git are line-ending normalization, not changed parsed elements. All eight PNGs have identical original bytes. The source archive identity is recorded, but its publisher checksum was not verified; the JAR was not executed and is not included.

`author-contract/inputs.json` hashes eight bounded author source files. The Forge and NeoForge IncenseBlock classes use noOcclusion(), do not implement a general support-underneath requirement, and their neighbor change behavior concerns redstone. The included renderer setup files do not register an alternate incense renderer. All 16 source model fill elements retain a down face without a cullface directive; `fill-face-contract.json` records it directly from the included models. A solid floor can hide an underside for one placement, but these source contracts do not justify universally deleting it.

## Concrete repair

The original base texture has a transparent central opening. Removing fill cube 3's down face therefore exposes the lid behind it when seen from below. The candidate restores only that down UV entry in `incense_closed.geo.json` and `incense_open.geo.json`; the open face's unshaded material is retained. The copied consumer audit records eight placed closed routes, eight placed open routes and eight closed item-visual routes to the same two geometry owners. There are no separate pot entity or attachable geometry references in that audit.

The original static checker receipt records 256 central first-visible underside rays. A separate independent audit at candidate df2559ef4ac9984d89d2dc4f01cfb60d1e7b7be7 reported 576 source/candidate first-hit matches across full footprints: old current differs in 256 central depths and 254 RGBA samples. Those are attributed saved audit findings, not a claim that this portable packaging run repeated that independent algorithm. The supplied builder can reproduce nondegenerate geometry, UV, rotation, shade and texture equality from the bounded inputs, and proves current differs only at the restored down face.

## Contract and release boundary

The independent review accepted the actual two-face runtime change but identified gaps in effective-open lifecycle override checks and root bone_visibility tests. The actual candidate contained none of the injected negative-test defects. Those contract checks were being refined separately. This snapshot does not certify their final result, a release gate, a version freeze, publication, deployment, BDS, Minecraft rendering or saved-world behavior. Version 0.6.212 is the unchanged frozen baseline, not an installable release of this candidate.

The exact scene inputs remain valid for a later tools-only revision only if the included model, block and texture hashes still match. A changed source commit name alone must not be substituted for that byte check.
