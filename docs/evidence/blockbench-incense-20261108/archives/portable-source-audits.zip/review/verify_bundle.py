"""Offline, read-only verification of the portable incense visual evidence.

Only temporary files are generated. The captured scene/JPEG bytes are never
rewritten. This verifies evidence identity and bounded preview reconstruction,
not Minecraft rendering, gameplay, release gates or independent ray audits.
"""
from pathlib import Path
import argparse
import base64
import copy
import hashlib
import io
import json
import platform
import shutil
import subprocess
import sys
import tempfile
import zipfile
import PIL
from PIL import Image

ROOT = Path(__file__).resolve().parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text())


def inside(relative):
    path = ROOT / relative
    assert path.resolve().is_relative_to(ROOT), relative
    return path


def normalized_scene(scene):
    """Rebase UUID references without changing any substantive scene value."""
    ids = {}
    for kind in ('elements', 'groups', 'textures'):
        for n, item in enumerate(scene[kind]):
            ids[item['uuid']] = f'{kind}/{n}'

    def visit(value):
        if isinstance(value, dict):
            return {k: visit(v) for k, v in value.items()}
        if isinstance(value, list):
            return [visit(v) for v in value]
        return ids.get(value, value) if isinstance(value, str) else value

    return visit(scene)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-inventory', action='store_true',
                        help='Packaging-only: verify payload before final inventory exists.')
    args = parser.parse_args()
    result = {'python': platform.python_version(), 'Pillow': PIL.__version__}
    if not args.skip_inventory:
        inv = read(ROOT / 'inventory.json')
        for rec in inv['files']:
            p = inside(rec['file'])
            assert p.stat().st_size == rec['bytes'] and sha(p) == rec['sha256'], rec['file']
        for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
            digest, name = line.split('  ', 1)
            assert sha(inside(name)) == digest, name
        result['inventory_files_verified'] = len(inv['files'])

    cm = read(ROOT / 'candidate/manifest.json')
    for name, rec in cm['inputs'].items():
        p = inside('candidate/' + name)
        assert p.stat().st_size == rec['bytes'] and sha(p) == rec['sha256'], name
    result['candidate_inputs_verified'] = len(cm['inputs'])
    for rec in read(ROOT / 'provenance.json')['exact_copies']:
        p = inside(rec['file'])
        assert p.stat().st_size == rec['bytes'] and sha(p) == rec['sha256'], rec['file']

    for state in ('closed', 'open'):
        current = read(ROOT / f'candidate/inputs/current/incense_{state}.geo.json')
        candidate = read(ROOT / f'candidate/inputs/candidate/incense_{state}.geo.json')
        face = candidate['minecraft:geometry'][0]['bones'][0]['cubes'][3]['uv']['down']
        assert face['uv'] == [20.0, 16.0] and face['uv_size'] == [-4.0, -4.0], face
        if state == 'open':
            assert face['material_instance'] == 'unshaded'
        reduced = copy.deepcopy(candidate)
        del reduced['minecraft:geometry'][0]['bones'][0]['cubes'][3]['uv']['down']
        assert reduced == current, state
    result['geometry_delta'] = 'Exactly cube 3/down in both shared models; open unshaded retained.'

    source = read(ROOT / 'audits/source-receipts.json')
    assert len(source['inputs']) == 24
    for rec in source['inputs']:
        assert sha(inside(rec['included_file'])) == rec['worktree_sha256'], rec['included_file']
    for rec in read(ROOT / 'audits/author-contract/inputs.json'):
        assert sha(inside('audits/' + rec['local'])) == rec['sha256'], rec['local']
    for rec in read(ROOT / 'audits/fill-face-contract.json'):
        p = inside(rec['file'])
        assert sha(p) == rec['sha256']
        d = read(p)
        e = d['elements'][3]
        assert e['faces']['down'] == rec['down'] and 'cullface' not in rec['down']
        assert e['from'] == rec['from'] and e['to'] == rec['to']
    for rec in read(ROOT / 'audits/baseline-input-compatibility.json'):
        assert sha(inside(rec['file'])) == rec['sha256'] == rec['baseline_manifest_input_sha256']
    result['source_asset_receipts_verified'] = 24
    result['author_code_inputs_verified'] = 8

    scene_records = [{'file': 'candidate/' + r['file'], **{k: v for k, v in r.items() if k != 'file'}}
                     for r in cm['scenes']]
    scene_records += read(ROOT / 'baseline/scene-manifest.json')['scenes']
    expected_pngs = {sha(p) for p in (ROOT / 'candidate/inputs/textures').glob('*.png')}
    embedded = 0
    for rec in scene_records:
        p = inside(rec['file'])
        assert sha(p) == rec['sha256'], rec['file']
        d = read(p)
        assert len(d['elements']) == rec['elements'] and len(d['textures']) == rec['textures']
        for texture in d['textures']:
            assert texture['source'].startswith('data:image/png;base64,')
            raw = base64.b64decode(texture['source'].split(',', 1)[1], validate=True)
            assert hashlib.sha256(raw).hexdigest() in expected_pngs, texture['name']
            with Image.open(io.BytesIO(raw)) as im:
                assert im.format == 'PNG' and im.size == (32, 32)
                assert im.size == (texture['width'], texture['height'])
            assert texture['render_sides'] == 'front'
            embedded += 1
    assert len(scene_records) == 11
    result['exact_scene_files_verified'] = 11
    result['embedded_png_entries_verified'] = embedded

    image_records = read(ROOT / 'image-index.json')
    assert len(image_records) == 24
    for rec in image_records:
        p = inside(rec['file'])
        assert sha(p) == rec['sha256'] and p.stat().st_size == rec['bytes'], rec['file']
        assert sha(inside(rec['scene'])) == rec['scene_sha256'], rec['scene']
        with Image.open(p) as im:
            assert im.format == 'JPEG' and list(im.size) == rec['dimensions'] == [1364, 1024]
            im.verify()
    result['raw_jpeg_files_verified'] = 24
    result['jpeg_visual_inspection'] = 'Recorded manual pixel inspection; this script does not replace visual review.'

    zip_entries = read(ROOT / 'archives/scene-zip-entries.json')
    for archive in sorted({r['archive'] for r in zip_entries}):
        entries = [r for r in zip_entries if r['archive'] == archive]
        with zipfile.ZipFile(inside(archive)) as z:
            assert z.testzip() is None
            assert sorted(z.namelist()) == sorted(r['entry'] for r in entries)
            for rec in entries:
                raw = z.read(rec['entry'])
                assert len(raw) == rec['bytes'] and hashlib.sha256(raw).hexdigest() == rec['sha256']
                assert raw == inside(rec['source_file']).read_bytes()
    result['scene_zip_entries_verified'] = len(zip_entries)

    with tempfile.TemporaryDirectory(prefix='incense-evidence-verify-') as td:
        temp = Path(td) / 'candidate'
        shutil.copytree(ROOT / 'candidate', temp)
        proc = subprocess.run([sys.executable, str(temp / 'build_review.py'), '--stored-inputs'],
                              cwd=temp, text=True, capture_output=True, check=True)
        summary = json.loads(proc.stdout)
        assert summary['unique_states'] == 16 and summary['scenes'] == 6
        rebuilt = read(temp / 'manifest.json')
        assert rebuilt['inputs'] == cm['inputs'] and rebuilt['cases'] == cm['cases']
        for rec in cm['scenes']:
            original = read(ROOT / 'candidate' / rec['file'])
            fresh = read(temp / rec['file'])
            assert normalized_scene(original) == normalized_scene(fresh), rec['file']
            assert sha(ROOT / 'candidate' / rec['file']) == rec['sha256']
    result['stored_input_rebuild'] = 'PASS: 6 scenes, 16 unique states; all scene data equal after UUID rebasing.'
    result['captured_scene_bytes_unchanged'] = True
    result['minecraft_or_release_acceptance'] = False
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
