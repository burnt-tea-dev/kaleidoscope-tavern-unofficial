# Stools: recorded GUI views reviewed

All five stool scenes were reviewed in native Blockbench default perspective and TOP, with ten original JPEGs retained under `evidence/`. The ten files were also individually inspected for framing and captions. All four pairs fit within each viewport; titles and state order match. No new visible seat/backrest silhouette or texture mismatch, viewport-edge clipping or caption problem was found.

Default perspective: native left/source right within each pair. TOP: source left/native right. Some rear bases are naturally occluded in perspective; TOP hides bases beneath seats. This is not every-surface, gameplay or Minecraft-engine acceptance. Body turns 0°, 45°, 90° and 180° are static samples, with fixed bases preserved.

`gui-review.json` gives the per-image observations, original JPEG SHA256 values and matching unchanged scene hashes. `evidence/README.md` is the image index. Scene, texture, UUID, hierarchy and transform bytes were not changed. Earlier `manifest.json` and `validation.json` retain their original GUI-pending fields as historical numerical evidence; the new GUI record is separate.

Bottle GUI review is still pending and is not part of this stool evidence ZIP. Code/art licensing: BSD-3-Clause and CC BY-NC-SA 4.0 respectively; retain `LICENSE-CODE`, `LICENSE-ASSETS` and the attribution below.

Original code/art: Kaleidoscope Official Production Team / YSBB, https://github.com/KaleidoscopeMods/KaleidoscopeTavern . Bedrock adaptation: casama233 and port contributors, https://github.com/casama233/kaleidoscope-tavern-unofficial . The review rearranges imported geometry without redrawing source textures. No author/Mojang/Microsoft endorsement is implied.
