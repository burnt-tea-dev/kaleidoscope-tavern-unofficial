# Stool screenshot index

**Completed bounded editor review:** all five scenes, default perspective and TOP. All ten original JPEGs were individually inspected. No viewport-edge clipping, wrong scene title, inconsistent colour/turn indexing or new visible mismatch was found.

Default perspective: native left/source right within each pair. TOP: source left/native right. These are camera-specific captions. Some rear bases are naturally occluded; no all-surface or engine-parity claim is made.

The raw JPEG bytes are unchanged. Entry hashes and matching scene hashes are in `stools/gui-review.json`.

- `stool-body-poses-perspective.jpg`: default perspective; 0, 45, 90, 180; 1364×1024; all four pairs framed.
- `stool-body-poses-top.jpg`: TOP; 0, 45, 90, 180; 1364×1024; all four pairs framed.
- `stool-colours-1-perspective.jpg`: default perspective; black, blue, brown, cyan; 1364×1024; all four pairs framed.
- `stool-colours-1-top.jpg`: TOP; black, blue, brown, cyan; 1364×1024; all four pairs framed.
- `stool-colours-2-perspective.jpg`: default perspective; gray, green, light_blue, light_gray; 1364×1024; all four pairs framed.
- `stool-colours-2-top.jpg`: TOP; gray, green, light_blue, light_gray; 1364×1024; all four pairs framed.
- `stool-colours-3-perspective.jpg`: default perspective; lime, magenta, orange, pink; 1364×1024; all four pairs framed.
- `stool-colours-3-top.jpg`: TOP; lime, magenta, orange, pink; 1364×1024; all four pairs framed.
- `stool-colours-4-perspective.jpg`: default perspective; purple, red, white, yellow; 1364×1024; all four pairs framed.
- `stool-colours-4-top.jpg`: TOP; purple, red, white, yellow; 1364×1024; all four pairs framed.
