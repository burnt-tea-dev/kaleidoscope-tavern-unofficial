from audit_paths import load_manifest, write_report
from pathlib import Path
import json,base64,io,hashlib
from PIL import Image
H=Path(__file__).resolve().parent
checks=[]
for p in sorted((H/'scenes').glob('*.bbmodel')):
 s=json.loads(p.read_text());es=s['elements'];assert len(es)==56
 ids=[a['uuid'] for a in es+s['groups']];assert len(ids)==len(set(ids))
 for t in s['textures']:
  im=Image.open(io.BytesIO(base64.b64decode(t['source'].split(',',1)[1])))
  assert list(im.size)==[t['uv_width'],t['uv_height']]
 for pair in range(4):
  for k in range(7):
   a,b=es[pair*14+k],es[pair*14+k+7]
   for v in ('from','to'):
    assert all(abs(b[v][i]-a[v][i]-(25 if i==0 else 0))<1e-8 for i in range(3))
   assert a['rotation']==b['rotation']
   if any(a['rotation']):assert all(abs(b['origin'][i]-a['origin'][i]-(25 if i==0 else 0))<1e-8 for i in range(3))
   for side,fa in a['faces'].items():
    fb=b['faces'][side]
    if fa['texture'] is None:assert fb['texture'] is None;continue
    uv=[u-(64 if k<3 and i%2==0 else 0) for i,u in enumerate(fb['uv'])]
    assert all(abs(x-y)<1e-8 for x,y in zip(fa['uv'],uv))
    assert fa.get('rotation',0)==fb.get('rotation',0)
 # Check the four animated roots and child active transforms; source and native are separate hierarchies.
 groups=s['groups'];ar=[g for g in groups if g['name'].startswith('Source world -X 1.21 body')];nr=[g for g in groups if g['name']=='bone']
 ac=[g for g in groups if g['name']=='author child pivot'];nc=[g for g in groups if g['name']=='cube_r1']
 for a,b in zip(ar+ac,nr+nc):
  assert all(abs(x-y)<1e-7 for x,y in zip(a['rotation'],b['rotation']))
  assert all(abs(b['origin'][i]-a['origin'][i]-(25 if i==0 else 0))<1e-8 for i in range(3))
 checks.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pair_count':4,'seven_cube_positions_uv_active_rotations_match':True,'self_contained_texture_dimensions_valid':True,'gui_reviewed':False})
write_report(H/'validation.json',checks);print('PASS: 5 scenes / 20 pairs / 280 cubes; all independent authored/native placements, active pivots and UVs agree.')
