"""Portable path and report plumbing. No geometry/UV calculations live here."""
from pathlib import Path
import json, os
BUNDLE = Path(__file__).resolve().parent.parent
PREFIXES = ("inputs/", "stools/", "bottles/")
def _walk(value, fn):
    if isinstance(value, dict):
        return {fn(k): _walk(v, fn) for k, v in value.items()}
    if isinstance(value, list):
        return [_walk(v, fn) for v in value]
    return fn(value) if isinstance(value, str) else value
def load_manifest(path):
    return _walk(json.loads(path.read_text()), lambda value: str(BUNDLE / value) if value.startswith(PREFIXES) else value)
def relative(value):
    root = str(BUNDLE) + "/"
    return value[len(root):] if value.startswith(root) else value
def write_report(path, value):
    root = Path(os.environ.get("TAVERN_AUDIT_OUTPUT", str(BUNDLE / "rerun")))
    target = root / path.parent.name / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(_walk(value, relative), indent=2) + "\n")
