# Portable stool audit inputs

This compact archive preserves the exact five scenes, bounded inputs, receipts and audit. The ten raw JPEGs are published next to the archive in the evidence folder rather than duplicated inside. Historical files under stools/evidence and gui-review.json describe those external original images. Run python stools/validate_scenes.py after extraction.
