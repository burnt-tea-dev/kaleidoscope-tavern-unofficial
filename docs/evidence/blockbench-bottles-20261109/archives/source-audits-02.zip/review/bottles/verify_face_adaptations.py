from audit_paths import load_manifest, write_report
import ast,sys,json,copy,base64,gzip,hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import linear_sum_assignment
H=Path(__file__).resolve().parent;R=H.parent/'inputs';ROOT=R/'source'
sys.path[:0]=[str(H),str(ROOT/'tools')]
from scene_lib_rescale import Scene
from repair_drink_planes import repair_geometry,THICKNESS,FACE_GAP
from normalize_luminous_base import normalize
from check_drink_surfaces import uv_digest
from drink_surface_math import conflicts
ref=R/'round3/compare_face_uv_ordered_all14.py';tree=ast.parse(ref.read_text());exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['faces','distance']],type_ignores=[]),str(ref),'exec'))
review=json.loads((ROOT/'data/drink-surface-review.json').read_text());crop_review=json.loads((ROOT/'data/luminous-base-review.json').read_text());manifest=load_manifest(H/'manifest.json');out=[];audit=[]
for family in manifest['families']:
 if family['name'] not in ['glowflower_brew','luminous_bride','madame_shexiang','sunset_glow']:continue
 for state in family['states']:
  gp=Path(state['canonical_geometry']);doc=json.loads(gp.read_text());rel=str(gp.relative_to(ROOT));rr=review['files'][rel]
  assert hashlib.sha256(gp.read_bytes()).hexdigest()==rr['after'];assert uv_digest(doc)==rr['uvInventory'];assert repair_geometry(copy.deepcopy(doc))==0;assert not conflicts(doc['minecraft:geometry'][0])
  a=Scene('Java');a.java(Path(state['java_model']),Path(state['java_texture']));b=Scene('Native');b.bedrock(gp,Path(state['canonical_texture']));trimmed=[]
  if family['name']=='luminous_bride':
   cr=crop_review['files'][rel];raw=gzip.decompress(base64.b64decode(cr['beforeGzipBase64']));assert hashlib.sha256(raw).hexdigest()==cr['before'];before=json.loads(raw);assert normalize(before)==4*state['count'];assert before==doc
   # Apply only the exact documented bottom-strip crop to inward source shell faces.
   for i,e in enumerate(a.j['elements']):
    if e['from'][1]==.1 and e['to'][1]==11.1 and e['from'][0]>e['to'][0]:
     assert set(s for s,f in e['faces'].items() if f['texture'] is not None)=={'north','east','south','west'}
     # Authored solid base is present at same pivot/rotation and covers the removed bottom unit.
     bases=[q for q in a.j['elements'] if q['from'][1]==.1 and q['to'][1]==1.1 and q['rotation']==e['rotation'] and q['origin']==e['origin'] and sorted([q['from'][0],q['to'][0]])==sorted([e['from'][0],e['to'][0]]) and sorted([q['from'][2],q['to'][2]])==sorted([e['from'][2],e['to'][2]])]
     assert len(bases)==1
     for s,f in e['faces'].items():
      if f['texture'] is not None:assert f['uv']==[11,5,15,16];f['uv'][3]=15
     e['from'][1]=1.1;trimmed.append(i)
   assert len(trimmed)==state['count']
  af,bf=faces(a),faces(b);cost=np.array([[distance(x,y) if np.allclose(x['uv'],y['uv'],rtol=0,atol=1e-9) else 1e6 for y in bf] for x in af]);rows,cols=linear_sum_assignment(cost);assert len(rows)==len(af)==len(bf);pairs=[]
  for ai,bi in zip(rows,cols):
   x,y=af[ai],bf[bi];assert np.allclose(x['uv'],y['uv'],rtol=0,atol=1e-9);d=np.array(y['vertices'])-np.array(x['vertices']);delta=distance(x,y);classification='exact';local=None
   if delta>1e-7:
    assert np.max(np.abs(d-d[0]))<1e-7,'Non-rigid face change'
    e=b.j['elements'][y['element']];rx,ry,rz=np.radians(e['rotation']);X=np.array([[1,0,0],[0,np.cos(rx),-np.sin(rx)],[0,np.sin(rx),np.cos(rx)]]);Y=np.array([[np.cos(ry),0,np.sin(ry)],[0,1,0],[-np.sin(ry),0,np.cos(ry)]]);Z=np.array([[np.cos(rz),-np.sin(rz),0],[np.sin(rz),np.cos(rz),0],[0,0,1]]);local=(Z@Y@X).T@d[0]
    axis,sign={'east':(0,1),'west':(0,-1),'up':(1,1),'down':(1,-1),'south':(2,1),'north':(2,-1)}[y['face']];sign*=(-1 if axis==0 else 1);expected=np.zeros(3)
    se=a.j['elements'][x['element']];thin=abs(se['to'][axis]-se['from'][axis])<=.020001
    if thin:
     assert abs(se['to'][axis]-se['from'][axis])<1e-9
     expected[axis]=sign*THICKNESS/2;classification='documented symmetric thin-sheet separation'
    else:
     expected[axis]=sign*FACE_GAP;classification='documented outward same-facing conflict separation'
    assert np.max(np.abs(local-expected))<1e-7,(family['name'],state['count'],x['element'],x['face'],local,expected)
   pairs.append({'java_element':x['element'],'java_face':x['face'],'canonical_cube':y['element'],'canonical_face':y['face'],'classification':classification,'max_vertex_delta':delta,'local_displacement':None if local is None else local.tolist(),'uv_equal':True})
  out.append({'family':family['name'],'count':state['count'],'face_count':len(af),'complete_uv_bijection':True,'cropped_source_shell_elements':trimmed,'review_hash_matches':True,'review_uv_inventory_matches':True,'repair_idempotent':True,'remaining_same_facing_conflicts':0,'matches':pairs})
result={'method':'Exact UV-parametric face matching. For luminous only, reproduce hash-verified normalize_luminous_base on stored before bytes and prove Java base coverage before comparing documented cropped faces. Nonzero face translations must exactly equal the rule-derived local outward FACE_GAP or symmetric THICKNESS/2; numeric epsilon 1e-7 only. No general geometric tolerance.','states':out,'inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ref,ROOT/'tools/repair_drink_planes.py',ROOT/'tools/drink_surface_math.py',ROOT/'tools/normalize_luminous_base.py',ROOT/'data/drink-surface-review.json',ROOT/'data/luminous-base-review.json']},'summary':{'states':len(out),'faces':sum(x['face_count'] for x in out),'all_complete_uv_bijection':True,'unexplained_differences':0,'luminous_cropped_shell_faces':sum(len(x['cropped_source_shell_elements'])*4 for x in out),'engine_acceptance':False}}
write_report(H/'face-adaptation-verification.json',result);print(result['summary'])
