# Bottles: GUI review pending

These 25 self-contained scene files cover 97 placed count states. Java is at world z=-12 and canonical at world z=+12; count increases along world X. Identify source/count groups rather than assuming universal front/back positions.

The existing numerical audits cover 4,132 faces: 82 exact states and 15 explicitly adapted states/960 faces, including the separately verified Luminous Bride crop contract. The raw diagnostic and later `face-adaptation-verification.json` preserve the precise differences and contracts. No bottle GUI acceptance is claimed. The completed stool screenshot review does not apply to bottles.

Original model, texture, UUID, hierarchy and transform bytes remain unchanged. Nothing was exported, deployed or published.

## Rerun the included numerical audits

Use Python with the packages in `requirements.txt`. From the extracted package root run, in order:

```sh
python bottles/validate_scenes.py
python bottles/check_routing.py
python bottles/compare_faces.py
python bottles/verify_face_adaptations.py
```

Scripts resolve their included inputs relative to the package location and write outputs under `rerun/bottles/`. The original saved reports remain unchanged. This audit rerun does not perform GUI inspection or change its pending status.

## Source and contract limits

Canonical runtime is 0.6.212. These sheets use the actual BP placed-block material and terrain binding, not the separately documented entity material. The editor does not emulate Minecraft shaders, lighting, transparency, interaction, drinking/throwing, held sprites, racks or engine behavior.

The 15 adapted states require exact local-axis FACE_GAP or THICKNESS/2 displacement, with Bedrock X reflection and 1e-7 arithmetic epsilon. This is not a blanket 0.0625 tolerance. Luminous Bride's 40 cropped shell faces are checked against hash-locked before snapshots, authored solid-base coverage and unchanged visible texel scale.

Forge source: c4ec1880bd44cf3139d3ba744ab30bb379cf1416. NeoForge source: a1afba34981a00e89d57130d3dc8f1e64f1820a2. Locked source JAR SHA256: 03f35e1e614953b22cd1f5e34345613f3a6a283bf1b1c99659b57d58970edeff. Assets were extracted and hash/size-verified, never executed. The JAR is not bundled; publisher checksum verified remains false.

Original Tavern code/art: Kaleidoscope Official Production Team / YSBB, https://github.com/KaleidoscopeMods/KaleidoscopeTavern . Bedrock adaptation: casama233 and port contributors, https://github.com/casama233/kaleidoscope-tavern-unofficial . Code is BSD-3-Clause and artwork/derivatives are CC BY-NC-SA 4.0; preserve the included licenses. Review import does not redraw textures; canonical face-separation/crop adaptations are documented above. No author/Mojang/Microsoft endorsement is implied.
