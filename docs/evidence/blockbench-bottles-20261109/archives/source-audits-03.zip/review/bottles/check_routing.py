from audit_paths import load_manifest, write_report
import json,hashlib
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parent/'inputs/source';read=lambda p:json.loads(p.read_text());files={};out={}
def load(p):files[str(p)]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};return read(p)
it=load(R/'runtime/RP/textures/item_texture.json')['texture_data']
for p in (R/'runtime/RP/entity').glob('*.json'):
 if p.name not in ['runtime_thrown_drink.entity.json','runtime_bar_cabinet_bottle_visual.entity.json','runtime_circular_rack_bottle_visual.entity.json','runtime_tilted_rack_bottle_visual.entity.json']:continue
 d=load(p)['minecraft:client_entity']['description']; rec={'materials':d['materials'],'geometry':d['geometry'],'textures':d['textures'],'animations':d.get('animations'),'scripts':d.get('scripts'),'render_controllers':d['render_controllers'],'resolved_controllers':{}}
 ids=[next(iter(x)) if isinstance(x,dict) else x for x in d['render_controllers']]
 for rp in (R/'runtime/RP/render_controllers').glob('*.json'):
  controllers=read(rp).get('render_controllers',{})
  for id in ids:
   if id in controllers:load(rp);rec['resolved_controllers'][id]={'path':str(rp),'controller':controllers[id]}
 assert set(ids)==set(rec['resolved_controllers']);out[p.stem]=rec
items={}
for family in sorted((H.parent/'inputs/java-reference/src/main/resources/assets/kaleidoscope_tavern/models/block/brew/drink').iterdir()):
 items[family.name]=[]
 for p in sorted(list((R/'runtime/BP/items').glob(family.name+'_q*.json')) + ([R/'runtime/BP/items/watermelon_juice.json'] if family.name=='watermelon_juice' else [])):
  j=load(p)['minecraft:item'];c=j['components'];icon=c['minecraft:icon'];t=it[icon]['textures'];assert isinstance(t,str);tp=R/'runtime/RP'/(t+'.png');files[str(tp)]={'bytes':tp.stat().st_size,'sha256':hashlib.sha256(tp.read_bytes()).hexdigest()}
  items[family.name].append({'id':j['description']['identifier'],'icon':icon,'texture':str(tp),'use_animation':c.get('minecraft:use_animation'),'use_modifiers':c.get('minecraft:use_modifiers')})
write_report(H/'routing.json',{'entity_routing':out,'quality_item_sprite_routing':items,'inputs':files,'limits':'Routing only, not acceptance of rack placement, held icons, throwing or drinking behavior. These sheets use BP placed-block material, not entity materials.'});print('resolved entities',len(out),'quality item bindings',sum(map(len,items.values())))
