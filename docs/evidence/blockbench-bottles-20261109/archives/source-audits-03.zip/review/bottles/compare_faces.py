from audit_paths import load_manifest, write_report
import ast,json,sys,hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import linear_sum_assignment
H=Path(__file__).resolve().parent;R=H.parent/'inputs';sys.path.insert(0,str(H));from scene_lib_rescale import Scene
# Reuse only audited pure UVToLocal and distance functions, not module side effects.
reference=R/'round3/compare_face_uv_ordered_all14.py'
tree=ast.parse(reference.read_text()); functions=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['faces','distance']],type_ignores=[]);exec(compile(functions,str(reference),'exec'))
manifest=load_manifest(H/'manifest.json');results=[]
for family in manifest['families']:
 for state in family['states']:
  a=Scene('Java');a.java(Path(state['java_model']),Path(state['java_texture']));b=Scene('Bedrock');b.bedrock(Path(state['canonical_geometry']),Path(state['canonical_texture']))
  af,bf=faces(a),faces(b);cost=np.array([[distance(x,y) if np.allclose(x['uv'],y['uv'],rtol=0,atol=1e-9) else 1e6 for y in bf] for x in af]);rows,cols=linear_sum_assignment(cost);pairs=[]
  for ai,bi in zip(rows,cols):
   x,y=af[ai],bf[bi];d=np.array(y['vertices'])-np.array(x['vertices']);delta=distance(x,y)
   pairs.append({'java_element':x['element'],'java_face':x['face'],'canonical_cube':y['element'],'canonical_face':y['face'],'uv_equal':bool(np.allclose(x['uv'],y['uv'],rtol=0,atol=1e-9)),'max_vertex_delta':float(delta),'vertex_displacements':d.tolist(),'java_vertices':x['vertices'],'canonical_vertices':y['vertices'],'java_uv':x['uv'],'canonical_uv':y['uv']})
  results.append({'family':family['name'],'count':state['count'],'source_faces':len(af),'canonical_faces':len(bf),'bijective':len(rows)==len(af)==len(bf),'all_uv_equal':all(p['uv_equal'] for p in pairs),'max_delta':max(p['max_vertex_delta'] for p in pairs),'matches':pairs})
out={'method':'Blockbench 5.2.2 UVToLocal-parametric vertices, signed dimensions and UV quarter-turns, nondegenerate geometric faces; one-to-one assignment restricted to equal UV rectangles. No acceptance tolerance beyond floating arithmetic has yet been applied.','reference':str(reference),'reference_sha256':hashlib.sha256(reference.read_bytes()).hexdigest(),'results':results}
write_report(H/'face-uv-diagnostic.json',out)
for r in results:
 if r['max_delta']>1e-6 or not r['bijective']: print(r['family'],r['count'],r['source_faces'],r['canonical_faces'],r['all_uv_equal'],round(r['max_delta'],8),[(p['java_element'],p['java_face'],p['canonical_cube'],round(p['max_vertex_delta'],8)) for p in r['matches'] if p['max_vertex_delta']>1e-6])
