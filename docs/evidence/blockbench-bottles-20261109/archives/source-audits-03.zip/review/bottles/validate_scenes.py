from audit_paths import load_manifest, write_report
import json,hashlib,base64
from pathlib import Path
from PIL import Image
H=Path(__file__).resolve().parent; manifest=load_manifest(H/'manifest.json');rows=[]
for family in manifest['families']:
 j=json.loads(Path(family['scene']).read_text());assert hashlib.sha256(Path(family['scene']).read_bytes()).hexdigest()==family['scene_sha256'];els={e['uuid']:e for e in j['elements']}
 def flat(n):return [els[x] for x in n['children'] if isinstance(x,str)]+sum([flat(x) for x in n['children'] if isinstance(x,dict)],[])
 for i,state in enumerate(family['states']):
  a,b=map(flat,j['outliner'][i*2:i*2+2]);xoff=(i-(len(family['states'])-1)/2)*22
  def norm(e,z):
   d={k:e[k] for k in ['from','to','rotation','origin']};d={k:([round(v-[xoff,0,z][n],7) for n,v in enumerate(vs)] if k!='rotation' else vs) for k,vs in d.items()};d['faces']={s:{k:v for k,v in f.items() if k!='texture'} for s,f in e['faces'].items() if f['texture'] is not None}
   if not any(d['rotation']):d.pop('origin')
   return d
  eq=[norm(e,-12) for e in a]==[norm(e,12) for e in b]
  jar=H/'verified-jar-inputs/assets/kaleidoscope_tavern'/Path(state['java_texture']).relative_to(H.parent/'inputs/java-reference/src/main/resources/assets/kaleidoscope_tavern');src=Path(state['java_texture'])
  pixels=Image.open(jar).size==Image.open(src).size and Image.open(jar).convert('RGBA').tobytes()==Image.open(src).convert('RGBA').tobytes();assert pixels
  rows.append({'family':family['name'],'count':state['count'],'geometry_uv_equal_ignoring_unrotated_pivots':eq,'java_element_count':len(a),'canonical_cube_count':len(b),'jar_texture_pixels_equal_current':pixels,'classification':'Exact geometry and face UV correspondence (zero-rotation pivots ignored)' if eq else 'Face-split conversion; requires visual or surface equivalence review, not a raw cube-list equality pass'})
 for t in j['textures']:assert t['source'].startswith('data:image/png;base64,')
result={'states':rows,'summary':{'states':len(rows),'exact_geometry_uv_states':sum(r['geometry_uv_equal_ignoring_unrotated_pivots'] for r in rows),'face_split_families':sorted(set(r['family'] for r in rows if not r['geometry_uv_equal_ignoring_unrotated_pivots'])),'all_jar_texture_pixels_equal_current':True,'gui_acceptance':'NOT_RUN_BY_THIS_WORKER'}}
write_report(H/'static-checks.json',result);print(result['summary'])
